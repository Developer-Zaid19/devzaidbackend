export const COLORS = {
  primary: '#00BCFF',
  background: '#0A1326',
  text: '#F1F5F9',
  bgt: '#160f58',
};
