import React, { useEffect, useState } from 'react'
import { COLORS } from '../constants/colors';
import { VERIFY_PASS } from '@env';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView } from 'react-native';


const BlogScreen = () => {

    const [Title, setTitle] = useState("")
    const [Description, setDescription] = useState("")
    const [Paragraph1, setParagraph1] = useState("")
    const [Paragraph2, setParagraph2] = useState("")
    const [Paragraph3, setParagraph3] = useState("")

    const verifypass = VERIFY_PASS


    const uploadhandeler = async () => {
        const payload = {
            title: Title,
            description: Description,
            content: Paragraph1,
            para1: Paragraph2,
            para2: Paragraph3,
            verifypass: verifypass
        };
        try {
            const res = await fetch('https://devzaidbackend.onrender.com/api/content/postblog', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });
            if (!res.ok) {
                alert('Something went wrong');
                return
            }
            setTitle("")
            setDescription("")
            setParagraph1("")
            setParagraph2("")
            setParagraph3("")
            alert("Blog Upload Successfully")
        } catch (err) {
            alert('Error posting data');
        }
    };


    return (
        <ScrollView style={{
            flex: 1,
            backgroundColor: COLORS.background
        }}>
            <View style={{
                backgroundColor: COLORS.bgt,
            }}>
                <Text style={{
                    color: COLORS.primary,
                    fontSize: 35,
                    textAlign: 'center',
                    paddingVertical: 21,
                    fontWeight: 800,

                }}>&lt;DeveloperZaid/&gt;</Text>
            </View>
            <View style={{
                width: '100%',
                alignItems: 'center',
                marginVertical: 24
            }}>

                <TextInput placeholder='Title'
                    multiline={true}
                    numberOfLines={2}
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Title}
                    onChangeText={text => setTitle(text)}
                />


                <TextInput placeholder='Description'
                multiline={true}
                    numberOfLines={1}
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Description}
                    onChangeText={text => setDescription(text)}
                />


                <TextInput placeholder='Paragraph1'
                 numberOfLines={15}
                    multiline={true}
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Paragraph1}
                    onChangeText={text => setParagraph1(text)}
                />


                <TextInput placeholder='Paragraph2' numberOfLines={15}
                    multiline={true}
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Paragraph2}
                    onChangeText={text => setParagraph2(text)}
                />


                <TextInput placeholder='Paragraph3' numberOfLines={15}
                    multiline={true}
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Paragraph3}
                    onChangeText={text => setParagraph3(text)}
                />

                <TouchableOpacity style={{
                    backgroundColor: COLORS.primary,
                    height: 30,
                    width: '80%',
                    borderRadius: 10


                }}>
                    <Text style={{
                        color: COLORS.background,
                        textAlign: 'center',
                        fontWeight: 700,
                        justifyContent: 'center',
                        fontSize: 15,
                        paddingVertical: 4
                    }}
                        onPress={() => uploadhandeler()}
                    >Upload</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    )
}

export default BlogScreen



const styles = StyleSheet.create({


    inputtext: {

        color: COLORS.text,
        fontSize: 15,
        borderColor: COLORS.primary,
        borderWidth: 1,
        
        width: 300,
        borderRadius: 9,
        color: COLORS.text,
        marginVertical: 20,
        padding: 10,



    }
});
