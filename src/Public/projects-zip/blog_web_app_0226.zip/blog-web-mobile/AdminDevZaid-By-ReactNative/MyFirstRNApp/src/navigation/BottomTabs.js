import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';


import BlogScreen from '../screens/BlogScreen';
import DocsScreen from '../screens/DocsScreen';
import { COLORS } from '../constants/colors';
// import SettingsScreen from '../screens/SettingsScreen';

const Tab = createBottomTabNavigator();

export default function BottomTabs() {
    return (
        <Tab.Navigator screenOptions={{
            headerShown: false,
            tabBarActiveTintColor: COLORS.primary,   // selected tab color
            tabBarInactiveTintColor: COLORS.text,    // unselected tab color
            tabBarStyle: {
                backgroundColor: COLORS.background,   // bottom bar ka background
                height: 60,                // height
                paddingBottom: 5,
                tabBarLabelStyle: {
                    fontSize: 12,              // label size
                    fontWeight: 'bold',
                },

            }
        }
        } >
            <Tab.Screen
                name="Blog"
                component={BlogScreen}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name="pencil" size={size} color={color} />
                    ),
                }}
            />
            <Tab.Screen name="Docs" component={DocsScreen}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Ionicons name='document' size={size} color={color} />
                    ),
                }}
            />
        </ Tab.Navigator>
    );
}
