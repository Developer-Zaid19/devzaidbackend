import React, { useState } from 'react'
import { COLORS } from '../constants/colors';
import { VERIFY_PASS } from '@env';
import { pick } from '@react-native-documents/picker';
import { View, Text, StyleSheet, TouchableOpacity, TextInput } from 'react-native';


const DocsScreen = () => {
    const [select, setselect] = useState(false)
    const [Title, setTitle] = useState("")
    const [Description, setDescription] = useState("")
    const [selectedPdf, setselectedPdf] = useState(null)
    const verifypass = VERIFY_PASS


const uploadhandeler = async () => {
  if (!selectedPdf) {
    alert('Choose document first');
    return;
  }

  const formData = new FormData();

  // normal fields
  formData.append('title', Title);
  formData.append('category', Description);
  formData.append('verifypass', verifypass);

  // pdf file
  formData.append('file', {
    uri: selectedPdf.uri,
    name: selectedPdf.name,
    type: 'application/pdf',
  });

  try {
    const res = await fetch(
      'https://devzaidbackend.onrender.com/api/content/postnote',
      {
        method: 'POST',
        body: formData,
      }
    );

    if (!res.ok) {
      alert('Something went wrong');
      console.log("doc upload nahi hua")
      return;
    }

    setTitle('');
    setDescription('');
    setselect(false);
    setselectedPdf(null);

    alert('Document Upload Successfully');
  } catch (err) {
    console.log(err);
    alert('Error posting data');
  }
};


const pickPDF = async () => {
  try {
    const result = await pick({
      type: ['application/pdf'],
      allowMultiSelection: false,
    });

    const file = result[0];
    setselectedPdf(file)
    setselect(true)
    console.log('Name:', file.name);
    console.log('URI:', file.uri);
    console.log('Type:', file.type);
    console.log('Size:', file.size);

  } catch (err) {
    if (err?.code === 'DOCUMENT_PICKER_CANCELED') {
      console.log('User cancelled');
    } else {
      console.log('Picker error:', err);
    }
  }
};

    return (
        <View style={{
            flex: 1,
            backgroundColor: COLORS.background
        }}>
            <View style={{
                backgroundColor: COLORS.bgt,
            }}>
                <Text style={{
                    color: COLORS.primary,
                    fontSize: 35,
                    textAlign: 'center',
                    paddingVertical: 21,
                    fontWeight: 800,

                }}>&lt;DeveloperZaid/&gt;</Text>
            </View>
            <View style={{
                width: '100%',
                alignItems: 'center',
                marginVertical: 24
            }}>

                <TextInput placeholder='Title'
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Title}
                    onChangeText={text => setTitle(text)}
                />


                <TextInput placeholder='Description'
                    style={styles.inputtext}
                    placeholderTextColor={COLORS.primary}
                    value={Description}
                    onChangeText={text => setDescription(text)}
                />

                <TouchableOpacity style={{
                    backgroundColor: COLORS.primary,
                    height: 30,
                    width: '80%',
                    borderRadius: 10


                }}
                onPress={() => pickPDF()}
                >
                    <Text style={{

                        color: COLORS.background,
                        textAlign: 'center',
                        fontWeight: 700,
                        justifyContent: 'center',
                        fontSize: 15,
                        paddingVertical: 4
                    }}>{select ? "selected" : "Select PDF"}</Text>
                </TouchableOpacity>
                <TouchableOpacity style={{
                    backgroundColor: COLORS.primary,
                    height: 30,
                    width: '80%',
                    margin: 15,
                    borderRadius: 10


                }}
                    onPress={() => uploadhandeler()}
                >
                    <Text style={{

                        color: COLORS.background,

                        textAlign: 'center',
                        fontWeight: 700,
                        justifyContent: 'center',
                        fontSize: 15,
                        paddingVertical: 4
                    }}>Upload</Text>
                </TouchableOpacity>
            </View>

        </View>
    )
}


export default DocsScreen;


const styles = StyleSheet.create({


    inputtext: {

        color: COLORS.text,
        fontSize: 15,
        borderColor: COLORS.primary,
        borderWidth: 1,
        height: 45,
        width: 300,
        borderRadius: 9,
        color: COLORS.text,
        marginVertical: 20,
        padding: 10,



    }
});

