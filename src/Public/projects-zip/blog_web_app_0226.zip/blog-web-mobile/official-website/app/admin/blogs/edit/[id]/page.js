"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useParams } from "next/navigation";
import Loader from "../../../../components/Loader";



// ── Shared style helpers ──────────────────────────────────────────
const inputStyle = {
  width: "100%", padding: "10px 14px", borderRadius: "10px",
  background: "var(--background)", border: "1px solid var(--border)",
  color: "var(--foreground)", fontSize: "14px", outline: "none",
  transition: "border-color 0.2s, box-shadow 0.2s",
  boxSizing: "border-box",
};
const labelStyle = {
  display: "block", fontSize: "13px", fontWeight: 600,
  color: "var(--foreground-muted)", marginBottom: "7px", letterSpacing: "0.01em",
};
function Field({ label, hint, children }) {
  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      <label style={labelStyle}>{label}</label>
      {children}
      {hint && <p style={{ fontSize: "11px", color: "var(--foreground-faint)", marginTop: "5px" }}>{hint}</p>}
    </div>
  );
}
function FocusInput({ style: extraStyle, ...props }) {
  const [focused, setFocused] = useState(false);
  return (
    <input
      {...props}
      style={{
        ...inputStyle, ...extraStyle,
        borderColor: focused ? "var(--brand)" : "var(--border)",
        boxShadow: focused ? "0 0 0 3px var(--brand-ring)" : "none",
      }}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    />
  );
}
function FocusTextarea(props) {
  const [focused, setFocused] = useState(false);
  return (
    <textarea
      {...props}
      style={{
        ...inputStyle, resize: "vertical", minHeight: "120px", fontFamily: "inherit",
        borderColor: focused ? "var(--brand)" : "var(--border)",
        boxShadow: focused ? "0 0 0 3px var(--brand-ring)" : "none",
      }}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    />
  );
}


// ── Main ─────────────────────────────────────────────────────────
export default function Editblogpage() {

  const params = useParams();
  const id = params.id;

  const BASE_URL = 'https://devzaidbackend.onrender.com/api/content'
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  const [formData, setFormData] = useState({
    id: "",
    title: "",
    description: "",
    content: "",
    para1: "",
    para2: "",
  });

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch(`/api/editblog/${formData.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to edit blog");
      alert("edited blog successfully!");
      setFormData({ title: "", description: "", content: "", para1: "", para2: "" });
    } catch (err) {
      alert(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  useEffect(() => {
    const fetchblogs = async () => {
      try {
        const res = await fetch(`${BASE_URL}/blogs/${id}`)
        if (!res.ok){
          console.error("some thing went wrong in server") 
          return;
        }
        const data = await res.json()
        setFormData(data)
      } catch (e) {
        console.error("server error", e.message);
      }
    }
    fetchblogs();
  }, [router])


  return (
    <div style={{ maxWidth: "760px", padding: "32px 24px", display: "flex", flexDirection: "column", gap: "28px" }}>

      {/* Header */}
      <div>
        <p style={{ fontSize: "12px", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--brand)", marginBottom: "6px" }}>
          Content
        </p>
        <h1 style={{ fontSize: "clamp(22px, 4vw, 32px)", fontWeight: 800, color: "var(--foreground)", letterSpacing: "-0.02em" }}>
          Edit Blog
        </h1>
        <p style={{ marginTop: "6px", fontSize: "14px", color: "var(--foreground-muted)" }}>
          Update some Information
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "0" }}>
        <div style={{
          background: "var(--background-card)", border: "1px solid var(--border)",
          borderRadius: "16px", boxShadow: "var(--shadow-sm)", overflow: "hidden",
        }}>

          {/* Section: Basic Info */}
          <SectionHeader label="Basic Info" />
          <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }} className="form-grid-2">
              <Field label="Blog Title">
                <FocusInput
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Understanding React Server Components"
                  required
                />
              </Field>
              <Field label="Description">
                <FocusTextarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Short description of the blog..."
                  required
                />
              </Field>
            </div>


          </div>
          <Divider />

          <SectionHeader label="Main Content" />

          <div style={{ padding: "24px" }}>
            <FocusTextarea
              name="content"
              value={formData.content}
              onChange={handleChange}
              placeholder="Main blog content..."
              required
            />
          </div>

          <Divider />

          <SectionHeader label="Paragraph 1" />

          <div style={{ padding: "24px" }}>
            <FocusTextarea
              name="para1"
              value={formData.para1}
              onChange={handleChange}
              placeholder="Additional paragraph..."
              required
            />
          </div>

          <Divider />

          <SectionHeader label="Paragraph 2" />

          <div style={{ padding: "24px" }}>
            <FocusTextarea
              name="para2"
              value={formData.para2}
              onChange={handleChange}
              placeholder="Additional paragraph..."
              required
            />
          </div>

        </div>

        {/* Action buttons */}
        <div style={{ display: "flex", gap: "12px", marginTop: "20px", justifyContent: "flex-end" }}>
          <button type="button" style={{
            padding: "11px 22px", borderRadius: "10px", fontSize: "14px", fontWeight: 600,
            background: "var(--background-subtle)", border: "1px solid var(--border)",
            color: "var(--foreground-muted)", cursor: "pointer",
          }} onClick={() => router.push("/admin/blogs")}>
            Cancel
          </button>
          <button type="submit" disabled={submitting} style={{
            padding: "11px 28px", borderRadius: "10px", fontSize: "14px", fontWeight: 700,
            background: submitting ? "var(--maincolor)" : "var(--mainsoft)",
            color: "#fff", border: "none", cursor: submitting ? "not-allowed" : "pointer",
            boxShadow: "var(--shadow-sm)", display: "inline-flex", alignItems: "center", gap: "8px",
            transition: "background 0.2s",
          }}>
            {submitting ? <><Spinner light /> Adding…</> : "Add blog"}
          </button>
        </div>
      </form >

      <style>{`
        @media (max-width: 600px) {
          .form-grid-2, .form-grid-4 { grid-template-columns: 1fr !important; }
        }
        @media (min-width: 601px) and (max-width: 900px) {
          .form-grid-4 { grid-template-columns: 1fr 1fr !important; }
        }
        @keyframes spin { to { transform: rotate(360deg) } }
      `}</style>
    </div >
  );
}

// ── Small shared components ───────────────────────────────────────
function SectionHeader({ label }) {
  return (
    <div style={{ padding: "14px 24px 0", display: "flex", alignItems: "center", gap: "8px" }}>
      <p style={{ fontSize: "12px", fontWeight: 700, letterSpacing: "0.07em", textTransform: "uppercase", color: "var(--foreground-faint)" }}>
        {label}
      </p>
    </div>
  );
}
function Divider() {
  return <div style={{ height: "1px", background: "var(--border)", margin: "4px 0" }} />;
}
function Spinner({ light }) {
  return (
    <span style={{
      width: "13px", height: "13px", borderRadius: "50%", display: "inline-block", flexShrink: 0,
      border: `2px solid ${light ? "rgba(255,255,255,0.35)" : "var(--brand-ring)"}`,
      borderTopColor: light ? "#fff" : "var(--brand)",
      animation: "spin 0.7s linear infinite",
    }} />
  );
}