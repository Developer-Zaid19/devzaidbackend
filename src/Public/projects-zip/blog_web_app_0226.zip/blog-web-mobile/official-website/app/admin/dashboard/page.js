"use client"
import { getSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Loader from "../../components/Loader";




// ── Icon components ───────────────────────────────────────────────
function BoxIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
            <polyline points="3.27 6.96 12 12.01 20.73 6.96" /><line x1="12" y1="22.08" x2="12" y2="12" />
        </svg>
    );
}
function TagIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
            <line x1="7" y1="7" x2="7.01" y2="7" />
        </svg>
    );
}
function LayersIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 2 7 12 12 22 7 12 2" />
            <polyline points="2 17 12 22 22 17" /><polyline points="2 12 12 17 22 12" />
        </svg>
    );
}
function StarIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
        </svg>
    );
}
function SearchIcon() {
    return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
    );
}
function TrendUpIcon() {
    return (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" /><polyline points="17 6 23 6 23 12" />
        </svg>
    );
}

// ── Stat Card ─────────────────────────────────────────────────────
function StatCard({ icon, label, value, accent }) {
    return (
        <div style={{
            background: "var(--background-card)",
            border: "1px solid var(--border)",
            borderRadius: "16px",
            padding: "24px",
            boxShadow: "var(--shadow-sm)",
            display: "flex",
            flexDirection: "column",
            gap: "16px",
            transition: "box-shadow 0.2s, transform 0.2s",
            cursor: "default",
        }}
            onMouseEnter={e => {
                e.currentTarget.style.boxShadow = "var(--shadow-md)";
                e.currentTarget.style.transform = "translateY(-2px)";
            }}
            onMouseLeave={e => {
                e.currentTarget.style.boxShadow = "var(--shadow-sm)";
                e.currentTarget.style.transform = "translateY(0)";
            }}
        >
            {/* Icon badge */}
            <div style={{
                width: "42px", height: "42px", borderRadius: "12px",
                background: accent ? "var(--brand-faint)" : "var(--background-subtle)",
                color: accent ? "var(--brand)" : "var(--foreground-muted)",
                display: "flex", alignItems: "center", justifyContent: "center",
            }}>
                {icon}
            </div>

            <div>
                <p style={{ fontSize: "12px", fontWeight: 500, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--foreground-faint)", marginBottom: "6px" }}>
                    {label}
                </p>
                <p style={{ fontSize: "32px", fontWeight: 700, color: "var(--foreground)", lineHeight: 1 }}>
                    {value}
                </p>
            </div>

            {/* Subtle bottom accent line */}
            {accent && (
                <div style={{ height: "3px", background: "var(--brand)", borderRadius: "999px", width: "36px", marginTop: "-4px" }} />
            )}
        </div>
    );
}


// ── Main Page ─────────────────────────────────────────────────────
export default
    function DashboardPage() {

    const router = useRouter();
    const BASE_URL = 'https://devzaidbackend.onrender.com/api/content'
    const [totalBlogs, setTotalBlogs] = useState(0);
    const [totalNotes, setTotalNotes] = useState(0);

    const [blogs, setBlogs] = useState([]);
    const [notes, setNotes] = useState([]);

    const [activeTab, setActiveTab] = useState("blogs");

    const [loading, setLoading] = useState(true);


    useEffect(() => {
        const fetchSession = async () => {
            const session = await getSession();
            if (!session) {
                router.push("/admin/login");
                return;
            }

        };

        fetchSession();
    }, [router]);

    useEffect(() => {
        const fetchDashboard = async () => {
            try {

                const [
                    blogsTotalRes,
                    notesTotalRes,
                    blogsRes,
                    notesRes
                ] = await Promise.all([
                    fetch(`${BASE_URL}/totalblog`),
                    fetch(`${BASE_URL}/totalnotes`),
                    fetch(`${BASE_URL}/blogs`),
                    fetch(`${BASE_URL}/notes`)
                ]);

                const blogsTotal = await blogsTotalRes.json();
                const notesTotal = await notesTotalRes.json();

                const blogsData = await blogsRes.json();
                const notesData = await notesRes.json();

                setTotalBlogs(blogsTotal.total);
                setTotalNotes(notesTotal.total);

                setBlogs(blogsData);
                setNotes(notesData);

            } catch (error) {
                console.error(error);
            } finally {
                setLoading(false);
            }
        };

        fetchDashboard();
    }, []);

    if (loading) {
        return (
            <div className="flex justify-center items-center min-h-[70vh]">
                <div className="text-(--text-muted)">
                    <Loader />
                </div>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "32px 24px", display: "flex", flexDirection: "column", gap: "32px" }}>

            {/* ── Header ── */}
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: "12px" }}>
                <div>
                    <p style={{ fontSize: "12px", fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--brand)", marginBottom: "6px" }}>
                        Overview
                    </p>
                    <h1 style={{ fontSize: "clamp(24px, 4vw, 36px)", fontWeight: 800, color: "var(--foreground)", letterSpacing: "-0.02em", lineHeight: 1.1 }}>
                        Dashboard
                    </h1>
                    <p style={{ marginTop: "8px", fontSize: "15px", color: "var(--foreground-muted)" }}>
                        Manage your e-commerce products and search system.
                    </p>
                </div>

                {/* Live badge */}
                <div style={{
                    display: "flex", alignItems: "center", gap: "8px",
                    background: "var(--background-subtle)", border: "1px solid var(--border)",
                    borderRadius: "999px", padding: "8px 16px", fontSize: "13px", color: "var(--foreground-muted)",
                }}>
                    <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "var(--brand)", display: "inline-block" }} className="pulse" />
                    Live data
                </div>
            </div>

            {/* ── Stat Cards ── */}
            <div style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                gap: "16px",
            }}>
                <StatCard
                    icon={<BoxIcon />}
                    label="Total Blogs"
                    value={totalBlogs}
                    accent
                />

                <StatCard
                    icon={<LayersIcon />}
                    label="Total Notes"
                    value={totalNotes}
                />
            </div>
            <div className="flex items-center gap-3 mt-6">

                <button
                    onClick={() => setActiveTab("blogs")}
                    className={`px-5 py-2 rounded-xl transition-all duration-300 ${activeTab === "blogs"
                        ? "bg-(--maincolor) text-white"
                        : "bg-(--background-card) border border-(--border)"
                        }`}
                >
                    Blogs
                </button>

                <button
                    onClick={() => setActiveTab("notes")}
                    className={`px-5 py-2 rounded-xl transition-all duration-300 ${activeTab === "notes"
                        ? "bg-(--maincolor) text-white"
                        : "bg-(--background-card) border border-(--border)"
                        }`}
                >
                    Notes
                </button>

            </div>

            <div className="mt-6 overflow-hidden">
                <AnimatePresence mode="wait">

                    <motion.div
                        key={activeTab}
                        initial={{ opacity: 0, x: activeTab === "blogs" ? -50 : 50 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: activeTab === "blogs" ? 50 : -50 }}
                        transition={{ duration: 0.35 }}
                    >
                        {/* yahan se shuru hua */}
                        {
                            activeTab === "blogs" ? (
                                <div className="grid gap-4 max-h-[600px] overflow-y-auto pr-2">
                                    {blogs.map((blog, index) => (
                                        <motion.div
                                            key={blog.id}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{
                                                duration: 0.3,
                                                delay: index * 0.05
                                            }}
                                            className="glass rounded-2xl p-6"
                                        >

                                            <div className="flex items-start justify-between gap-4">

                                                <div className="flex-1">

                                                    <span className="text-xs text-(--text-muted)">
                                                        BLOG #{String(index + 1).padStart(2, "0")}
                                                    </span>

                                                    <h2 className="text-xl font-bold mt-2 text-(--text)">
                                                        {blog.title}
                                                    </h2>

                                                    <p className="text-sm text-(--text-muted) mt-3 line-clamp-2">
                                                        {blog.description}
                                                    </p>

                                                    <div className="mt-4 pt-4 border-t border-(--border)">
                                                        <span className="text-xs text-(--text-muted)">
                                                            📅 {blog.date}
                                                        </span>
                                                    </div>

                                                </div>

                                            </div>

                                        </motion.div>
                                    ))}

                                </div>
                            ) : (
                                <div className="grid gap-4 max-h-[600px] overflow-y-auto pr-2">
                                    {notes.map((note, index) => (
                                        <motion.div
                                            key={note.id}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{
                                                duration: 0.3,
                                                delay: index * 0.05
                                            }}
                                            className="glass rounded-2xl p-5"
                                        >

                                            <div className="flex gap-4">

                                                <img
                                                    src={`/notes/img/${note.image}`}
                                                    alt={note.title}
                                                    className="w-24 h-24 rounded-xl object-cover border border-(--border) flex-shrink-0"
                                                />

                                                <div className="flex-1 min-w-0">

                                                    <span className="text-xs text-(--text-muted)">
                                                        NOTE #{String(index + 1).padStart(2, "0")}
                                                    </span>

                                                    <h2 className="text-lg font-bold mt-2 text-(--text)">
                                                        {note.title}
                                                    </h2>

                                                    <p className="text-sm text-(--text-muted) mt-2 line-clamp-2">
                                                        {note.description}
                                                    </p>

                                                </div>

                                            </div>

                                        </motion.div>
                                    ))}

                                </div>
                            )
                        }
                        {/* yahan pr khtam hua */}
                    </motion.div>

                </AnimatePresence>
            </div>


            {/* Pulse animation */}
            <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50%       { opacity: 0.5; transform: scale(0.85); }
        }
        @media (max-width: 768px) {
          .dashboard-bottom-row {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
        </div>
    );
}