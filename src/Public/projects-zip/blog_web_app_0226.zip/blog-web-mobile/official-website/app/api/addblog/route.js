export async function POST(req) {
    const formData = await req.json()
    const backendRes = await fetch(
        `https://devzaidbackend.onrender.com/api/content/postblog/`,
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                ...formData,
                verifypass: process.env.VERIFYPASS
            }),
        }
    );

    const data = await backendRes.json();

    return Response.json(data, {
        status: backendRes.status,
    });
}