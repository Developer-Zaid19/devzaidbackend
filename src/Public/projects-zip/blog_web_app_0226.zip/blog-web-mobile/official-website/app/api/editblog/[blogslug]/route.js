export async function PUT(req, { params }) {
    const { blogslug } = await params;
    const formdata = await req.json();

    const backendRes = await fetch(
        `https://devzaidbackend.onrender.com/api/content/updateblog/${blogslug}`,
        {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                verifypass: process.env.VERIFYPASS,
                ...formdata
            }),
        }
    );

    const data = await backendRes.json();

    return Response.json(data, {
        status: backendRes.status,
    });
}