export async function DELETE(req, { params }) {
    const { blogslug } = await params;

    const backendRes = await fetch(
        `https://devzaidbackend.onrender.com/api/content/deleteblog/${blogslug}`,
        {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                verifypass: process.env.VERIFYPASS,
            }),
        }
    );

    const data = await backendRes.json();

    return Response.json(data, {
        status: backendRes.status,
    });
}