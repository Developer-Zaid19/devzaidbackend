package com.example.admindevzaid.ContentManager

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.admindevzaid.BuildConfig

@Composable
fun BlogUploadScreen() {

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val verifypass = BuildConfig.VERIFYPASS


    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var paragraph1 by remember { mutableStateOf("") }
    var paragraph2 by remember { mutableStateOf("") }
    var paragraph3 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Upload Blog",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.headlineMedium,
         color = MaterialTheme.colorScheme.primary)

        OutlinedTextField(

    colors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MaterialTheme.colorScheme.surface,
    unfocusedTextColor = MaterialTheme.colorScheme.surface,
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.primary,
    cursorColor = MaterialTheme.colorScheme.primary,
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.primary
    ),


            value = title,
            onValueChange = { title = it },
            label = { Text("Blog Title", color = MaterialTheme.colorScheme.primary
) },
            modifier = Modifier.fillMaxWidth()
        )


        OutlinedTextField(

    colors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MaterialTheme.colorScheme.surface,
    unfocusedTextColor = MaterialTheme.colorScheme.surface,
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.primary,
    cursorColor = MaterialTheme.colorScheme.primary,
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.primary
    ),


            value = description,
            onValueChange = { description = it },
            label = { Text("Short Description" , color = MaterialTheme.colorScheme.primary) },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(

    colors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MaterialTheme.colorScheme.surface,
    unfocusedTextColor = MaterialTheme.colorScheme.surface,
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.primary,
    cursorColor = MaterialTheme.colorScheme.primary,
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.primary
    ),


            value = paragraph1,
            onValueChange = { paragraph1 = it },
            label = { Text("Paragraph 1" , color = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        )

        OutlinedTextField(

    colors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MaterialTheme.colorScheme.surface,
    unfocusedTextColor = MaterialTheme.colorScheme.surface,
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.primary,
    cursorColor = MaterialTheme.colorScheme.primary,
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.primary
    ),


            value = paragraph2,
            onValueChange = { paragraph2 = it },
            label = { Text("paragraph 2" , color = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        )

        OutlinedTextField(

    colors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = MaterialTheme.colorScheme.surface,
    unfocusedTextColor = MaterialTheme.colorScheme.surface,
    focusedLabelColor = MaterialTheme.colorScheme.primary,
    unfocusedLabelColor = MaterialTheme.colorScheme.primary,
    cursorColor = MaterialTheme.colorScheme.primary,
    focusedBorderColor = MaterialTheme.colorScheme.primary,
    unfocusedBorderColor = MaterialTheme.colorScheme.primary
    ),


            value = paragraph3,
            onValueChange = { paragraph3 = it },
            label = { Text("paragraph 3" , color = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        )




        Button(
            colors = ButtonDefaults.buttonColors(
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.surface
    ),
            onClick = {
                if (
                    (title.isBlank() ||
                    description.isBlank()) ||
                    ( paragraph1.isBlank() &&
                    paragraph2.isBlank() &&
                    paragraph3.isBlank())
                ) {
                    Toast.makeText(context, "All fields required or minimum 1 paragraph", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                scope.launch {
                    try {
                        val response = RetrofitClient.api.uploadBlog(
                            BlogRequest(
                                verifypass = verifypass,
                                title = title,
                                description = description,
                                content = paragraph1, // UI para1 → backend content
                                para1 = paragraph2,
                                para2 = paragraph3
                            )
                        )

                        if (response.isSuccessful) {
                            Toast.makeText(context, "Blog uploaded ✅", Toast.LENGTH_LONG).show()

                            // clear fields
                            title = ""
                            description = ""
                            paragraph1 = ""
                            paragraph2 = ""
                            paragraph3 = ""

                        } else {
                            Toast.makeText(
                                context,
                                "Upload failed ❌ (wrong password or server error)",
                                Toast.LENGTH_LONG
                            ).show()
                        }

                    } catch (e: Exception) {
                        Toast.makeText(
                            context,
                            "Network error: ${e.localizedMessage}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Upload Blog")
        }

    }
}
