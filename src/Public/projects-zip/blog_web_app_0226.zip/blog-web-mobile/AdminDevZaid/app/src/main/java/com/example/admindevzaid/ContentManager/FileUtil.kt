package com.example.admindevzaid.ContentManager

import android.content.Context
import android.net.Uri
import java.io.File

object FileUtil {
    fun fromUri(context: Context, uri: Uri): File {
        val inputStream = context.contentResolver.openInputStream(uri)!!
        val tempFile = File(context.cacheDir, "tempPdf_${System.currentTimeMillis()}.pdf")
        inputStream.use { input -> tempFile.outputStream().use { output -> input.copyTo(output) } }
        return tempFile
    }
}
