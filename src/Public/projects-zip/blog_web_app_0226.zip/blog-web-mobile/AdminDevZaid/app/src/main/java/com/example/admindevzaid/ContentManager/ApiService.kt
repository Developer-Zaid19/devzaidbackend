package com.example.admindevzaid.ContentManager

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {

    @POST("api/content/postblog")
    suspend fun uploadBlog(
        @Body blogRequest: BlogRequest
    ): Response<Map<String, Any>>

    @Multipart
    @POST("/api/content/postnote")
    suspend fun uploadNotes(
        @Part("verifypass") verifypass: RequestBody,
        @Part("title") title: RequestBody,
        @Part("category") category: RequestBody,
        @Part pdf: MultipartBody.Part?
    ): Response<Map<String, Any>>


}