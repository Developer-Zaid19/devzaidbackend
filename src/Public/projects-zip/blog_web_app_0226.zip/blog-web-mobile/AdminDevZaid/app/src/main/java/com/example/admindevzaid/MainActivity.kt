package com.example.admindevzaid

import android.os.Bundle
import androidx.compose.ui.Modifier
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.admindevzaid.ContentManager.BlogUploadScreen
import com.example.admindevzaid.ContentManager.NotesUploadScreen
import com.example.admindevzaid.ui.theme.AdminDevZaidTheme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdminDevZaidTheme() {

                val navController = rememberNavController()

                Scaffold(
                    bottomBar = {
                        BottomNavigationBar(navController)
                    }
                ) { paddingValues ->

                    NavHost(
                        navController = navController,
                        startDestination = Screen.Blog.route,
                        modifier = Modifier.padding(paddingValues)
                    ) {

                        composable(Screen.Blog.route) {
                            BlogUploadScreen()
                        }

                        composable(Screen.Notes.route) {
                            NotesUploadScreen()
                        }
                    }
                }
            }
        }


    }
}


@Preview(showBackground = true)
@Composable
fun BottomNavPreview() {
    val navController = rememberNavController()
    BottomNavigationBar(navController)
}