package com.example.admindevzaid.ContentManager

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.admindevzaid.BuildConfig
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody

@Composable
fun NotesUploadScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val verifypass = BuildConfig.VERIFYPASS

    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var selectedPdfUri by remember { mutableStateOf<Uri?>(null) }

    // PDF picker launcher
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                selectedPdfUri = uri
            }
        }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        Text(
            "Upload Notes",
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )

        // Notes Title
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Notes Title", color = MaterialTheme.colorScheme.primary) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = MaterialTheme.colorScheme.surface,
                unfocusedTextColor = MaterialTheme.colorScheme.surface,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.fillMaxWidth()
        )

        // Category
        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category of Document", color = MaterialTheme.colorScheme.primary) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = MaterialTheme.colorScheme.surface,
                unfocusedTextColor = MaterialTheme.colorScheme.surface,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.primary,
                cursorColor = MaterialTheme.colorScheme.primary,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.primary
            ),
            modifier = Modifier.fillMaxWidth()
        )

        // PDF Upload Button
        Button(onClick = { pdfPickerLauncher.launch(arrayOf("application/pdf")) }) {
            Text(text = if (selectedPdfUri != null) "PDF Selected" else "Upload PDF")
        }

        // Submit Button
        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.surface
            ),
            onClick = {
                if (title.isBlank() || category.isBlank()) {
                    Toast.makeText(context, "All fields required", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                scope.launch {
                    try {
                        val filePart = selectedPdfUri?.let { uri ->
                            val file = FileUtil.fromUri(context, uri)
                            val requestFile =
                                file.asRequestBody("application/pdf".toMediaTypeOrNull())
                            MultipartBody.Part.createFormData("file", file.name, requestFile)
                        }

                        val response = RetrofitClient.api.uploadNotes(
                            verifypass.toRequestBody("text/plain".toMediaTypeOrNull()),
                            title.toRequestBody("text/plain".toMediaTypeOrNull()),
                            category.toRequestBody("text/plain".toMediaTypeOrNull()),
                            filePart
                        )

                        if (response.isSuccessful) {
                            Toast.makeText(context, "Document uploaded ✅", Toast.LENGTH_LONG)
                                .show()
                            title = ""
                            category = ""
                            selectedPdfUri = null
                        } else {
                            Toast.makeText(context, "Upload failed ❌", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        Toast.makeText(
                            context,
                            "Network error: ${e.localizedMessage}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Upload Document")
        }

    }
}
