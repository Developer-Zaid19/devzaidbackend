package com.example.admindevzaid.ui.theme

import androidx.compose.ui.graphics.Color

//<color name="hadding">#FF00BCFF</color>
//<color name="focus">#FF3766d1</color>
//<color name="bg">#FF0A1326</color>
//<color name="text">#FFF1F5F9</color>
//<color name="border">#FF343a41</color>
//<color name="err">#FFFF0000</color>
//<color name="bgt">#FF141414</color>

val hadding = Color(0xFF00BCFF)
val focus = Color(0xFF3766d1)
val bg = Color(0xFF0A1326)
val text = Color(0xFFF1F5F9)
val border = Color(0xFF343a41)
val err = Color(0xFFFF0000)
val bgt = Color(0xFF141414)