package com.example.admindevzaid

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBox
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController

@Composable
fun BottomNavigationBar(navController: NavController) {

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        modifier = Modifier.fillMaxWidth().height(60.dp),
        containerColor = MaterialTheme.colorScheme.background,
    ) {

        NavigationBarItem(
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                unselectedTextColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            ),

            selected = currentRoute == Screen.Blog.route,
            onClick = {
                navController.navigate(Screen.Blog.route) {
                    popUpTo(Screen.Blog.route) { inclusive = false }
                    launchSingleTop = true
                }
            },
            icon = { Icon(Icons.Default.Create, contentDescription = "Blog") },
            label = { Text("Blog") }
        )

        NavigationBarItem(
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                unselectedTextColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            ),

            selected = currentRoute == Screen.Notes.route,
            onClick = {
                navController.navigate(Screen.Notes.route) {
                    popUpTo(Screen.Blog.route)
                    launchSingleTop = true
                }
            },
            icon = { Icon(Icons.Default.Menu, contentDescription = "Notes") },
            label = { Text("Notes") }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun BottomNavPryeview() {
    val navController = rememberNavController()
    BottomNavigationBar(navController)
}