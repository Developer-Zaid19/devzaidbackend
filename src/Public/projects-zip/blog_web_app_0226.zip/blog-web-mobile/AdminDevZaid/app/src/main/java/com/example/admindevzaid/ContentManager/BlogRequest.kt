package com.example.admindevzaid.ContentManager

data class BlogRequest(
    val verifypass: String,
    val title: String,
    val description: String,
    val content: String,
    val para1: String,
    val para2: String,
)
