package com.example.admindevzaid

sealed class Screen(val route: String) {
    object Blog : Screen("blog")
    object Notes : Screen("notes")
}
