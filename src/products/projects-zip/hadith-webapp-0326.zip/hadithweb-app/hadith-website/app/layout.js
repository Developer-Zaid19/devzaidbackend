// Layout.js

import { Amiri, DM_Sans, Syne } from "next/font/google";
import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import { LoadingProvider } from "./context/LoadingContext";
import "./globals.css";

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-dm-sans",
});

const amiri = Amiri({
  subsets: ["arabic", "latin"],
  weight: ["400", "700"],
  variable: "--font-amiri",
});

const syne = Syne({
  subsets: ["latin"],
  variable: "--font-syne",
});

export const metadata = {
  title: "MyHadith - Find Hadith Clearly",
  description:
    "Search, read, and explore authentic hadiths from major collections through a polished multi-page web experience.",
  keywords: ["hadith", "islamic app", "bukhari", "muslim", "quran", "sunnah", "myhadith"],
  // icons: { icon: "/favicon.png" },
  openGraph: {
    title: "MyHadith - Find Hadith Clearly",
    description: "Search, read, and explore hadiths from authentic collections anytime, anywhere.",
    type: "website",
  },
  icons: {
    icon: "/icon.png",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${dmSans.variable} ${amiri.variable} ${syne.variable} bg-[var(--dark)] font-[family-name:var(--font-dm-sans)] text-[var(--text)] antialiased`}
        style={{ fontOpticalSizing: "auto" }}
      >
        <LoadingProvider>
          <div className="site-bg min-h-screen">
            <Navbar />
            {children}
            <Footer />
          </div>
        </LoadingProvider>
      </body>
    </html>
  );
}
