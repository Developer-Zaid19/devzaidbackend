// Footer.js

import Link from "next/link";
import { Github, Instagram, Linkedin, Mail, Youtube } from "lucide-react";

const links = [
  { name: "Home", href: "/" },
  { name: "Books", href: "/books" },
  { name: "Download", href: "/download" },
  { name: "Opensource", href: "/open-source" },
  { name: "Contact", href: "/contact" },
];

const socials = [
  { href: "https://youtube.com/@Developer-zaid", label: "YouTube", icon: Youtube },
  { href: "https://instagram.com/dvlprzaid", label: "Instagram", icon: Instagram },
  { href: "https://linkedin.com/in/developer-zaid29", label: "LinkedIn", icon: Linkedin },
  { href: "https://github.com/Developer-Zaid19", label: "GitHub", icon: Github },
  { href: "mailto:developerzaid26@gmail.com", label: "Email", icon: Mail },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-[var(--border)] bg-[rgba(2,10,22,0.92)]">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div className="space-y-4">
          <div>
            <div className="font-[family-name:var(--font-amiri)] text-3xl text-[var(--gold)]">MyHadith</div>
            <p className="mt-3 max-w-md text-sm leading-7 text-[var(--text-dim)]">
              This project has been designed to bring authentic Hadith collections into a simple, searchable, and beautifully readable web experience.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            {socials.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target={social.href.startsWith("http") ? "_blank" : undefined}
                  rel={social.href.startsWith("http") ? "noreferrer" : undefined}
                  className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-[var(--text-dim)] transition hover:border-[var(--border-strong)] hover:text-[var(--gold)]"
                  aria-label={social.label}
                >
                  <Icon size={18} />
                </a>
              );
            })}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.24em] text-[var(--gold)]">Navigate</h3>
          <div className="mt-5 flex flex-col gap-3">
            {links.map((link) => (
              <Link key={link.href} href={link.href} className="text-sm text-[var(--text-dim)] transition hover:text-white">
                {link.name}
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-[0.24em] text-[var(--gold)]">Highlights</h3>
          <div className="mt-5 space-y-3 text-sm text-[var(--text-dim)]">
            <p>7 major hadith books in one place</p>
            <p>Search by book and hadith number</p>
            <p>Arabic, Urdu, English language views</p>
            <p>APK showcase and direct download page</p>
          </div>
        </div>
      </div>

      <div className="border-t border-[var(--border)] px-4 py-5 text-center text-xs text-[var(--text-dim)] sm:px-6 lg:px-8">
        Copyright {new Date().getFullYear()} MyHadith. Crafted by Developer Zaid.
      </div>
    </footer>
  );
}
