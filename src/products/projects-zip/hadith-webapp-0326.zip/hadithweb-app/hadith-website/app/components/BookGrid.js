// component/BookGrid.js

import Link from "next/link";

export default function BookGrid({ books }) {
  return (
    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
      {books.map((book) => (
        <Link key={book.slug} href={`/books/${book.slug}`} className="surface-panel group p-6 transition hover:-translate-y-1">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.26em] text-[var(--gold)]">{book.shortName}</p>
              <h3 className="mt-3 text-2xl font-semibold text-white">{book.name}</h3>
            </div>
            <div className="rounded-full border border-[var(--border)] px-3 py-1 text-xs text-[var(--text-dim)]">
              {book.totalHadith} hadith
            </div>
          </div>

          <p className="mt-4 text-sm leading-7 text-[var(--text-dim)]">
            Compiled by {book.writer}
            {book.writerDeath ? ` • ${book.writerDeath}` : ""}
          </p>

          <div className="mt-6 flex flex-wrap gap-2">
            {book.preview.slice(0, 3).map((hadith) => (
              <span key={`${book.slug}-${hadith.id || hadith.hadithNumber}`} className="pill">
                #{hadith.hadithNumber}
              </span>
            ))}
          </div>

          <p className="mt-6 text-sm font-medium text-[var(--gold)]">Open collection</p>
        </Link>
      ))}
    </div>
  );
}
