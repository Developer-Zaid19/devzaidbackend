
"use client";

import Link from "next/link";
import { Search } from "lucide-react";
import { useState } from "react";
import HadithCard from "./HadithCard";

export default function HadithSearch({ books, randomHadith = null }) {
  const [bookslug, setbookslug] = useState(books[0]?.slug ?? "");
  const [hadithnumber, sethadithnumber] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const displayedHadith = result ?? randomHadith;


  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const response = await fetch(
        `/api/hadith?bookslug=${encodeURIComponent(bookslug)}&hadithnumber=${encodeURIComponent(hadithnumber)}`
      );
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Hadith not found");
      }
      setResult(data);
    } catch (submissionError) {

      setError(submissionError.message);
    } finally {
      
      setLoading(false);
    }
  }

  return (
    <div className="surface-panel flex h-full flex-col p-5 sm:p-7">
      <div className="flex items-center gap-3">
        <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-[rgba(212,175,55,0.1)] text-[var(--gold)]">
          <Search size={18} />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-white sm:text-2xl">Hadith Search</h2>
          <p className="text-sm text-[var(--text-dim)]">
            Select a book, enter a hadith number, and see the result instantly.
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-5 grid gap-4 md:mt-6 md:grid-cols-[1fr_1fr_auto]">
        <label className="space-y-2">
          <span className="text-sm text-[var(--text-soft)]">Book</span>
          <select
            className="form-select text-sm"
            value={bookslug}
            onChange={(event) => setbookslug(event.target.value)}
          >
            {books.map((item) => (
              <option key={item.slug} value={item.slug}>
                {item.name}
              </option>
            ))}
          </select>
        </label>

        <label className="space-y-2">
          <span className="text-sm text-[var(--text-soft)]">Hadith Number</span>
          <input
            type="number"
            min="1"
            className="w-full rounded-2xl border border-[var(--border)] bg-[rgba(255,255,255,0.03)] px-4 py-3 text-sm text-white outline-none placeholder:text-[var(--text-dim)] min-h-12"
            placeholder="e.g. 1"
            value={hadithnumber}
            onChange={(event) => sethadithnumber(event.target.value)}
          />
        </label>

        <button
          type="submit"
          className="btn-primary mt-1 min-h-12 justify-center px-6 py-3.5 text-sm md:mt-7"
          disabled={loading}
        >
          {loading ? "Searching..." : "Find Hadith"}
        </button>
      </form>

      {error ? <p className="mt-4 text-sm text-[#ffb4a8]">{error}</p> : null}

      {displayedHadith ? (
        <div className="mt-8 flex min-h-0 flex-1 flex-col space-y-4">
          <HadithCard
            hadith={displayedHadith}
            preview
            href={`/books/${displayedHadith.bookSlug}/${displayedHadith.hadithNumber}`}
          />
        </div>
      ) : null}
    </div>
  );
}
