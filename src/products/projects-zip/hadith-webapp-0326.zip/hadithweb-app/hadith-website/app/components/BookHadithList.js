"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ChevronDown } from "lucide-react";
import Loader from "../components/Loader";

const PAGE_SIZE = 20;

export default function BookHadithList({ slug }) {
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  // Reset when book changes
  useEffect(() => {
    setItems([]);
    setPage(1);
    setHasMore(true);
  }, [slug]);

  useEffect(() => {
    const loadMoreHadiths = async () => {
      try {
        setLoading(true);

        const response = await fetch(
          `/api/hadithlist?bookslug=${encodeURIComponent(
            slug
          )}&page=${page}`
        );

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error || "Failed to load hadiths");
        }

        const newHadiths = data.hadiths || [];

        if (page === 1) {
          setItems(newHadiths);
        } else {
          setItems((prev) => [...prev, ...newHadiths]);
        }

        setHasMore(newHadiths.length === PAGE_SIZE);
      } catch (error) {
        console.error("Failed to load more hadiths:", error);
      } finally {
        setLoading(false);
      }
    };

    if (slug) {
      loadMoreHadiths();
    }
  }, [page, slug]);

  const shown = items;

  // Optional full-page loader for first load
  // if (loading && page === 1 && shown.length === 0) {
  //   return <Loader />;
  // }

  return (
    <div className="space-y-5">
      <div className="grid gap-5">
        {shown.map((hadith) => (
          <Link
            key={`${slug}-${hadith.id || hadith.hadithNumber}`}
            href={`/books/${slug}/${hadith.hadithNumber}`}
            className="surface-panel p-6 transition hover:-translate-y-1"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-xs uppercase tracking-[0.26em] text-[var(--gold)]">
                  Hadith #{hadith.hadithNumber}
                </p>

                {hadith.headingEnglish ||
                hadith.headingUrdu ||
                hadith.headingArabic ? (
                  <h3 className="mt-2 text-xl font-semibold text-white">
                    {hadith.headingEnglish ||
                      hadith.headingUrdu ||
                      hadith.headingArabic}
                  </h3>
                ) : null}
              </div>

              {hadith.chapterEnglish ||
              hadith.chapterUrdu ||
              hadith.chapterArabic ? (
                <span className="pill text-xs">
                  {hadith.chapterEnglish ||
                    hadith.chapterUrdu ||
                    hadith.chapterArabic}
                </span>
              ) : null}
            </div>

            <p className="mt-4 line-clamp-4 text-sm leading-7 text-[var(--text-dim)]">
              {hadith.hadithEnglish || hadith.hadithArabic || hadith.hadithUrdu}
            </p>

            <p className="mt-5 text-sm font-medium text-[var(--gold)]">
              Read full hadith →
            </p>
          </Link>
        ))}
      </div>

      {hasMore && (
        <div className="flex flex-col items-center gap-3 pt-4">
          <p className="text-xs text-[var(--text-dim)]">
            Showing {shown.length} hadiths
          </p>

          <button
            type="button"
            onClick={() => setPage((prev) => prev + 1)}
            disabled={loading}
            className="btn-outline flex items-center gap-2 px-6 py-3 text-sm"
          >
            <ChevronDown size={16} />
            {loading ? "Loading..." : "Load 20 more hadiths"}
          </button>
        </div>
      )}

      {!hasMore && shown.length > PAGE_SIZE && (
        <p className="pt-2 text-center text-xs text-[var(--text-dim)]">
          All available hadiths loaded.
        </p>
      )}
    </div>
  );
}