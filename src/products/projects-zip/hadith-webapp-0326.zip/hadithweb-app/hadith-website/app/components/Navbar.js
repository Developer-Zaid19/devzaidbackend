// Navber.js

"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import appIcon from "../favicon.png";

const navLinks = [
  { name: "Home", href: "/" },
  { name: "Books", href: "/books" },
  { name: "Download", href: "/download" },
  { name: "Open Source", href: "/open-source" },
  { name: "Contact", href: "/contact" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--border)] bg-[rgba(3,15,30,0.82)] backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="flex min-w-0 items-center gap-3">
          <Image src={appIcon} alt="MyHadith logo" className="h-10 w-10 rounded-2xl border border-[var(--border)] sm:h-11 sm:w-11" />
          <div>
            <div className="font-[family-name:var(--font-amiri)] text-lg text-[var(--gold)] sm:text-xl">MyHadith</div>
            <div className="text-[9px] uppercase tracking-[0.24em] text-[var(--text-dim)] sm:text-[10px] sm:tracking-[0.3em]">
              Hadith Explorer
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-2 lg:flex">
          {navLinks.map((link) => {
            const active = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-full px-4 py-2 text-sm transition ${
                  active
                    ? "bg-[rgba(212,175,55,0.14)] text-[var(--gold)]"
                    : "text-[var(--text-dim)] hover:bg-[rgba(255,255,255,0.04)] hover:text-white"
                }`}
              >
                {link.name}
              </Link>
            );
          })}
        </nav>

        <div className="hidden lg:block">
          <Link href="/download" className="btn-primary px-5 py-3 text-sm">
            Download APK
          </Link>
        </div>

        <button
          type="button"
          className="inline-flex rounded-full border border-[var(--border)] p-2 text-[var(--gold)] lg:hidden"
          onClick={() => setOpen((value) => !value)}
          aria-label="Toggle navigation"
          aria-expanded={open}
          aria-controls="mobile-nav"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open ? (
        <div
          id="mobile-nav"
          className="border-t border-[var(--border)] bg-[rgba(3,15,30,0.98)] px-4 py-4 shadow-[0_18px_40px_rgba(0,0,0,0.35)] lg:hidden"
        >
          <nav className="mx-auto flex max-w-7xl flex-col gap-2">
            {navLinks.map((link) => {
              const active = pathname === link.href || (link.href !== "/" && pathname.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className={`rounded-2xl px-4 py-3.5 text-sm ${
                    active
                      ? "bg-[rgba(212,175,55,0.14)] text-[var(--gold)]"
                      : "text-[var(--text-dim)] hover:bg-[rgba(255,255,255,0.04)] hover:text-white"
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
            <Link href="/download" className="btn-primary mt-3 w-full px-5 py-3 text-sm" onClick={() => setOpen(false)}>
              Download APK
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
