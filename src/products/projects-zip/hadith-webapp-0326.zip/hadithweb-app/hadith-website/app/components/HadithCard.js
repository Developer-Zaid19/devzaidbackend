// components/HadithCard.js

"use client";

import { Copy, Check } from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";

const languages = [
  { key: "english", label: "English" },
  { key: "urdu", label: "Urdu" },
  { key: "arabic", label: "Arabic" },
];

function getContent(hadith, language) {
  if (language === "urdu") {
    return {
      heading: hadith.headingUrdu || hadith.headingEnglish || hadith.headingArabic,
      narrator: hadith.narratorUrdu || hadith.narratorEnglish,
      body: hadith.hadithUrdu || hadith.hadithEnglish,
      chapter: hadith.chapterUrdu || hadith.chapterEnglish || hadith.chapterArabic,
    };
  }

  if (language === "arabic") {
    return {
      heading: hadith.headingArabic || hadith.headingEnglish || hadith.headingUrdu,
      narrator: hadith.narratorEnglish,
      body: hadith.hadithArabic || hadith.hadithEnglish,
      chapter: hadith.chapterArabic || hadith.chapterEnglish || hadith.chapterUrdu,
    };
  }

  return {
    heading: hadith.headingEnglish || hadith.headingUrdu || hadith.headingArabic,
    narrator: hadith.narratorEnglish || hadith.narratorUrdu,
    body: hadith.hadithEnglish || hadith.hadithUrdu,
    chapter: hadith.chapterEnglish || hadith.chapterUrdu || hadith.chapterArabic,
  };
}

export default function HadithCard({
  hadith,
  defaultLanguage = "urdu",
  full = false,
  compact = false,
  preview = false,
  href = "",
}) {
  const router = useRouter();
  const [language, setLanguage] = useState(defaultLanguage);
  const [copied, setCopied] = useState(false);
  const content = useMemo(() => getContent(hadith, language), [hadith, language]);
  const isRtlLanguage = language === "arabic" || language === "urdu";
  const textAlignClass = isRtlLanguage ? "text-right" : "text-left";

  async function handleCopy() {
    const payload = [
      `Book: ${hadith.bookName}`,
      `Hadith Number: ${hadith.hadithNumber}`,
      hadith.hadithArabic ? `Arabic:\n${hadith.hadithArabic}` : null,
      hadith.hadithUrdu ? `Urdu:\n${hadith.hadithUrdu}` : null,
      hadith.hadithEnglish ? `English:\n${hadith.hadithEnglish}` : null,
    ]
      .filter(Boolean)
      .join("\n\n");

    await navigator.clipboard.writeText(payload);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  }

  return (
    <article
      className={`surface-panel flex h-full flex-col ${compact ? "p-5" : "p-6 sm:p-7"} ${
        preview && href ? "cursor-pointer" : ""
      }`}
      onClick={() => {
        if (preview && href) {
          router.push(href);
        }
      }}
    >
      <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between">
        <div >
          <p className="text-xs uppercase tracking-[0.26em] text-[var(--gold)]">{hadith.bookName}</p>
          <h3 className="mt-2 text-xl font-semibold text-white">Hadith #{hadith.hadithNumber}</h3>
          {content.chapter ? (
            <p className={`mt-2 text-sm text-[var(--text-dim)] `}>{content.chapter}</p>
          ) : null}
        </div>

        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
          <select
            className="form-select w-full min-w-0 rounded-2xl px-4 py-2 text-sm sm:min-w-[140px] sm:w-auto sm:rounded-full"
            value={language}
            onChange={(event) => setLanguage(event.target.value)}
            onClick={(event) => event.stopPropagation()}
          >
            {languages.map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>

          <button
            type="button"
            className="btn-outline min-h-12 w-full px-4 py-2.5 text-sm sm:w-auto"
            onClick={(event) => {
              event.stopPropagation();
              handleCopy();
            }}
          >
            {copied ? <Check size={16} /> : <Copy size={16} />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>

      {content.heading ? (
        <p className={`mt-6 text-base font-semibold text-[var(--gold-light)] ${textAlignClass}`}>
          {content.heading}
        </p>
      ) : null}

      {content.narrator ? (
        <p className={`mt-4 text-sm font-medium text-[var(--text-soft)] ${textAlignClass}`}>
          {content.narrator}
        </p>
      ) : null}

      <p
        className={`mt-4 whitespace-pre-line leading-8 text-[var(--text)] ${
          language === "arabic"
            ? "font-[family-name:var(--font-amiri)] text-2xl leading-[2.2]"
            : language === "urdu"
              ? "text-lg leading-9 sm:text-[1.15rem]"
              : "text-[15px] sm:text-base"
        } ${full ? "" : preview ? "line-clamp-[14]" : "line-clamp-6"} ${textAlignClass} ${
          preview ? "overflow-hidden" : ""
        }`}
        dir={isRtlLanguage ? "rtl" : "ltr"}
      >
        {content.body || "Hadith text is not available."}
      </p>

      <div className="mt-auto pt-6">
        <div
          className={`flex flex-wrap gap-3 text-xs text-[var(--text-dim)] ${
            isRtlLanguage ? "justify-end" : "justify-start"
          }`}
        >
          {hadith.status ? <span className="pill">{hadith.status}</span> : null}
          {hadith.chapterNumber ? <span className="pill">Chapter {hadith.chapterNumber}</span> : null}
          {hadith.volume ? <span className="pill">Volume {hadith.volume}</span> : null}
        </div>
      </div>
    </article>
  );
}
