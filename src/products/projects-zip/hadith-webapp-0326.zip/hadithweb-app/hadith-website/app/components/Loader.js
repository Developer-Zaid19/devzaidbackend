import React from 'react';
import styled from 'styled-components';

const Loader = () => {
  return (
    <StyledWrapper>
      <div className="loader-overlay">
        <div className="loader-content">
          <div className="loader">
            <div className="loader-square" />
            <div className="loader-square" />
            <div className="loader-square" />
            <div className="loader-square" />
            <div className="loader-square" />
            <div className="loader-square" />
            <div className="loader-square" />
          </div>
          <p className="loader-text">Loading...</p>
        </div>
      </div>
    </StyledWrapper>
  );
}

const StyledWrapper = styled.div`
  .loader-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(4, 16, 29, 0.95);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    animation: fadeIn 0.2s ease-in;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  .loader-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 24px;
  }

  .loader-text {
    color: var(--gold, #d4af37);
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.1em;
    margin: 0;
    animation: pulse 1.5s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% {
      opacity: 0.6;
    }
    50% {
      opacity: 1;
    }
  }

  @keyframes square-animation {
   0% {
    left: 0;
    top: 0;
   }

   10.5% {
    left: 0;
    top: 0;
   }

   12.5% {
    left: 32px;
    top: 0;
   }

   23% {
    left: 32px;
    top: 0;
   }

   25% {
    left: 64px;
    top: 0;
   }

   35.5% {
    left: 64px;
    top: 0;
   }

   37.5% {
    left: 64px;
    top: 32px;
   }

   48% {
    left: 64px;
    top: 32px;
   }

   50% {
    left: 32px;
    top: 32px;
   }

   60.5% {
    left: 32px;
    top: 32px;
   }

   62.5% {
    left: 32px;
    top: 64px;
   }

   73% {
    left: 32px;
    top: 64px;
   }

   75% {
    left: 0;
    top: 64px;
   }

   85.5% {
    left: 0;
    top: 64px;
   }

   87.5% {
    left: 0;
    top: 32px;
   }

   98% {
    left: 0;
    top: 32px;
   }

   100% {
    left: 0;
    top: 0;
   }
  }

  .loader {
   position: relative;
   width: 96px;
   height: 96px;
   transform: rotate(45deg);
  }

  .loader-square {
   position: absolute;
   top: 0;
   left: 0;
   width: 28px;
   height: 28px;
   margin: 2px;
   border-radius: 0px;
   background: #d4af37;
   background-size: cover;
   background-position: center;
   background-attachment: fixed;
   animation: square-animation 10s ease-in-out infinite both;
  }

  .loader-square:nth-of-type(1) {
   animation-delay: 0s;
  }

  .loader-square:nth-of-type(2) {
   animation-delay: -1.4285714286s;
  }

  .loader-square:nth-of-type(3) {
   animation-delay: -2.8571428571s;
  }

  .loader-square:nth-of-type(4) {
   animation-delay: -4.2857142857s;
  }

  .loader-square:nth-of-type(5) {
   animation-delay: -5.7142857143s;
  }

  .loader-square:nth-of-type(6) {
   animation-delay: -7.1428571429s;
  }

  .loader-square:nth-of-type(7) {
   animation-delay: -8.5714285714s;
  }
`;

export default Loader;
