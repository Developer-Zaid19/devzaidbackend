// components/HomePageContent.js

import Link from "next/link";
import { BookOpen, Download } from "lucide-react";
import HadithSearch from "./HadithSearch";

const featureItems = [
  {
    title: "Instant search",
    description: "Select a book from the home page, enter a hadith number, and get the result immediately.",
  },
  {
    title: "Readable detail pages",
    description: "Every hadith has its own page with full text, language switching, and a one-click copy action.",
  },
  {
    title: "Seven trusted books",
    description: "Bukhari, Muslim, Tirmidhi, Nasai, Abu Dawood, Ibn Majah, and Mishkat — all in one flow.",
  },
];

export default function HomePageContent({ books, randomHadith }) {
  return (
    <main>
      <section className="page-shell pt-8 sm:pt-12 lg:pt-16">
        <div className="grid gap-8 xl:grid-cols-[1.15fr_0.85fr] mb-5">
          <div className="order-2 mainbox surface-panel hero-panel p-6 sm:p-8 lg:p-12 xl:order-1">
            <div className="section-tag">MyHadith Web Experience</div>
            <h1 className="section-title max-w-3xl">
              Search, explore, and read hadith in a cleaner multi-page experience.
            </h1>
            <p className="section-sub">
              The website is organised into dedicated pages — books, download, about, contact, and open source — each on its own route. Search and random hadith discovery are front and centre on the home page.
            </p>

            <div className="mt-6 flex flex-col gap-3 sm:mt-8 sm:flex-row sm:flex-wrap sm:gap-4">
              <Link href="/books" className="btn-primary w-full sm:w-auto">
                <BookOpen size={18} />
                Explore Books
              </Link>
              <Link href="/download" className="btn-outline w-full sm:w-auto">
                <Download size={18} />
                Download APK
              </Link>
            </div>

            <div className="mt-6 grid gap-3 sm:mt-8 md:grid-cols-3 md:gap-4">
              {featureItems.map((item) => (
                <div
                  key={item.title}
                  className="rounded-[22px] border border-[var(--border)] bg-[rgba(255,255,255,0.03)] p-4 sm:p-5"
                >
                  <h3 className="text-base font-semibold text-white">{item.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-[var(--text-dim)]">{item.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="order-1 space-y-6 xl:order-2 xl:flex xl:h-full xl:flex-col xl:space-y-8">
            <HadithSearch books={books} randomHadith={randomHadith} />
            {!randomHadith ? (
              <div className="surface-panel p-7 text-sm leading-8 text-[var(--text-dim)]">
                Random hadith could not be loaded right now. Browse the books page to explore collections.
              </div>
            ) : null}
          </div>
        </div>
      </section>
    </main>
  );
}
