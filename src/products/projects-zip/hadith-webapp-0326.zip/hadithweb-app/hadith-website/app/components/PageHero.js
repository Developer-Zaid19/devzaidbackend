// PageHero.js

export default function PageHero({ eyebrow, title, description, actions, align = "left" }) {
  const alignment = align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl";

  return (
    <section className="page-shell pt-16">
      <div className={`surface-panel relative overflow-hidden p-8 sm:p-10 lg:p-14 ${alignment}`}>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.14),transparent_38%)]" />
        <div className="relative">
          <div className="section-tag justify-start">{eyebrow}</div>
          <h1 className="section-title">{title}</h1>
          <p className="section-sub max-w-2xl">{description}</p>
          {actions ? <div className={`mt-8 flex flex-wrap gap-4 ${align === "center" ? "justify-center" : ""}`}>{actions}</div> : null}
        </div>
      </div>
    </section>
  );
}
