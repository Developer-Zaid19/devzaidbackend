// open-source/page.js

import { Github, ShieldCheck, RefreshCcw, Code2, Search, Bookmark , CircleCheck , Smartphone, Palette, ExternalLink, Youtube, Instagram, Linkedin, GitFork, GitPullRequest } from "lucide-react";
import PageHero from "../components/PageHero";
import Image from "next/image";
import appIcon from "../favicon.png";

const architectureItems = [
  {
    icon: Github,
    title: "Transparent build",
    description:
      "The project gives users not just an APK, but a full open web experience around it — one that can be inspected, forked, and improved by anyone.",
  },
  {
    icon: ShieldCheck,
    title: "Readable source data flow",
    description:
      "Hadith JSON feeds directly into structured pages, search, and detail views, keeping the content pipeline simple, auditable, and trustworthy.",
  },

];

const designItems = [
  {
    icon: Code2,
    title: "Full-stack mindset",
    description:
      "Next.js, React Native, APIs, and product structure are thought through together so every experience feels coherent from web to mobile.",
  },
  {
    icon: Smartphone,
    title: "APK-first product thinking",
    description:
      "The website is not just a landing page — it is a supporting ecosystem for the Android app, improving discoverability and driving downloads.",
  },
 
];

export const metadata = {
  title: "Open Source | MyHadith",
};

export default function OpenSourcePage() {
  return (
    <main>
      <div className='flex items-center gap-12 page-shell'>
        <PageHero
          eyebrow="Open Source"
          title="A project structure that is easier to understand, extend, and contribute to."
          description="Breaking a single long page into separate routes and reusable components made the codebase more maintainable and gave future additions a strong foundation to build on."
          actions={
            <a
              href="https://github.com/Developer-Zaid19"
              target="_blank"
              rel="noreferrer"
              className="btn-primary"
            >
              <Github size={18} />
              View on GitHub
            </a>
          }
        />

        <div className="relative z-10 hidden xl:flex xl:items-center xl:justify-center flex-shrink-0">
          <div className="relative">
            {/* Glow effect */}
            <div className="absolute inset-0 blur-3xl rounded-full bg-gradient-to-r from-[rgba(212,175,55,0.15)] via-transparent to-[rgba(212,175,55,0.08)] scale-150" />
            
            {/* Phone mockup */}
            <div className="relative mx-auto w-[240px] overflow-hidden rounded-[42px] border border-[rgba(212,175,55,0.28)] bg-[var(--dark)] shadow-[0_48px_96px_rgba(0,0,0,0.65),0_0_0_1px_rgba(212,175,55,0.12),inset_0_1px_0_rgba(212,175,55,0.08)]">
              {/* Notch */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 rounded-b-2xl border border-[rgba(0,0,0,0.8)] bg-[var(--dark)] z-10" />

              {/* Status bar */}
              <div className="flex items-center justify-between border-b border-[rgba(212,175,55,0.12)] bg-[var(--dark)] px-4 pt-4 pb-3">
                <span className="text-[9px] font-semibold text-[var(--text-dim)]">9:41</span>
                <div className="flex items-center gap-1.5">
                  {[18, 13, 8].map((h) => (
                    <div key={h} className="w-1.5 rounded-sm bg-[var(--gold)]" style={{ height: `${h}px` }} />
                  ))}
                  <div className="ml-2 h-3 w-5 rounded-sm border border-[rgba(212,175,55,0.5)]">
                    <div className="m-0.5 h-2 w-2.5 rounded-sm bg-[var(--gold)]" />
                  </div>
                </div>
              </div>

              {/* App Header */}
              <div className="border-b border-[rgba(212,175,55,0.12)] bg-[var(--dark)] px-4 pb-3 pt-3 text-center">
                <div className="flex items-center justify-center gap-2 text-[var(--gold)]">
                  <Image src={appIcon} alt="App icon" className="h-7 w-7 rounded-lg shadow-lg" />
                  <span className="font-[family-name:var(--font-amiri)] text-base font-medium">MyHadith</span>
                </div>
              </div>

              {/* App Content */}
              <div className="flex flex-col gap-3 p-4 pb-5">
                {/* Search */}
                <div className="flex items-center gap-2.5 rounded-xl border border-[rgba(212,175,55,0.16)] bg-[rgba(9,24,39,0.6)] px-3.5 py-2.5 text-[10px] text-[var(--text-dim)]">
                  <Search className="h-3.5 w-3.5 text-[var(--gold)] flex-shrink-0" />
                  <span>Search by number...</span>
                </div>

                {/* Hadith cards */}
                {[
                  { book: "Bukhari", num: "#1", arabic: "إنما الأعمال بالنيات" },
                  { book: "Muslim", num: "#2674", arabic: "اتق الله حيثما كنت" },
                  { book: "Tirmidhi", num: "#1987", arabic: "الدين النصيحة" },
                ].map((h) => (
                  <div
                    key={h.num}
                    className="rounded-lg border-l-2 border-[var(--gold)] bg-[rgba(9,24,39,0.6)] p-3 hover:border-[var(--gold-light)] hover:bg-[rgba(9,24,39,0.8)] transition-all duration-200"
                  >
                    <div className="mb-1.5 flex items-center justify-between gap-2">
                      <span className="text-[8px] font-bold uppercase tracking-wider text-[var(--gold)]">{h.book} · {h.num}</span>
                      <Bookmark className="h-3 w-3 text-[var(--text-muted)] flex-shrink-0" />
                    </div>
                    <div className="text-right font-[family-name:var(--font-amiri)] text-xs leading-5 text-[var(--text-soft)]">
                      {h.arabic}
                    </div>
                  </div>
                ))}

                {/* Offline badge */}
                <div className="inline-flex items-center gap-1.5 rounded-full border border-[rgba(58,133,112,0.4)] bg-[rgba(58,133,112,0.1)] px-3 py-1.5 text-[9px] font-medium text-[rgba(110,220,180,0.9)]">
                  <CircleCheck className="h-3 w-3 flex-shrink-0" />
                  3 Saved Offline
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="page-shell py-16 md:py-20">
        <div className="px-1 mb-8">
          <p className="inline-flex items-center gap-2.5 text-xs font-bold tracking-widest uppercase text-[var(--gold)]">
            <span className="w-5 h-px bg-gradient-to-r from-[var(--gold)] to-transparent"></span>
            The Developer
          </p>
          <h2 className="mt-4 font-semibold text-white text-4xl md:text-5xl leading-tight">
            Made with ❤️ by<br className="hidden sm:block" /> Zaid Khan
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mt-12">
          {/* Developer Card */}
          <article className="surface-panel p-8 md:p-10 flex flex-col items-center text-center">
            <div className="w-20 h-20 md:w-24 md:h-24 rounded-full bg-[rgba(212,175,55,0.12)] flex items-center justify-center text-3xl md:text-4xl font-bold text-[var(--gold)]">
              Z
            </div>
            <h3 className="mt-8 text-2xl md:text-3xl font-semibold text-white">Zaid Khan</h3>
            <p className="mt-2 text-sm text-[var(--text-dim)]">Full Stack Developer & App Creator</p>

            <a
              href="https://developerzaid.vercel.app"
              target="_blank"
              rel="noreferrer"
              className="mt-8 inline-flex items-center gap-2 px-6 py-3 rounded-full border border-[var(--border)] bg-[rgba(212,175,55,0.08)] text-[var(--gold)] hover:bg-[rgba(212,175,55,0.15)] hover:border-[var(--border-strong)] transition-all duration-200"
            >
              <ExternalLink size={16} />
              See Portfolio
            </a>

            <div className="mt-8 flex gap-4 justify-center mb-3.5">
              <a
                href="https://youtube.com/@Developer-zaid"
                target="_blank"
                rel="noreferrer"
                title="YouTube"
                className="w-11 h-11 rounded-full flex items-center justify-center bg-[rgba(212,175,55,0.08)] text-[var(--text-dim)] hover:text-[var(--gold)] hover:bg-[rgba(212,175,55,0.15)] transition-all duration-200"
              >
                <Youtube size={18} />
              </a>
              <a
                href="https://instagram.com/dvlprzaid"
                target="_blank"
                rel="noreferrer"
                title="Instagram"
                className="w-11 h-11 rounded-full flex items-center justify-center bg-[rgba(212,175,55,0.08)] text-[var(--text-dim)] hover:text-[var(--gold)] hover:bg-[rgba(212,175,55,0.15)] transition-all duration-200"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://linkedin.com/in/developer-zaid29"
                target="_blank"
                rel="noreferrer"
                title="LinkedIn"
                className="w-11 h-11 rounded-full flex items-center justify-center bg-[rgba(212,175,55,0.08)] text-[var(--text-dim)] hover:text-[var(--gold)] hover:bg-[rgba(212,175,55,0.15)] transition-all duration-200"
              >
                <Linkedin size={18} />
              </a>
              <a
                href="https://github.com/Developer-Zaid19"
                target="_blank"
                rel="noreferrer"
                title="GitHub"
                className="w-11 h-11 rounded-full flex items-center justify-center bg-[rgba(212,175,55,0.08)] text-[var(--text-dim)] hover:text-[var(--gold)] hover:bg-[rgba(212,175,55,0.15)] transition-all duration-200"
              >
                <Github size={18} />
              </a>
            </div>

            <div className='flex flex-col sm:flex-row gap-3 sm:gap-2.5 w-full sm:w-auto'>
              <a
                href="https://github.com/Developer-Zaid19/MyHadith-MobileApp"
                target="_blank"
                rel="noreferrer"
                className="btn-primary flex-1 sm:flex-none justify-center"
              >
                <GitFork size={16} />
                <span className="truncate">Fork App</span>
              </a>

              <a
                href="https://github.com/Developer-Zaid19/MyHadith-Website"
                target="_blank"
                rel="noreferrer"
                className="btn-outline flex-1 sm:flex-none justify-center"
              >
                <GitPullRequest size={16} />
                <span className="truncate">Fork Website</span>
              </a>
            </div>

          </article>

          {/* About Section */}
          <div className="flex flex-col justify-center space-y-6">
            <div>
              <h3 className="text-2xl md:text-3xl font-semibold text-white mb-4">Who am I?</h3>
              <p className="text-[var(--text-dim)] leading-relaxed">
                I'm a passionate <span className="text-[var(--gold)] font-medium">Full Stack Web Developer</span> and <span className="text-[var(--gold)] font-medium">Cross-Platform Mobile App Developer</span> who loves building meaningful digital experiences. I believe technology should serve people — and what better way than to serve the Muslim Ummah through an app that brings the Prophet's ﷺ wisdom to every pocket?
              </p>
            </div>
            <p className="text-[var(--text-dim)] leading-relaxed">
              I build modern, performant applications for the web and mobile using cutting-edge tools. From sleek frontends to robust backends and production-ready mobile apps — I cover the full stack. MyHadith is one of my passion projects — built out of love for my Deen and my craft.
            </p>
            <p className="text-[var(--text-dim)] leading-relaxed">
              I also share my journey, tutorials, and projects on YouTube and Instagram. If you're into web dev, app development, or just geeky tech stuff — you'll feel right at home on my channels.
            </p>
            <div className="flex flex-wrap gap-3 pt-4">
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">React / Next.js</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">Node.js</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">JetPack Compose</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">React Native</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">MongoDB</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">MySQL</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">REST APIs</span>
              <span className="px-4 py-2 rounded-full border border-[var(--border)] bg-[rgba(255,255,255,0.03)] text-xs font-medium text-[var(--text-soft)]">UI/UX Design</span>
            </div>
          </div>
        </div>
      </section>


      <section className="page-shell py-16 md:py-8">
        <div className="px-1 mb-8">
          <p className="inline-flex items-center gap-2.5 text-xs font-bold tracking-widest uppercase text-[var(--gold)]">
            <span className="w-5 h-px bg-gradient-to-r from-[var(--gold)] to-transparent"></span>
            Architecture
          </p>
          <h2 className="mt-4 text-3xl md:text-4xl font-semibold text-white">How the project is structured</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {architectureItems.map((item) => {
            const Icon = item.icon;
            return (
              <article key={item.title} className="surface-panel p-8 hover:border-[var(--border-strong)] transition-all duration-300">
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[rgba(212,175,55,0.12)] text-[var(--gold)]">
                  <Icon size={24} />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-white">{item.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-[var(--text-dim)]">{item.description}</p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="page-shell py-16 md:py-20">
        <div className="px-1 mb-8">
          <p className="inline-flex items-center gap-2.5 text-xs font-bold tracking-widest uppercase text-[var(--gold)]">
            <span className="w-5 h-px bg-gradient-to-r from-[var(--gold)] to-transparent"></span>
            Design Philosophy
          </p>
          <h2 className="mt-4 text-3xl md:text-4xl font-semibold text-white">What shapes the experience</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {designItems.map((item) => {
            const Icon = item.icon;
            return (
              <article key={item.title} className="surface-panel p-8 hover:border-[var(--border-strong)] transition-all duration-300">
                <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[rgba(212,175,55,0.12)] text-[var(--gold)]">
                  <Icon size={24} />
                </div>
                <h3 className="mt-6 text-lg font-semibold text-white">{item.title}</h3>
                <p className="mt-4 text-sm leading-relaxed text-[var(--text-dim)]">{item.description}</p>
              </article>
            );
          })}
        </div>
      </section>
    </main>
  );
}