// this is book/page.js
import { getBookSummaries } from "../../lib/hadith";
import BookGrid from "../components/BookGrid";
import PageHero from "../components/PageHero";

export const metadata = {
  title: "Books | MyHadith",
};

export default async function BooksPage() {
  const books = await getBookSummaries(4);

  return (
    <main>
      <section className="page-shell pb-16 mt-3">
        <BookGrid books={books} />
      </section>
    </main>
  );
}
