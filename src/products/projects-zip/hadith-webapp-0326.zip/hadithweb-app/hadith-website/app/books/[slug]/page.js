// book/[slug]/page.js

import { notFound } from "next/navigation";
// import { getBookListData } from "../../../lib/hadith";
import BookHadithList from "../../components/BookHadithList";



async function getBookListData(bookslug) {

  try {
    const page = 1;

    const response = await fetch(
      `https://devzaidbackend.onrender.com/api/hadith/hadithlist`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        verifypass: process.env.VERIFYPASS,
        bookslug: bookslug,
        pagenumber: page,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Failed to load hadiths");
    }
    
    return data;
  } catch (error) {
    console.error("Failed to load initial hadiths:", error);
  }
}


export async function generateMetadata({ params }) {
  const { slug } = await params;
  const bookData = await getBookListData(slug);

  return {
    title: bookData ? `${bookData.hadiths[0].book.bookName} | MyHadith` : "Book Not Found | MyHadith",
  };
}

export default async function BookDetailPage({ params }) {
  const { slug } = await params;
  const bookData = await getBookListData(slug);

  if (!bookData) {
    notFound();
  }

  return (
    <main>
      <section className="page-shell pt-16">
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="surface-panel relative overflow-hidden p-8 sm:p-10 lg:p-14">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.14),transparent_38%)]" />
            <div className="relative">
              <div className="section-tag justify-start">Book Detail</div>
              <h1 className="section-title">{bookData.hadiths[0].book.bookName}</h1>
              <p className="section-sub max-w-2xl">
                A collection compiled by {bookData.hadiths[0].writerName}, containing {bookData.totalHadiths} hadith
                entries. Browse the full list below.
              </p>
            </div>
          </div>

          <aside className="surface-panel flex h-full flex-col justify-center p-8 sm:p-10 lg:p-14">
            <h2 className="text-2xl font-semibold text-white">Collection info</h2>
            <div className="mt-8 space-y-5 text-sm text-[var(--text-dim)]">
              <div>
                <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Compiler</p>
                <p className="mt-1 font-medium text-white">{bookData.hadiths[0].book.writerName}</p>
              </div>
              {bookData.hadiths[0].book.writerDeath ? (
                <div>
                  <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Death year</p>
                  <p className="mt-1 font-medium text-white">{bookData.hadiths[0].book.writerDeath} A.H.</p>
                </div>
              ) : null}
              <div>
                <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Total hadiths</p>
                <p className="mt-1 font-medium text-white">{bookData.totalHadiths}</p>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <section className="page-shell pb-16 pt-10">
        <BookHadithList slug={slug} />
      </section>
    </main>
  );
}
