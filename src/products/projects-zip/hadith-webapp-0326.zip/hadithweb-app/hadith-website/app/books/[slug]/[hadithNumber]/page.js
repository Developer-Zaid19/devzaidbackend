import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import HadithCard from "../../../components/HadithCard";

async function getHadithByNumber(bookslug, hadithnumber) {

  try {
    const response = await fetch(
      `https://devzaidbackend.onrender.com/api/hadith/findhadith/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        verifypass: process.env.VERIFYPASS,
        bookslug: bookslug,
        hadithnumber: hadithnumber,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Hadith not found");
    }

    return data;
  } catch (e) {
    throw new error("could not submit ", e.massage)
  }
}

export async function generateMetadata({ params }) {
  const { slug, hadithNumber } = await params;
  const result = await getHadithByNumber(slug, hadithNumber);

  return {
    title: result ? `${result.book.bookname} #${result.hadithNumber} | MyHadith` : "Hadith Not Found | MyHadith",
  };
}

export default async function HadithDetailPage({ params }) {
  const { slug, hadithNumber } = await params;
  const result = await getHadithByNumber(slug, hadithNumber);

  if (!result) {
    notFound();
  }

  return (
    <main>
      <section className="page-shell pt-12">
        <div className="surface-panel relative overflow-hidden p-6 sm:p-7 lg:p-8">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.12),transparent_34%)]" />
          <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div className="min-w-0">
              <div className="section-tag justify-start">Hadith Detail</div>
              <h1 className="mt-3 text-2xl font-semibold text-white sm:text-3xl">
                {result.book.bookname} - Hadith #{result.hadithNumber}
              </h1>
            </div>

            <Link href={`/books/${slug}`} className="btn-outline px-5 py-3 text-sm">
              <ArrowLeft size={18} />
              Back to book
            </Link>
          </div>
        </div>
      </section>

      <section className="page-shell pb-16 pt-6">
        <HadithCard hadith={result} full />
      </section>
    </main>
  );
}
