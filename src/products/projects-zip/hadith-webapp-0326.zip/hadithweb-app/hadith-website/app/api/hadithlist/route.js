import { NextResponse } from "next/server";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const book = searchParams.get("bookslug");
  const pagenumber = searchParams.get("page");
  const result = await fetch(`https://devzaidbackend.onrender.com/api/hadith/hadithlist`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      verifypass: process.env.VERIFYPASS,
      bookslug: book,
      pagenumber: pagenumber,
    }),
  });

  const data = await result.json();

  return NextResponse.json(data);
}
