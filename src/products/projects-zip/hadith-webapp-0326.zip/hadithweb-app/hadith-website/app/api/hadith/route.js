import { NextResponse } from "next/server";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const book = searchParams.get("bookslug");
  const number = searchParams.get("hadithnumber");

  if (!book || !number) {
    return NextResponse.json({ error: "Book aur hadith number dono required hain." }, { status: 400 });
  }

  const result = await fetch(`https://devzaidbackend.onrender.com/api/hadith/findhadith/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      verifypass: process.env.VERIFYPASS,
      bookslug: book,
      hadithnumber: number,
    }),
  });

  const data = await result.json();

  return NextResponse.json(data);
}
