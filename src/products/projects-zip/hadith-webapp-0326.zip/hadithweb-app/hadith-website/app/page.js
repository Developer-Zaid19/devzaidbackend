import HomePageContent from "./components/HomePageContent";
import { getAllBooks } from "../lib/hadith";

async function getRandomHadith() {
  const response = await fetch(
    "https://devzaidbackend.onrender.com/api/hadith/randomhadith",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        verifypass: process.env.VERIFYPASS,
      }),
    });

  const data = await response.text();

  if (!response.ok) {
    throw new Error(
      `Failed to fetch random hadith. Status: ${response.status}`
    );
  }

  return JSON.parse(data);
}

export default async function HomePage() {
  const [books, randomHadith] = await Promise.all([
    getAllBooks(),
    getRandomHadith(),
  ]);

  return (
    <HomePageContent
      books={books}
      randomHadith={randomHadith}
    />
  );
}