"use client"
import { Mail, Github, Linkedin, Youtube } from "lucide-react";
import PageHero from "../components/PageHero";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { fadeUp } from "../components/animations";


const contacts = [
  {
    label: "Email",
    value: "developerzaid26@gmail.com",
    href: "mailto:developerzaid26@gmail.com",
    icon: Mail,
    description: "Best for bug reports, questions, or collaboration requests.",
  },
  {
    label: "GitHub",
    value: "Developer-Zaid19",
    href: "https://github.com/Developer-Zaid19",
    icon: Github,
    description: "Browse source code, open issues, or submit pull requests.",
  },
  {
    label: "LinkedIn",
    value: "developer-zaid29",
    href: "https://linkedin.com/in/developer-zaid29",
    icon: Linkedin,
    description: "Connect for professional opportunities and project discussions.",
  },
  {
    label: "YouTube",
    value: "@Developer-zaid",
    href: "https://youtube.com/@Developer-zaid",
    icon: Youtube,
    description: "Watch development tutorials and project walkthroughs.",
  },
];

export default function ContactPage() {

  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm();

    const submithandle = async (formData) => {
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });
    const result = await res.json();
    if (!result.success) {
      alert("We are trying to reply faster");
    } else {
      alert("I will contact you soon!");
      reset();
    }
  };

  return (
    <main>
      <PageHero
        eyebrow="Contact"
        title="Reach out for feedback, collaboration, or app questions."
        description="If you spot an issue on the website or APK, or want to discuss the project, any of the channels below will reach the developer directly."
      />

      <section className="page-shell py-16 md:py-20">
        <div className="px-1 mb-8">
          <p className="inline-flex items-center gap-2.5 text-xs font-bold tracking-widest uppercase text-[var(--gold)]">
            <span className="w-5 h-px bg-gradient-to-r from-[var(--gold)] to-transparent"></span>
            Get In Touch
          </p>
          <h2 className="mt-4 text-3xl md:text-4xl font-semibold text-white">Choose your preferred channel</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          {contacts.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.label}
                href={item.href}
                target="_blank"
                rel="noreferrer"
                className="surface-panel group p-8 hover:border-[var(--border-strong)] transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start gap-6">
                  <div className="inline-flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-[rgba(212,175,55,0.12)] text-[var(--gold)] transition-all duration-300 group-hover:bg-[rgba(212,175,55,0.2)] group-hover:scale-110">
                    <Icon size={24} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs uppercase tracking-widest font-bold text-[var(--gold)]">{item.label}</p>
                    <h3 className="mt-2 text-lg font-semibold text-white truncate group-hover:text-[var(--gold-light)] transition-colors duration-300">{item.value}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-[var(--text-dim)]">{item.description}</p>
                  </div>
                </div>
              </a>
            );
          })}
        </div>

        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}
          transition={{ delay: 0.15 }}
          className="glass rounded-2xl p-8 sm:p-10"
        >
          <h3 className="text-xl font-bold mb-6">Send a Message</h3>
          <form className="space-y-5" onSubmit={handleSubmit(submithandle)}>

            <div>
              <input
                {...register("name", {
                  required: "Name is required",
                  minLength: { value: 3, message: "Min 3 characters" },
                  maxLength: { value: 15, message: "Max 15 characters" },
                })}
                type="text"
                placeholder="Your Name"
                className="w-full bg-transparent border border-(--border) rounded-xl px-5 py-3.5 outline-none focus:border-(--gold) focus:shadow-[0_0_15px_var(--gold)] transition-all placeholder:text-(--text-soft) text-(--text) text-sm"
              />
              {errors.name && <p className="text-red-400 text-xs mt-1.5 font-medium">{errors.name.message}</p>}
            </div>

            <div>
              <input
                {...register("email", {
                  required: "Email is required",
                  minLength: { value: 5, message: "Min 5 characters" },
                  maxLength: { value: 50, message: "Max 50 characters" },
                })}
                type="email"
                placeholder="Email or Phone"
                className="w-full bg-transparent border border-(--border) rounded-xl px-5 py-3.5 outline-none focus:border-(--gold) focus:shadow-[0_0_15px_var(--gold)] transition-all placeholder:text-(--text-soft) text-(--text) text-sm"
              />
              {errors.email && <p className="text-red-400 text-xs mt-1.5 font-medium">{errors.email.message}</p>}
            </div>

            <div>
              <textarea
                {...register("message", {
                  required: "Message is required",
                  minLength: { value: 5, message: "Min 5 characters" },
                  maxLength: { value: 500, message: "Max 500 characters" },
                })}
                rows="5"
                placeholder="Tell me about your project..."
                className="w-full bg-transparent border border-(--border) rounded-xl px-5 py-3.5 outline-none focus:border-(--gold) focus:shadow-[0_0_15px_var(--gold)] transition-all placeholder:text-(--text-soft) text-(--text) text-sm resize-none"
              />
              {errors.message && <p className="text-red-400 text-xs mt-1.5 font-medium">{errors.message.message}</p>}
            </div>

            <button
              disabled={isSubmitting}
              type="submit"
              className="w-full py-4 rounded-xl font-bold text-sm bg-(--gold) text-(--bgcolor) hover:shadow-[0_0_30px_var(--gold-strong)] hover:scale-[1.02] disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-300"
            >
              {isSubmitting ? "Sending..." : "Send Message →"}
            </button>

          </form>
        </motion.div>
      </section>
    </main>
  );
}