// download/page.js

import Image from "next/image";
import Link from "next/link";
import { Download, ShieldCheck, Smartphone } from "lucide-react";

export const metadata = {
  title: "Download | MyHadith",
};

export default function DownloadPage() {
  return (
    <main>
      <section className="page-shell pt-10 sm:pt-12 lg:pt-16 mb-7">
        <div className="grid gap-8 xl:grid-cols-[1fr_0.92fr]">
          <div className="surface-panel hero-panel p-6 sm:p-8 lg:p-12">
            <div className="section-tag">Download APK</div>
            <h1 className="section-title max-w-3xl">
              Install the MyHadith Android app directly from this page.
            </h1>
            <p className="section-sub max-w-2xl">
              The Android APK and the website share the same content vision - clean reading, fast search, and
              support for Arabic, Urdu, and English in a single tap.
            </p>

            <div className="mt-6 flex flex-col gap-3 sm:mt-8 sm:flex-row sm:flex-wrap">
              <a href="/apk/myhadith.apk" download className="btn-primary w-full sm:w-auto">
                <Download size={18} />
                Download APK
              </a>
              <Link href="/books" className="btn-outline w-full sm:w-auto">
                Browse Books
              </Link>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              <div className="rounded-[22px] border border-[var(--border)] bg-[rgba(255,255,255,0.03)] p-4">
                <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Search</p>
                <p className="mt-2 text-sm leading-7 text-[var(--text-dim)]">Open a book and find hadiths quickly.</p>
              </div>
              <div className="rounded-[22px] border border-[var(--border)] bg-[rgba(255,255,255,0.03)] p-4">
                <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Read</p>
                <p className="mt-2 text-sm leading-7 text-[var(--text-dim)]">
                  Switch between Arabic, Urdu, and English.
                </p>
              </div>
              <div className="rounded-[22px] border border-[var(--border)] bg-[rgba(255,255,255,0.03)] p-4">
                <p className="text-xs uppercase tracking-[0.22em] text-[var(--gold)]">Download</p>
                <p className="mt-2 text-sm leading-7 text-[var(--text-dim)]">
                  Get the APK directly without extra steps.
                </p>
              </div>
            </div>
          </div>

          <div className="surface-panel relative overflow-hidden p-5 sm:p-7 lg:p-8">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(212,175,55,0.18),transparent_36%)]" />
            <div className="download-showcase relative mx-auto flex min-h-[420px] items-center justify-center sm:min-h-[520px]">
              <div className="download-glow" />
              <div className="download-orbit download-orbit-one" />
              <div className="download-orbit download-orbit-two" />

              <div className="download-badge download-badge-left">
                <span className="text-xs uppercase tracking-[0.18em] text-[var(--gold)]">Fast Search</span>
                <span className="mt-2 block text-sm text-white">Book + hadith number</span>
              </div>

              <div className="download-badge download-badge-right">
                <span className="text-xs uppercase tracking-[0.18em] text-[var(--gold)]">Multi Language</span>
                <span className="mt-2 block text-sm text-white">Arabic, Urdu, English</span>
              </div>

              <div className="download-phone-shell">
                <div className="download-phone-notch" />
                <div className="download-phone-screen">
                  <Image
                    src="/media/mobile.jpg"
                    alt="MyHadith mobile app preview"
                    fill
                    className="object-cover object-top"
                    sizes="(max-width: 768px) 78vw, 420px"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section className="page-shell pb-16">
        <div className="surface-panel p-8 text-center sm:p-10">
          <h2 className="text-3xl font-semibold text-white">Want to browse first?</h2>
          <p className="mx-auto mt-4 max-w-2xl text-sm leading-8 text-[var(--text-dim)]">
            Explore books and random hadiths on the web before installing the app. The web experience mirrors
            everything the app offers.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link href="/" className="btn-outline">
              Back to Home
            </Link>
            <Link href="/books" className="btn-primary">
              Browse Books
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
