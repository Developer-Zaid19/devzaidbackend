/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return [
      {
        source: "/apk/myhadith.apk",
        destination: `https://devzaidbackend.onrender.com/apk/myhadith.apk`,
      },
    ];
  },
  reactCompiler: true,
};

export default nextConfig;
