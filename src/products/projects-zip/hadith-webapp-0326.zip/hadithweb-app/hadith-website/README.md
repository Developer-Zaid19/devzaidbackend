# Hadith Website 🌐📖

A simple and responsive website to access authentic Hadiths easily. Search Hadiths by number, browse them online, and save your favorite Hadiths for quick access. Powered by [HadithAPI.com](https://hadithapi.com).

---

## Features ✨

- Search Hadith by number
- Browse Hadiths online
- Save favorite Hadiths
- Responsive design (works on mobile & desktop)
- Clean and user-friendly interface

---

## Screenshots 🖼️

*(Add screenshots of your website here for better presentation)*

---

## Installation 💻

### 0. Requirements:

```bash
node -v
version 14+
```

### 1. Clone this repository:

```bash
git clone https://github.com/Developer-Zaid19/MyHadith-Website.git
```

### 2. Navigate into the project directory:

```bash
cd MyHadith-Website
```

### 3. Install dependencies:

```bash
npm install
```

## Usage 🌍

- Enter the Hadith number to search
- Click the "Save" button to store your favorite Hadiths

---

## Contributing 🤝

Feel free to open issues or submit pull requests. Keep the code clean and follow best practices.

---

## License 📄

This project is licensed under the MIT License. See the LICENSE file for details.

---

## Contact ✉️

Developed by Zaid  
Email: developerzaid26@gmail.com  
GitHub: https://github.com/Developer-Zaid19/

---