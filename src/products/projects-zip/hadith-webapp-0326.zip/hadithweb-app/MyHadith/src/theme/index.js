import {
  DefaultTheme as NavigationDefaultTheme,
  DarkTheme as NavigationDarkTheme,
} from '@react-navigation/native';
import {Platform} from 'react-native';

const shared = {
  primary: '#D4AF37',
  primaryLight: '#E6C76A',
  primaryDim: 'rgba(212, 175, 55, 0.15)',
  secondary: '#2F6F5E',
  secondaryLight: '#3F8F7A',
  radius: 16,
};

const darkColors = {
  ...shared,
  background: '#04172B',
  backgroundSecondary: '#06203C',
  backgroundTertiary: '#0A2A4D',
  surface: '#0F2F52',
  surfaceElevated: '#123963',
  textPrimary: '#E6EDF3',
  textSecondary: '#9BA6B2',
  border: '#1E3A5F',
  shadow: '#000000',
  white: '#FFFFFF',
};

const lightColors = {
  ...shared,
  background: '#F4F8FC',
  backgroundSecondary: '#FCFDFE',
  backgroundTertiary: '#EAF1F8',
  surface: '#FFFFFF',
  surfaceElevated: '#F7FAFD',
  textPrimary: '#10243E',
  textSecondary: '#5F6E7F',
  border: '#D8E3EE',
  shadow: '#10243E',
  white: '#FFFFFF',
};

const fontFamily = (name, fallback) =>
  Platform.select({
    android: name || fallback,
    ios: name || fallback,
    default: fallback,
  });

const typography = {
  heading: fontFamily('DM Sans', 'sans-serif-medium'),
  body: fontFamily('Inter', 'sans-serif'),
  arabic: fontFamily('Amiri', 'serif'),
};

export const getTheme = (mode = 'dark') => {
  const colors = mode === 'light' ? lightColors : darkColors;

  return {
    mode,
    isDark: mode !== 'light',
    colors,
    typography,
  };
};

export const createNavigationTheme = (mode = 'dark') => {
  const baseTheme =
    mode === 'light' ? NavigationDefaultTheme : NavigationDarkTheme;
  const theme = getTheme(mode);

  return {
    ...baseTheme,
    colors: {
      ...baseTheme.colors,
      primary: theme.colors.primary,
      background: theme.colors.background,
      card: theme.colors.backgroundSecondary,
      text: theme.colors.textPrimary,
      border: theme.colors.border,
      notification: theme.colors.secondary,
    },
  };
};
