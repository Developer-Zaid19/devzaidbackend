export const buildHadithCopyText = ({hadith, bookTitle, volumeNumber}) => {
  const sections = [
    hadith?.hadithNumber ? `Hadith Number: ${hadith.hadithNumber}` : null,
    bookTitle || hadith?.book?.bookName
      ? `Book: ${bookTitle || hadith?.book?.bookName}`
      : null,
    volumeNumber || hadith?.volume
      ? `Volume: ${volumeNumber || hadith?.volume}`
      : null,
    hadith?.status ? `Status: ${hadith.status}` : null,
    hadith?.englishNarrator ? `Narrator: ${hadith.englishNarrator}` : null,
    hadith?.hadithEnglish ? `English:\n${hadith.hadithEnglish}` : null,
    hadith?.hadithUrdu ? `Urdu:\n${hadith.hadithUrdu}` : null,
    hadith?.hadithArabic ? `Arabic:\n${hadith.hadithArabic}` : null,
  ];

  return sections.filter(Boolean).join('\n\n');
};
