import AsyncStorage from '@react-native-async-storage/async-storage';

const BOOKMARKS_KEY = '@myhadith/bookmarks';
const COLLECTIONS_KEY = '@myhadith/bookmarkCollections';
const DEFAULT_COLLECTION_ID = 'default-saved-hadiths';
const DEFAULT_COLLECTION_NAME = 'Saved Hadiths';

export const getBookmarkId = hadith => {
  const bookSlug = hadith?.bookSlug || hadith?.book?.bookSlug || 'unknown-book';
  const hadithNumber = hadith?.hadithNumber || hadith?.id || 'unknown-hadith';
  const volume = hadith?.volume || 'unknown-volume';

  return `${bookSlug}-${volume}-${hadithNumber}`;
};

export const normalizeBookmark = (hadith, extra = {}) => {
  return {
    ...hadith,
    bookmarkId: getBookmarkId(hadith),
    savedAt: extra.savedAt || new Date().toISOString(),
    savedBookTitle: extra.bookTitle || hadith?.book?.bookName || null,
    savedVolumeNumber: extra.volumeNumber || hadith?.volume || null,
  };
};

const normalizeCollection = collection => ({
  id: collection?.id || `collection-${Date.now()}`,
  name: collection?.name || DEFAULT_COLLECTION_NAME,
  createdAt: collection?.createdAt || new Date().toISOString(),
  updatedAt:
    collection?.updatedAt || collection?.createdAt || new Date().toISOString(),
  items: Array.isArray(collection?.items) ? collection.items : [],
});

const readLegacyBookmarks = async () => {
  try {
    const raw = await AsyncStorage.getItem(BOOKMARKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    console.log('Bookmarks read error:', error);
    return [];
  }
};

const persistCollections = async collections => {
  await AsyncStorage.setItem(COLLECTIONS_KEY, JSON.stringify(collections));

  const flattened = [];
  const seen = {};

  collections.forEach(collection => {
    collection.items.forEach(item => {
      const bookmarkId = item.bookmarkId || getBookmarkId(item);

      if (!seen[bookmarkId]) {
        seen[bookmarkId] = true;
        flattened.push(item);
      }
    });
  });

  await AsyncStorage.setItem(BOOKMARKS_KEY, JSON.stringify(flattened));
};

const normalizeCollectionName = name => name.trim().toLowerCase();

export const collectionNameExists = (collections, name) => {
  const normalizedName = normalizeCollectionName(name);

  if (!normalizedName) {
    return false;
  }

  return collections.some(
    collection => normalizeCollectionName(collection.name) === normalizedName,
  );
};

export const getCollections = async () => {
  try {
    const rawCollections = await AsyncStorage.getItem(COLLECTIONS_KEY);

    if (rawCollections) {
      return JSON.parse(rawCollections).map(normalizeCollection);
    }

    const legacyBookmarks = await readLegacyBookmarks();

    if (!legacyBookmarks.length) {
      return [];
    }

    const defaultCollection = normalizeCollection({
      id: DEFAULT_COLLECTION_ID,
      name: DEFAULT_COLLECTION_NAME,
      items: legacyBookmarks,
    });

    await persistCollections([defaultCollection]);
    return [defaultCollection];
  } catch (error) {
    console.log('Collections read error:', error);
    return [];
  }
};

export const getBookmarks = async () => {
  const collections = await getCollections();
  const flattened = [];
  const seen = {};

  collections.forEach(collection => {
    collection.items.forEach(item => {
      const bookmarkId = item.bookmarkId || getBookmarkId(item);

      if (!seen[bookmarkId]) {
        seen[bookmarkId] = true;
        flattened.push(item);
      }
    });
  });

  return flattened;
};

export const isBookmarked = async hadith => {
  const bookmarks = await getBookmarks();
  const bookmarkId = getBookmarkId(hadith);
  return bookmarks.some(item => item.bookmarkId === bookmarkId);
};

export const getBookmarkCollections = async hadith => {
  const collections = await getCollections();
  const bookmarkId = getBookmarkId(hadith);

  return collections.filter(collection =>
    collection.items.some(item => item.bookmarkId === bookmarkId),
  );
};

export const createCollection = async name => {
  const sanitizedName = name.trim() || 'New Collection';
  const now = new Date().toISOString();
  const collections = await getCollections();

  if (collectionNameExists(collections, sanitizedName)) {
    return null;
  }

  const collection = {
    id: `collection-${Date.now()}`,
    name: sanitizedName,
    createdAt: now,
    updatedAt: now,
    items: [],
  };

  const nextCollections = [collection, ...collections];

  try {
    await persistCollections(nextCollections);
    return collection;
  } catch (error) {
    console.log('Collection write error:', error);
    return null;
  }
};

export const deleteCollection = async collectionId => {
  const collections = await getCollections();
  const nextCollections = collections.filter(
    collection => collection.id !== collectionId,
  );

  try {
    await persistCollections(nextCollections);
    return nextCollections;
  } catch (error) {
    console.log('Collection delete error:', error);
    return collections;
  }
};

export const saveHadithToCollection = async (
  hadith,
  collectionId,
  extra = {},
) => {
  const collections = await getCollections();
  const normalized = normalizeBookmark(hadith, extra);
  const now = new Date().toISOString();
  const hasTarget = collections.some(
    collection => collection.id === collectionId,
  );
  const baseCollections = hasTarget
    ? collections
    : [
        normalizeCollection({
          id: DEFAULT_COLLECTION_ID,
          name: DEFAULT_COLLECTION_NAME,
          createdAt: now,
          updatedAt: now,
          items: [],
        }),
        ...collections,
      ];

  const nextCollections = baseCollections.map(collection => {
    if (collection.id !== collectionId && hasTarget) {
      return collection;
    }

    if (!hasTarget && collection.id !== DEFAULT_COLLECTION_ID) {
      return collection;
    }

    const alreadySaved = collection.items.some(
      item => item.bookmarkId === normalized.bookmarkId,
    );

    return {
      ...collection,
      updatedAt: now,
      items: alreadySaved
        ? collection.items
        : [{...normalized, savedAt: now}, ...collection.items],
    };
  });

  try {
    await persistCollections(nextCollections);
    return {
      saved: true,
      collections: nextCollections,
    };
  } catch (error) {
    console.log('Bookmark collection write error:', error);
    return {
      saved: false,
      collections,
    };
  }
};

export const removeHadithFromCollection = async (hadith, collectionId) => {
  const collections = await getCollections();
  const bookmarkId = getBookmarkId(hadith);
  const now = new Date().toISOString();
  const nextCollections = collections.map(collection => {
    if (collection.id !== collectionId) {
      return collection;
    }

    return {
      ...collection,
      updatedAt: now,
      items: collection.items.filter(item => item.bookmarkId !== bookmarkId),
    };
  });

  try {
    await persistCollections(nextCollections);
    return nextCollections;
  } catch (error) {
    console.log('Bookmark collection remove error:', error);
    return collections;
  }
};

export const removeHadithFromAllCollections = async hadith => {
  const collections = await getCollections();
  const bookmarkId = getBookmarkId(hadith);
  const now = new Date().toISOString();
  const nextCollections = collections.map(collection => ({
    ...collection,
    updatedAt: now,
    items: collection.items.filter(item => item.bookmarkId !== bookmarkId),
  }));

  try {
    await persistCollections(nextCollections);
    return nextCollections;
  } catch (error) {
    console.log('Bookmark remove error:', error);
    return collections;
  }
};

export const toggleHadithInCollection = async (
  hadith,
  collectionId,
  extra = {},
) => {
  const activeCollections = await getBookmarkCollections(hadith);
  const alreadySaved = activeCollections.some(
    collection => collection.id === collectionId,
  );

  if (alreadySaved) {
    const collections = await removeHadithFromCollection(hadith, collectionId);
    return {
      saved: collections.some(collection =>
        collection.items.some(
          item => item.bookmarkId === getBookmarkId(hadith),
        ),
      ),
      collections,
    };
  }

  return saveHadithToCollection(hadith, collectionId, extra);
};

export const toggleBookmark = async (hadith, extra = {}) => {
  const bookmarks = await getBookmarks();
  const normalized = normalizeBookmark(hadith, extra);
  const alreadySaved = bookmarks.some(
    item => item.bookmarkId === normalized.bookmarkId,
  );

  try {
    const result = alreadySaved
      ? await removeHadithFromAllCollections(normalized)
      : await saveHadithToCollection(normalized, DEFAULT_COLLECTION_ID, extra);

    return {
      saved: !alreadySaved,
      bookmarks: alreadySaved ? await getBookmarks() : result.collections,
    };
  } catch (error) {
    console.log('Bookmarks write error:', error);
    return {
      saved: alreadySaved,
      bookmarks,
    };
  }
};
