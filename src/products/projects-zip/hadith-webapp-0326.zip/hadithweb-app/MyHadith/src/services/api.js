import {books} from '../data/books';

const BOOK_FILE_MAP = {
  'sahih-bukhari': () => require('../data/Hadith-Json/Sahih-Bukhari.json'),
  'sahih-muslim': () => require('../data/Hadith-Json/Sahih-Muslim.json'),
  'al-tirmidhi': () => require('../data/Hadith-Json/Jami-at-tirmidhi.json'),
  'abu-dawood': () => require('../data/Hadith-Json/Abu-Dawood.json'),
  'ibn-e-majah': () => require('../data/Hadith-Json/Ibn-e-Majah.json'),
  'sunan-nasai': () => require('../data/Hadith-Json/Sunan-Nasai.json'),
  mishkat: () => require('../data/Hadith-Json/Mishkat-al-Masabih.json'),
};

const getBookDataset = bookSlug => {
  const loader = BOOK_FILE_MAP[bookSlug];

  if (!loader) {
    console.log('Offline dataset not found for book:', bookSlug);
    return [];
  }

  const dataset = loader();
  return Array.isArray(dataset) ? dataset : [];
};

const paginateItems = ({items, page = 1, batchSize = 50}) => {
  const safePage = Number(page) || 1;
  const safeBatchSize = Number(batchSize) || 50;
  const startIndex = (safePage - 1) * safeBatchSize;
  const hadiths = items.slice(startIndex, startIndex + safeBatchSize);

  return {
    hadiths,
    nextPage: safePage + 1,
    hasMore: startIndex + safeBatchSize < items.length,
  };
};

export const getHadiths = async (book = 'sahih-bukhari') => {
  try {
    return getBookDataset(book).slice(0, 20);
  } catch (err) {
    console.log('Offline hadith read error:', err);
    return [];
  }
};

export const getVolumeHadithBatch = async ({
  bookSlug,
  volume,
  page = 1,
  batchSize = 50,
}) => {
  try {
    const volumeHadiths = getBookDataset(bookSlug).filter(
      item => String(item.volume) === String(volume),
    );

    return paginateItems({
      items: volumeHadiths,
      page,
      batchSize,
    });
  } catch (err) {
    console.log('Offline volume hadith read error:', err);
    return {
      hadiths: [],
      nextPage: page,
      hasMore: false,
    };
  }
};

export const getBookHadithBatch = async ({
  bookSlug,
  page = 1,
  batchSize = 50,
}) => {
  try {
    return paginateItems({
      items: getBookDataset(bookSlug),
      page,
      batchSize,
    });
  } catch (err) {
    console.log('Offline book hadith read error:', err);
    return {
      hadiths: [],
      nextPage: page,
      hasMore: false,
    };
  }
};

export const searchHadithByNumber = async ({bookSlug, hadithNumber}) => {
  try {
    const normalizedHadithNumber = String(hadithNumber).trim();

    return (
      getBookDataset(bookSlug).find(
        item => String(item.hadithNumber) === normalizedHadithNumber,
      ) || null
    );
  } catch (error) {
    console.log('Offline hadith search error:', error);
    return null;
  }
};

export const getRandomHadith = async () => {
  try {
    const randomBook =
      books[Math.floor(Math.random() * books.length)]?.id || 'sahih-bukhari';
    const dataset = getBookDataset(randomBook);

    if (!dataset.length) {
      return null;
    }

    return dataset[Math.floor(Math.random() * dataset.length)] || null;
  } catch (error) {
    console.log('Offline random hadith error:', error);
    return null;
  }
};
