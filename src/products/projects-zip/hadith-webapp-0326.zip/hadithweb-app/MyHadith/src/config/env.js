import Config from 'react-native-config';

export const ABOUT_US_URL =
  Config.ABOUT_US_URL || 'https://myhadith.vercel.app/#about';
