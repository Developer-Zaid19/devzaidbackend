import React, {useCallback, useEffect, useState} from 'react';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  Alert,
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {useAppSettings} from '../context/AppSettingsContext';
import {
  collectionNameExists,
  createCollection,
  getBookmarkCollections,
  getCollections,
  saveHadithToCollection,
  toggleHadithInCollection,
} from '../services/bookmarks';

const SaveToCollectionModal = ({
  visible,
  hadith,
  bookTitle,
  volumeNumber,
  onClose,
  onChange,
}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const [collections, setCollections] = useState([]);
  const [selectedIds, setSelectedIds] = useState({});
  const [creating, setCreating] = useState(false);
  const [collectionName, setCollectionName] = useState('');

  const loadCollections = useCallback(async () => {
    const nextCollections = await getCollections();
    const activeCollections = hadith
      ? await getBookmarkCollections(hadith)
      : [];
    const nextSelectedIds = {};

    activeCollections.forEach(collection => {
      nextSelectedIds[collection.id] = true;
    });

    setCollections(nextCollections);
    setSelectedIds(nextSelectedIds);
  }, [hadith]);

  useEffect(() => {
    if (visible) {
      loadCollections();
    } else {
      setCreating(false);
      setCollectionName('');
    }
  }, [loadCollections, visible]);

  const handleToggleCollection = async collection => {
    if (!hadith) {
      return;
    }

    await toggleHadithInCollection(hadith, collection.id, {
      bookTitle,
      volumeNumber,
    });
    await loadCollections();

    if (onChange) {
      onChange();
    }
  };

  const handleCreateCollection = async () => {
    if (collectionNameExists(collections, collectionName)) {
      Alert.alert(
        'Already exists',
        'A collection with this name already exists.',
      );
      return;
    }

    const collection = await createCollection(collectionName);

    if (!collection) {
      Alert.alert('Not created', 'Please use a different collection name.');
      return;
    }

    if (hadith) {
      await saveHadithToCollection(hadith, collection.id, {
        bookTitle,
        volumeNumber,
      });
    }

    setCreating(false);
    setCollectionName('');
    await loadCollections();

    if (onChange) {
      onChange();
    }
  };

  const renderCollection = ({item}) => {
    const selected = Boolean(selectedIds[item.id]);

    return (
      <TouchableOpacity
        activeOpacity={0.85}
        style={styles.collectionRow}
        onPress={() => handleToggleCollection(item)}>
        <View style={styles.collectionIcon}>
          <MaterialCommunityIcons
            name="folder-outline"
            size={22}
            color={theme.colors.primary}
          />
        </View>

        <View style={styles.collectionTextBlock}>
          <Text style={styles.collectionName}>{item.name}</Text>
          <Text style={styles.collectionCount}>{item.items.length} saved</Text>
        </View>

        <MaterialCommunityIcons
          name={selected ? 'checkbox-marked-circle' : 'circle-outline'}
          size={24}
          color={selected ? theme.colors.primary : theme.colors.textSecondary}
        />
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      animationType="fade"
      transparent
      visible={visible}
      onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <View style={styles.headerRow}>
            <View>
              <Text style={styles.title}>Save to</Text>
              <Text style={styles.subtitle}>Choose collection</Text>
            </View>

            <View style={styles.headerActions}>
              <TouchableOpacity
                activeOpacity={0.85}
                onPress={() => setCreating(true)}
                style={styles.iconButton}>
                <MaterialCommunityIcons
                  name="folder-plus-outline"
                  size={22}
                  color={theme.colors.white}
                />
              </TouchableOpacity>

              <TouchableOpacity
                activeOpacity={0.85}
                onPress={onClose}
                style={styles.closeButton}>
                <MaterialCommunityIcons
                  name="close"
                  size={22}
                  color={theme.colors.textPrimary}
                />
              </TouchableOpacity>
            </View>
          </View>

          {creating ? (
            <View style={styles.createBox}>
              <TextInput
                autoFocus
                placeholder="Collection name"
                placeholderTextColor={theme.colors.textSecondary}
                value={collectionName}
                onChangeText={setCollectionName}
                style={styles.input}
              />

              <TouchableOpacity
                activeOpacity={0.85}
                onPress={handleCreateCollection}
                style={styles.confirmButton}>
                <MaterialCommunityIcons
                  name="check"
                  size={24}
                  color={theme.colors.background}
                />
              </TouchableOpacity>
            </View>
          ) : null}

          <FlatList
            data={collections}
            keyExtractor={item => item.id}
            renderItem={renderCollection}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.emptyBox}>
                <MaterialCommunityIcons
                  name="folder-plus-outline"
                  size={30}
                  color={theme.colors.primary}
                />
                <Text style={styles.emptyText}>
                  Create your first collection.
                </Text>
              </View>
            }
          />
        </View>
      </View>
    </Modal>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    backdrop: {
      flex: 1,
      justifyContent: 'flex-end',
      backgroundColor: 'rgba(0, 0, 0, 0.55)',
    },
    sheet: {
      maxHeight: '78%',
      backgroundColor: theme.colors.backgroundSecondary,
      borderTopLeftRadius: 24,
      borderTopRightRadius: 24,
      paddingHorizontal: 16,
      paddingTop: 16,
      paddingBottom: 10,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    headerRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 14,
    },
    title: {
      fontSize: 22,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
    },
    subtitle: {
      fontSize: 13,
      color: theme.colors.textSecondary,
      marginTop: 2,
      fontFamily: theme.typography.body,
    },
    headerActions: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    iconButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 8,
      backgroundColor: theme.colors.secondary,
    },
    closeButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.colors.surface,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    createBox: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 12,
    },
    input: {
      flex: 1,
      minHeight: 46,
      borderWidth: 1,
      borderColor: theme.colors.border,
      borderRadius: 14,
      paddingHorizontal: 14,
      color: theme.colors.textPrimary,
      backgroundColor: theme.colors.surface,
      fontFamily: theme.typography.body,
    },
    confirmButton: {
      width: 46,
      height: 46,
      borderRadius: 23,
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 10,
      backgroundColor: theme.colors.primary,
    },
    listContent: {
      paddingBottom: 14,
    },
    collectionRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      paddingHorizontal: 12,
      marginBottom: 10,
      borderRadius: 16,
      backgroundColor: theme.colors.surface,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    collectionIcon: {
      width: 42,
      height: 42,
      borderRadius: 21,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
      backgroundColor: theme.colors.primaryDim,
    },
    collectionTextBlock: {
      flex: 1,
      paddingRight: 10,
    },
    collectionName: {
      fontSize: 16,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
    },
    collectionCount: {
      fontSize: 12,
      color: theme.colors.textSecondary,
      marginTop: 3,
      fontFamily: theme.typography.body,
    },
    emptyBox: {
      alignItems: 'center',
      paddingVertical: 28,
    },
    emptyText: {
      color: theme.colors.textSecondary,
      marginTop: 8,
      fontFamily: theme.typography.body,
    },
  });

export default SaveToCollectionModal;
