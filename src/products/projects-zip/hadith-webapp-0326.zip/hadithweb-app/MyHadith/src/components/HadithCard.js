import React from 'react';
import Clipboard from '@react-native-clipboard/clipboard';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Alert, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {useAppSettings} from '../context/AppSettingsContext';
import {buildHadithCopyText} from '../utils/hadithCopy';

const LANGUAGE_OPTIONS = [
  {key: 'urdu', label: 'Urdu'},
  {key: 'english', label: 'English'},
  {key: 'arabic', label: 'Arbi'},
];

const getHadithText = (hadith, language) => {
  if (language === 'urdu') {
    return (
      hadith?.hadithUrdu || hadith?.hadithEnglish || 'Hadith not available'
    );
  }

  if (language === 'arabic') {
    return (
      hadith?.hadithArabic || hadith?.hadithEnglish || 'Hadith not available'
    );
  }

  return hadith?.hadithEnglish || hadith?.hadithUrdu || 'Hadith not available';
};

const HadithCard = ({
  hadith,
  onPress,
  previewLines,
  language = 'english',
  showLanguageToggle = false,
  onChangeLanguage,
  onToggleBookmark,
  isBookmarked = false,
  showBookmarkButton = false,
  bookTitle,
  volumeNumber,
}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const hadithText = getHadithText(hadith, language);

  const handleCopy = () => {
    Clipboard.setString(
      buildHadithCopyText({
        hadith,
        bookTitle,
        volumeNumber,
      }),
    );

    Alert.alert('Copied', 'Hadith text has been copied.');
  };

  return (
    <TouchableOpacity activeOpacity={0.9} onPress={onPress} style={styles.card}>
      <View style={styles.headerRow}>
        <View style={styles.metaBlock}>
          <Text style={styles.hadithNumber}>Hadith {hadith?.hadithNumber}</Text>
          <Text style={styles.bookName}>
            {bookTitle || hadith?.book?.bookName || 'Unknown Book'}
            {volumeNumber || hadith?.volume
              ? ` | Volume ${volumeNumber || hadith?.volume}`
              : ''}
          </Text>
        </View>

        <View style={styles.headerActions}>
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={handleCopy}
            style={styles.copyButton}>
            <MaterialCommunityIcons
              name="content-copy"
              size={18}
              color={theme.colors.white}
            />
          </TouchableOpacity>

          {showBookmarkButton ? (
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={onToggleBookmark}
              style={styles.bookmarkButton}>
              <MaterialCommunityIcons
                name={isBookmarked ? 'bookmark' : 'bookmark-outline'}
                size={22}
                color={
                  isBookmarked
                    ? theme.colors.primary
                    : theme.colors.textSecondary
                }
              />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {showLanguageToggle ? (
        <View style={styles.languageRow}>
          {LANGUAGE_OPTIONS.map(option => {
            const active = option.key === language;

            return (
              <TouchableOpacity
                key={option.key}
                activeOpacity={0.85}
                onPress={() => onChangeLanguage && onChangeLanguage(option.key)}
                style={[
                  styles.languageChip,
                  active ? styles.languageChipActive : null,
                ]}>
                <Text
                  style={[
                    styles.languageChipText,
                    active ? styles.languageChipTextActive : null,
                  ]}>
                  {option.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      ) : null}

      <Text
        style={[
          styles.hadithText,
          language === 'arabic' ? styles.arabicText : null,
        ]}
        numberOfLines={previewLines}>
        {hadithText}
      </Text>
    </TouchableOpacity>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    card: {
      backgroundColor: theme.colors.surface,
      marginVertical: 8,
      marginHorizontal: 12,
      padding: 15,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: theme.colors.border,
      elevation: 3,
    },
    headerRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginBottom: 12,
    },
    metaBlock: {
      flex: 1,
      paddingRight: 10,
    },
    headerActions: {
      flexDirection: 'row',
      alignItems: 'center',
      marginLeft: 8,
    },
    hadithNumber: {
      fontSize: 12,
      color: theme.colors.primary,
      textTransform: 'uppercase',
      letterSpacing: 0.8,
      fontFamily: theme.typography.heading,
    },
    bookName: {
      fontSize: 13,
      color: theme.colors.textSecondary,
      marginTop: 4,
      fontFamily: theme.typography.body,
    },
    copyButton: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: theme.colors.secondary,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 8,
    },
    bookmarkButton: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: 'transparent',
      alignItems: 'center',
      justifyContent: 'center',
    },
    languageRow: {
      flexDirection: 'row',
      marginBottom: 12,
    },
    languageChip: {
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 999,
      backgroundColor: theme.colors.backgroundTertiary,
      marginRight: 8,
    },
    languageChipActive: {
      backgroundColor: theme.colors.secondary,
    },
    languageChipText: {
      fontSize: 12,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.body,
    },
    languageChipTextActive: {
      color: theme.colors.white,
      fontFamily: theme.typography.heading,
    },
    hadithText: {
      fontSize: 16,
      color: theme.colors.textPrimary,
      lineHeight: 26,
      fontFamily: theme.typography.body,
    },
    arabicText: {
      textAlign: 'right',
      fontSize: 20,
      lineHeight: 34,
      fontFamily: theme.typography.arabic,
    },
  });

export default HadithCard;
