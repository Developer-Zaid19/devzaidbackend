import React from 'react';
import {ActivityIndicator, StyleSheet, Text, View} from 'react-native';

const AppSplash = ({theme, displayName}) => {
  const styles = getStyles(theme);
  const trimmedName = displayName.trim();

  return (
    <View style={styles.container}>
      <View style={styles.badge}>
        <Text style={styles.badgeText}>MyHadith</Text>
      </View>
      <Text style={styles.salam}>السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ</Text>
      {trimmedName ? (
        <Text style={styles.name}>Welcome, {trimmedName}</Text>
      ) : null}
      <Text style={styles.subtitle}>
        Authentic ahadith, beautifully arranged for daily reading.
      </Text>
      <ActivityIndicator
        size="small"
        color={theme.colors.primary}
        style={styles.loader}
      />
    </View>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 24,
      backgroundColor: theme.colors.background,
    },
    badge: {
      backgroundColor: theme.colors.primaryDim,
      borderRadius: 999,
      paddingHorizontal: 16,
      paddingVertical: 8,
      marginBottom: 18,
      borderWidth: 1,
      borderColor: theme.colors.primary,
    },
    badgeText: {
      color: theme.colors.primary,
      fontFamily: theme.typography.heading,
      fontSize: 14,
      letterSpacing: 1.1,
    },
    salam: {
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.arabic,
      fontSize: 28,
      lineHeight: 44,
      textAlign: 'center',
    },
    name: {
      marginTop: 12,
      color: theme.colors.primaryLight,
      fontFamily: theme.typography.heading,
      fontSize: 20,
      textAlign: 'center',
    },
    subtitle: {
      marginTop: 14,
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
      fontSize: 15,
      lineHeight: 24,
      textAlign: 'center',
      maxWidth: 300,
    },
    loader: {
      marginTop: 20,
    },
  });

export default AppSplash;
