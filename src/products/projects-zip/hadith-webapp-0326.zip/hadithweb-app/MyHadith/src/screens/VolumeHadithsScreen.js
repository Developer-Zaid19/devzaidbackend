import React, {useCallback, useEffect, useState} from 'react';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import HadithCard from '../components/HadithCard';
import SaveToCollectionModal from '../components/SaveToCollectionModal';
import {useAppSettings} from '../context/AppSettingsContext';
import {getBookHadithBatch} from '../services/api';
import {getBookmarkId, getBookmarks} from '../services/bookmarks';

const VolumeHadithsScreen = ({navigation, route}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const {book} = route.params;
  const [hadiths, setHadiths] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [savedMap, setSavedMap] = useState({});
  const [selectedHadith, setSelectedHadith] = useState(null);

  const loadSavedState = async () => {
    const bookmarks = await getBookmarks();
    const nextSavedMap = {};

    bookmarks.forEach(item => {
      nextSavedMap[item.bookmarkId] = true;
    });

    setSavedMap(nextSavedMap);
  };

  const loadInitialHadiths = useCallback(async () => {
    setLoading(true);

    const result = await getBookHadithBatch({
      bookSlug: book.id,
      page: 1,
      batchSize: 50,
    });

    await loadSavedState();
    setHadiths(result.hadiths);
    setPage(result.nextPage);
    setHasMore(result.hasMore);
    setLoading(false);
  }, [book.id]);

  useEffect(() => {
    loadInitialHadiths();
  }, [loadInitialHadiths]);

  const loadMoreHadiths = async () => {
    if (loadingMore || loading || !hasMore) {
      return;
    }

    setLoadingMore(true);

    const result = await getBookHadithBatch({
      bookSlug: book.id,
      page,
      batchSize: 50,
    });

    setHadiths(prev => [...prev, ...result.hadiths]);
    setPage(result.nextPage);
    setHasMore(result.hasMore);
    setLoadingMore(false);
  };

  const renderHadithCard = ({item}) => {
    return (
      <HadithCard
        hadith={item}
        previewLines={4}
        language="english"
        showBookmarkButton
        isBookmarked={Boolean(savedMap[getBookmarkId(item)])}
        onToggleBookmark={() => setSelectedHadith(item)}
        bookTitle={book.title}
        volumeNumber={item.volume}
        onPress={() =>
          navigation.navigate('HadithDetail', {
            hadith: item,
            bookTitle: book.title,
            volumeNumber: item.volume,
          })
        }
      />
    );
  };

  const renderFooter = () => {
    if (!loadingMore) {
      return null;
    }

    return (
      <View style={styles.footerLoader}>
        <ActivityIndicator size="small" color={theme.colors.primary} />
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={styles.loadingText}>اِنَّ اللّٰهَ مَعَ الصّٰبِرِيْنَ</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>{book.title}</Text>
      <Text style={styles.subheading}>50 hadiths per batch</Text>

      <FlatList
        data={hadiths}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        renderItem={renderHadithCard}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        onEndReached={loadMoreHadiths}
        onEndReachedThreshold={0.4}
        ListFooterComponent={renderFooter}
        ListEmptyComponent={
          <View style={styles.centered}>
            <Text style={styles.emptyText}>
              Is kitab ki hadiths nahi milin.
            </Text>
          </View>
        }
      />

      <SaveToCollectionModal
        visible={Boolean(selectedHadith)}
        hadith={selectedHadith}
        bookTitle={book.title}
        volumeNumber={selectedHadith?.volume}
        onClose={() => setSelectedHadith(null)}
        onChange={loadSavedState}
      />
    </View>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.colors.background,
      paddingTop: 18,
    },
    centered: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      paddingHorizontal: 24,
      backgroundColor: theme.colors.background,
    },
    heading: {
      fontSize: 24,
      color: theme.colors.textPrimary,
      paddingHorizontal: 16,
      fontFamily: theme.typography.heading,
    },
    subheading: {
      fontSize: 15,
      color: theme.colors.primary,
      paddingHorizontal: 16,
      marginTop: 4,
      marginBottom: 14,
      fontFamily: theme.typography.heading,
    },
    listContent: {
      paddingHorizontal: 16,
      paddingBottom: 24,
    },
    footerLoader: {
      paddingVertical: 16,
    },
    loadingText: {
      marginTop: 12,
      fontSize: 20,
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.arabic,
      textAlign: 'center',
    },
    emptyText: {
      fontSize: 15,
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
    },
  });

export default VolumeHadithsScreen;
