import React, {useCallback, useEffect, useState} from 'react';
import Clipboard from '@react-native-clipboard/clipboard';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {useAppSettings} from '../context/AppSettingsContext';
import SaveToCollectionModal from '../components/SaveToCollectionModal';
import {getBookmarkId, getBookmarks} from '../services/bookmarks';
import {buildHadithCopyText} from '../utils/hadithCopy';

const HadithDetailScreen = ({route}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const {hadith, bookTitle, volumeNumber} = route.params;
  const [saved, setSaved] = useState(false);
  const [saveModalVisible, setSaveModalVisible] = useState(false);

  const loadBookmarkState = useCallback(async () => {
    const bookmarks = await getBookmarks();
    const isSaved = bookmarks.some(
      item => item.bookmarkId === getBookmarkId(hadith),
    );
    setSaved(isSaved);
  }, [hadith]);

  useEffect(() => {
    loadBookmarkState();
  }, [loadBookmarkState]);

  const handleCopy = () => {
    Clipboard.setString(
      buildHadithCopyText({
        hadith,
        bookTitle,
        volumeNumber,
      }),
    );

    Alert.alert('Copied', 'Hadith text has been copied.');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.metaCard}>
        <View style={styles.actionsRow}>
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={handleCopy}
            style={styles.copyButton}>
            <MaterialCommunityIcons
              name="content-copy"
              size={20}
              color={theme.colors.white}
            />
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => setSaveModalVisible(true)}
            style={styles.saveButton}>
            <MaterialCommunityIcons
              name={saved ? 'bookmark' : 'bookmark-outline'}
              size={24}
              color={saved ? theme.colors.primary : theme.colors.textSecondary}
            />
          </TouchableOpacity>
        </View>

        <Text style={styles.metaLabel}>Hadith Number</Text>
        <Text style={styles.metaValue}>{hadith.hadithNumber}</Text>

        <Text style={styles.metaLabel}>Book</Text>
        <Text style={styles.metaValue}>
          {bookTitle || hadith.book?.bookName}
        </Text>

        <Text style={styles.metaLabel}>Volume</Text>
        <Text style={styles.metaValue}>{volumeNumber || hadith.volume}</Text>

        <Text style={styles.metaLabel}>Status</Text>
        <Text style={styles.metaValue}>{hadith.status || 'N/A'}</Text>
      </View>

      <View style={styles.contentCard}>
        <Text style={styles.sectionTitle}>English Narrator</Text>
        <Text style={styles.bodyText}>
          {hadith.englishNarrator || 'Not available'}
        </Text>

        <Text style={styles.sectionTitle}>Hadith</Text>
        <Text style={styles.bodyText}>
          {hadith.hadithEnglish || 'Not available'}
        </Text>

        <Text style={styles.sectionTitle}>Urdu</Text>
        <Text style={styles.bodyText}>
          {hadith.hadithUrdu || 'Not available'}
        </Text>

        <Text style={styles.sectionTitle}>Arabic</Text>
        <Text style={styles.arabicText}>
          {hadith.hadithArabic || 'Not available'}
        </Text>
      </View>

      <SaveToCollectionModal
        visible={saveModalVisible}
        hadith={hadith}
        bookTitle={bookTitle || hadith.book?.bookName}
        volumeNumber={volumeNumber || hadith.volume}
        onClose={() => setSaveModalVisible(false)}
        onChange={loadBookmarkState}
      />
    </ScrollView>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      padding: 16,
      backgroundColor: theme.colors.background,
    },
    metaCard: {
      backgroundColor: theme.colors.surface,
      borderRadius: 18,
      padding: 16,
      borderWidth: 1,
      borderColor: theme.colors.border,
      marginBottom: 14,
    },
    actionsRow: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      alignItems: 'center',
      marginBottom: 6,
    },
    copyButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.colors.secondary,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 8,
    },
    saveButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: 'transparent',
      alignItems: 'center',
      justifyContent: 'center',
    },
    metaLabel: {
      fontSize: 12,
      color: theme.colors.textSecondary,
      textTransform: 'uppercase',
      marginTop: 10,
      letterSpacing: 0.8,
      fontFamily: theme.typography.heading,
    },
    metaValue: {
      fontSize: 16,
      color: theme.colors.textPrimary,
      marginTop: 4,
      fontFamily: theme.typography.body,
    },
    contentCard: {
      backgroundColor: theme.colors.surface,
      borderRadius: 18,
      padding: 16,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    sectionTitle: {
      fontSize: 16,
      color: theme.colors.textPrimary,
      marginTop: 14,
      marginBottom: 8,
      fontFamily: theme.typography.heading,
    },
    bodyText: {
      fontSize: 15,
      lineHeight: 24,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.body,
    },
    arabicText: {
      fontSize: 20,
      lineHeight: 34,
      color: theme.colors.textPrimary,
      textAlign: 'right',
      fontFamily: theme.typography.arabic,
    },
  });

export default HadithDetailScreen;
