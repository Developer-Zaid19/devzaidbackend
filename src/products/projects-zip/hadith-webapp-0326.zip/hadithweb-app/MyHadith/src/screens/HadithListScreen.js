import React from 'react';
import {FlatList, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {useAppSettings} from '../context/AppSettingsContext';
import {books} from '../data/books';

const HadithListScreen = ({navigation}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);

  const renderBookCard = ({item}) => {
    return (
      <TouchableOpacity
        activeOpacity={0.85}
        style={styles.card}
        onPress={() => navigation.navigate('VolumeHadiths', {book: item})}>
        <Text style={styles.cardTitle}>{item.title}</Text>
        <Text style={styles.cardSubtitle}>Open collection</Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Hadith Library</Text>
      <Text style={styles.subheading}>Tap any Book and see their Ahadith.</Text>

      <FlatList
        data={books}
        keyExtractor={item => item.id}
        renderItem={renderBookCard}
        numColumns={2}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.colors.background,
      paddingTop: 18,
    },
    heading: {
      fontSize: 24,
      color: theme.colors.textPrimary,
      paddingHorizontal: 16,
      fontFamily: theme.typography.heading,
    },
    subheading: {
      fontSize: 14,
      color: theme.colors.textSecondary,
      paddingHorizontal: 16,
      marginTop: 4,
      marginBottom: 18,
      fontFamily: theme.typography.body,
    },
    listContent: {
      paddingHorizontal: 16,
      paddingBottom: 24,
    },
    row: {
      justifyContent: 'space-between',
      marginBottom: 14,
    },
    card: {
      width: '48%',
      minHeight: 130,
      borderRadius: 18,
      backgroundColor: theme.colors.surface,
      padding: 16,
      justifyContent: 'center',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: theme.colors.border,
      elevation: 2,
    },
    cardTitle: {
      fontSize: 18,
      color: theme.colors.textPrimary,
      textAlign: 'center',
      fontFamily: theme.typography.heading,
    },
    cardSubtitle: {
      fontSize: 12,
      color: theme.colors.primary,
      textTransform: 'uppercase',
      letterSpacing: 0.8,
      marginTop: 12,
      textAlign: 'center',
      fontFamily: theme.typography.body,
    },
  });

export default HadithListScreen;
