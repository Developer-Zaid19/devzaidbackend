import React, {useCallback, useState} from 'react';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  Alert,
  FlatList,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {useFocusEffect} from '@react-navigation/native';
import HadithCard from '../components/HadithCard';
import {useAppSettings} from '../context/AppSettingsContext';
import {
  collectionNameExists,
  createCollection,
  deleteCollection,
  getBookmarkId,
  getCollections,
  removeHadithFromCollection,
} from '../services/bookmarks';

const SavedScreen = ({navigation}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const [collections, setCollections] = useState([]);
  const [selectedCollectionId, setSelectedCollectionId] = useState(null);
  const [creating, setCreating] = useState(false);
  const [collectionName, setCollectionName] = useState('');

  const selectedCollection = collections.find(
    collection => collection.id === selectedCollectionId,
  );

  const loadCollections = useCallback(async () => {
    const nextCollections = await getCollections();
    setCollections(nextCollections);

    if (
      selectedCollectionId &&
      !nextCollections.some(
        collection => collection.id === selectedCollectionId,
      )
    ) {
      setSelectedCollectionId(null);
    }
  }, [selectedCollectionId]);

  useFocusEffect(
    useCallback(() => {
      loadCollections();
    }, [loadCollections]),
  );

  const handleCreateCollection = async () => {
    if (collectionNameExists(collections, collectionName)) {
      Alert.alert(
        'Already exists',
        'A collection with this name already exists.',
      );
      return;
    }

    const collection = await createCollection(collectionName);

    if (collection) {
      setCollectionName('');
      setCreating(false);
      await loadCollections();
      setSelectedCollectionId(collection.id);
    } else {
      Alert.alert('Not created', 'Please use a different collection name.');
    }
  };

  const handleDeleteCollection = collection => {
    Alert.alert(
      'Delete collection',
      `Delete "${collection.name}" and remove ${collection.items.length} saved hadiths from it?`,
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await deleteCollection(collection.id);

            if (selectedCollectionId === collection.id) {
              setSelectedCollectionId(null);
            }

            await loadCollections();
          },
        },
      ],
    );
  };

  const renderCollection = ({item}) => (
    <TouchableOpacity
      activeOpacity={0.85}
      style={styles.collectionCard}
      onPress={() => setSelectedCollectionId(item.id)}>
      <View style={styles.folderIcon}>
        <MaterialCommunityIcons
          name="folder-outline"
          size={28}
          color={theme.colors.primary}
        />
      </View>

      <View style={styles.collectionInfo}>
        <Text style={styles.collectionName} numberOfLines={1}>
          {item.name}
        </Text>
        <Text style={styles.collectionCount}>{item.items.length} saved</Text>
      </View>

      <View style={styles.collectionActions}>
        <TouchableOpacity
          activeOpacity={0.85}
          onPress={event => {
            event.stopPropagation();
            handleDeleteCollection(item);
          }}
          style={styles.deleteButton}>
          <MaterialCommunityIcons
            name="delete-outline"
            size={22}
            color={theme.colors.textSecondary}
          />
        </TouchableOpacity>

        <MaterialCommunityIcons
          name="chevron-right"
          size={24}
          color={theme.colors.textSecondary}
        />
      </View>
    </TouchableOpacity>
  );

  const renderHadith = ({item}) => (
    <HadithCard
      hadith={item}
      language="urdu"
      showBookmarkButton
      isBookmarked
      onToggleBookmark={async () => {
        await removeHadithFromCollection(item, selectedCollection.id);
        await loadCollections();
      }}
      bookTitle={item.savedBookTitle}
      volumeNumber={item.savedVolumeNumber}
      onPress={() =>
        navigation.navigate('HadithDetail', {
          hadith: item,
          bookTitle: item.savedBookTitle,
          volumeNumber: item.savedVolumeNumber,
        })
      }
    />
  );

  if (selectedCollection) {
    return (
      <View style={styles.container}>
        <View style={styles.headerRow}>
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => setSelectedCollectionId(null)}
            style={styles.roundButton}>
            <MaterialCommunityIcons
              name="arrow-left"
              size={22}
              color={theme.colors.textPrimary}
            />
          </TouchableOpacity>

          <View style={styles.headerTextBlock}>
            <Text style={styles.heading} numberOfLines={1}>
              {selectedCollection.name}
            </Text>
            <Text style={styles.subheading}>
              {selectedCollection.items.length} saved hadiths
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => handleDeleteCollection(selectedCollection)}
            style={styles.roundButton}>
            <MaterialCommunityIcons
              name="delete-outline"
              size={22}
              color={theme.colors.textSecondary}
            />
          </TouchableOpacity>
        </View>

        <FlatList
          data={selectedCollection.items}
          keyExtractor={item => item.bookmarkId || getBookmarkId(item)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={renderHadith}
          ListEmptyComponent={
            <View style={styles.emptyBox}>
              <Text style={styles.emptyText}>
                No hadiths in this collection.
              </Text>
            </View>
          }
        />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <View style={styles.headerTextBlock}>
          <Text style={styles.heading}>Saved</Text>
          <Text style={styles.subheading}>Your personal collections</Text>
        </View>

        <TouchableOpacity
          activeOpacity={0.85}
          onPress={() => setCreating(true)}
          style={styles.createButton}>
          <MaterialCommunityIcons
            name="folder-plus-outline"
            size={24}
            color={theme.colors.white}
          />
        </TouchableOpacity>
      </View>

      {creating ? (
        <View style={styles.createBox}>
          <TextInput
            autoFocus
            placeholder="Collection name"
            placeholderTextColor={theme.colors.textSecondary}
            value={collectionName}
            onChangeText={setCollectionName}
            style={styles.input}
          />

          <TouchableOpacity
            activeOpacity={0.85}
            onPress={handleCreateCollection}
            style={styles.confirmButton}>
            <MaterialCommunityIcons
              name="check"
              size={24}
              color={theme.colors.background}
            />
          </TouchableOpacity>
        </View>
      ) : null}

      <FlatList
        data={collections}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.collectionsContent}
        showsVerticalScrollIndicator={false}
        renderItem={renderCollection}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <MaterialCommunityIcons
              name="folder-plus-outline"
              size={34}
              color={theme.colors.primary}
            />
            <Text style={styles.emptyText}>No collections yet.</Text>
          </View>
        }
      />
    </View>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.colors.background,
      paddingTop: 18,
    },
    headerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 16,
      marginBottom: 12,
    },
    headerTextBlock: {
      flex: 1,
      paddingRight: 10,
    },
    heading: {
      fontSize: 24,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
    },
    subheading: {
      fontSize: 13,
      color: theme.colors.textSecondary,
      marginTop: 3,
      fontFamily: theme.typography.body,
    },
    createButton: {
      width: 46,
      height: 46,
      borderRadius: 23,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.colors.secondary,
    },
    roundButton: {
      width: 42,
      height: 42,
      borderRadius: 21,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
      backgroundColor: theme.colors.surface,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    createBox: {
      flexDirection: 'row',
      alignItems: 'center',
      marginHorizontal: 16,
      marginBottom: 12,
    },
    input: {
      flex: 1,
      minHeight: 46,
      borderWidth: 1,
      borderColor: theme.colors.border,
      borderRadius: 14,
      paddingHorizontal: 14,
      color: theme.colors.textPrimary,
      backgroundColor: theme.colors.surface,
      fontFamily: theme.typography.body,
    },
    confirmButton: {
      width: 46,
      height: 46,
      borderRadius: 23,
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 10,
      backgroundColor: theme.colors.primary,
    },
    collectionsContent: {
      paddingHorizontal: 16,
      paddingBottom: 24,
    },
    listContent: {
      paddingBottom: 24,
    },
    collectionCard: {
      flexDirection: 'row',
      alignItems: 'center',
      minHeight: 76,
      backgroundColor: theme.colors.surface,
      borderRadius: 16,
      padding: 14,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: theme.colors.border,
      elevation: 2,
    },
    folderIcon: {
      width: 48,
      height: 48,
      borderRadius: 24,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
      backgroundColor: theme.colors.primaryDim,
    },
    collectionInfo: {
      flex: 1,
      paddingRight: 10,
    },
    collectionName: {
      fontSize: 16,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
    },
    collectionCount: {
      fontSize: 12,
      color: theme.colors.textSecondary,
      marginTop: 4,
      fontFamily: theme.typography.body,
    },
    collectionActions: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    deleteButton: {
      width: 38,
      height: 38,
      borderRadius: 19,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 4,
      backgroundColor: theme.colors.backgroundTertiary,
    },
    emptyBox: {
      marginTop: 10,
      backgroundColor: theme.colors.surface,
      borderRadius: 16,
      padding: 22,
      borderWidth: 1,
      borderColor: theme.colors.border,
      alignItems: 'center',
    },
    emptyText: {
      color: theme.colors.textSecondary,
      marginTop: 8,
      fontFamily: theme.typography.body,
    },
  });

export default SavedScreen;
