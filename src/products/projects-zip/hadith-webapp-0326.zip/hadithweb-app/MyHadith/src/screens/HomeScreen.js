import React, {useCallback, useEffect, useState} from 'react';
import {
  ActivityIndicator,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import HadithCard from '../components/HadithCard';
import SaveToCollectionModal from '../components/SaveToCollectionModal';
import {useAppSettings} from '../context/AppSettingsContext';
import {books} from '../data/books';
import {getRandomHadith, searchHadithByNumber} from '../services/api';
import {getBookmarkId, getBookmarks} from '../services/bookmarks';

const HomeScreen = ({navigation}) => {
  const {theme} = useAppSettings();
  const styles = getStyles(theme);
  const [hadith, setHadith] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedBook, setSelectedBook] = useState('sahih-bukhari');
  const [hadithNumber, setHadithNumber] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('urdu');
  const [savedMap, setSavedMap] = useState({});
  const [saveModalVisible, setSaveModalVisible] = useState(false);

  const markBookmarkState = async nextHadith => {
    if (!nextHadith) {
      return;
    }

    const bookmarks = await getBookmarks();
    const bookmarkId = getBookmarkId(nextHadith);
    const isSaved = bookmarks.some(item => item.bookmarkId === bookmarkId);

    setSavedMap(prev => ({
      ...prev,
      [bookmarkId]: isSaved,
    }));
  };

  const loadRandomHadith = useCallback(async () => {
    setLoading(true);

    try {
      const randomHadith = await getRandomHadith();
      setHadith(randomHadith || null);
      await markBookmarkState(randomHadith);
    } catch (err) {
      console.log(err);
    }

    setLoading(false);
  }, []);

  useEffect(() => {
    loadRandomHadith();
  }, [loadRandomHadith]);

  const searchHadith = async () => {
    if (!hadithNumber) {
      return;
    }

    setLoading(true);

    try {
      const result = await searchHadithByNumber({
        bookSlug: selectedBook,
        hadithNumber,
      });

      setHadith(result);
      await markBookmarkState(result);
    } catch (err) {
      console.log(err);
    }

    setLoading(false);
  };

  const refreshCurrentSavedState = async () => {
    if (!hadith) {
      return;
    }

    await markBookmarkState(hadith);
  };

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.searchBox}>
        <Text style={styles.heading}>Daily Hadith</Text>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.booksRow}
          style={styles.booksScroll}>
          {books.map(book => (
            <TouchableOpacity
              key={book.id}
              activeOpacity={0.85}
              onPress={() => setSelectedBook(book.id)}
              style={[
                styles.bookChip,
                selectedBook === book.id ? styles.bookChipActive : null,
              ]}>
              <Text
                style={[
                  styles.bookChipText,
                  selectedBook === book.id ? styles.bookChipTextActive : null,
                ]}>
                {book.title}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <TextInput
          placeholder="Enter Hadith Number"
          placeholderTextColor={theme.colors.textSecondary}
          value={hadithNumber}
          onChangeText={setHadithNumber}
          style={styles.input}
        />

        <View style={styles.actionsRow}>
          <TouchableOpacity onPress={searchHadith} style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>Search</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={loadRandomHadith}
            style={styles.secondaryButton}>
            <Text style={styles.secondaryButtonText}>Random Hadith</Text>
          </TouchableOpacity>
        </View>
      </View>

      {hadith ? (
        <HadithCard
          hadith={hadith}
          language={selectedLanguage}
          showLanguageToggle
          onChangeLanguage={setSelectedLanguage}
          showBookmarkButton
          isBookmarked={Boolean(savedMap[getBookmarkId(hadith)])}
          onToggleBookmark={() => setSaveModalVisible(true)}
          onPress={() =>
            navigation.navigate('HadithDetail', {
              hadith,
              bookTitle: hadith?.book?.bookName,
              volumeNumber: hadith?.volume,
            })
          }
        />
      ) : (
        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>No Hadith Found</Text>
        </View>
      )}

      <SaveToCollectionModal
        visible={saveModalVisible}
        hadith={hadith}
        bookTitle={hadith?.book?.bookName}
        volumeNumber={hadith?.volume}
        onClose={() => setSaveModalVisible(false)}
        onChange={refreshCurrentSavedState}
      />
    </ScrollView>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      padding: 10,
      paddingBottom: 24,
      backgroundColor: theme.colors.background,
    },
    centered: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: theme.colors.background,
    },
    loadingText: {
      marginTop: 10,
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
    },
    searchBox: {
      backgroundColor: theme.colors.surface,
      borderRadius: 18,
      padding: 16,
      borderWidth: 1,
      borderColor: theme.colors.border,
      marginBottom: 12,
    },
    heading: {
      fontSize: 24,
      color: theme.colors.textPrimary,
      marginBottom: 14,
      fontFamily: theme.typography.heading,
    },
    booksScroll: {
      marginBottom: 10,
    },
    booksRow: {
      paddingRight: 10,
    },
    bookChip: {
      flexShrink: 0,
      marginRight: 10,
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 999,
      backgroundColor: theme.colors.backgroundTertiary,
      borderWidth: 1,
      borderColor: theme.colors.border,
    },
    bookChipActive: {
      backgroundColor: theme.colors.primaryDim,
      borderColor: theme.colors.primary,
    },
    bookChipText: {
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.body,
    },
    bookChipTextActive: {
      color: theme.colors.primary,
      fontFamily: theme.typography.heading,
    },
    input: {
      borderWidth: 1,
      borderColor: theme.colors.border,
      borderRadius: 12,
      padding: 12,
      marginBottom: 12,
      backgroundColor: theme.colors.backgroundSecondary,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.body,
    },
    actionsRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    primaryButton: {
      flex: 1,
      backgroundColor: theme.colors.primary,
      padding: 12,
      borderRadius: 12,
      alignItems: 'center',
      marginRight: 8,
    },
    primaryButtonText: {
      color: theme.colors.background,
      fontFamily: theme.typography.heading,
    },
    secondaryButton: {
      flex: 1,
      backgroundColor: theme.colors.secondary,
      padding: 12,
      borderRadius: 12,
      alignItems: 'center',
    },
    secondaryButtonText: {
      color: theme.colors.white,
      fontFamily: theme.typography.heading,
    },
    emptyBox: {
      backgroundColor: theme.colors.surface,
      borderRadius: 18,
      padding: 20,
      borderWidth: 1,
      borderColor: theme.colors.border,
      alignItems: 'center',
    },
    emptyText: {
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
    },
  });

export default HomeScreen;
