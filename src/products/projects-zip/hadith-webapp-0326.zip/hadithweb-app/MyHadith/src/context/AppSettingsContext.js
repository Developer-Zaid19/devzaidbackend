import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {createNavigationTheme, getTheme} from '../theme';

const SETTINGS_KEY = '@myhadith/settings';

const AppSettingsContext = createContext(null);

export const AppSettingsProvider = ({children}) => {
  const [mode, setMode] = useState('dark');
  const [displayName, setDisplayNameState] = useState('');
  const [isReady, setIsReady] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    let mounted = true;

    const bootstrap = async () => {
      try {
        const raw = await AsyncStorage.getItem(SETTINGS_KEY);

        if (raw && mounted) {
          const parsed = JSON.parse(raw);

          if (parsed?.mode === 'light' || parsed?.mode === 'dark') {
            setMode(parsed.mode);
          }

          if (typeof parsed?.displayName === 'string') {
            setDisplayNameState(parsed.displayName);
          }
        }
      } catch (error) {
        console.log('Settings read error:', error);
      } finally {
        if (mounted) {
          setIsReady(true);
        }
      }
    };

    bootstrap();

    const timer = setTimeout(() => {
      if (mounted) {
        setShowSplash(false);
      }
    }, 1800);

    return () => {
      mounted = false;
      clearTimeout(timer);
    };
  }, []);

  const persistSettings = useCallback(async nextSettings => {
    try {
      await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(nextSettings));
    } catch (error) {
      console.log('Settings write error:', error);
    }
  }, []);

  const updateMode = useCallback(
    async nextMode => {
      setMode(nextMode);
      await persistSettings({
        mode: nextMode,
        displayName,
      });
    },
    [displayName, persistSettings],
  );

  const updateDisplayName = useCallback(
    async nextName => {
      const sanitized = nextName.trim();
      setDisplayNameState(sanitized);
      await persistSettings({
        mode,
        displayName: sanitized,
      });
    },
    [mode, persistSettings],
  );

  const value = useMemo(() => {
    const theme = getTheme(mode);

    return {
      mode,
      displayName,
      isDarkMode: mode === 'dark',
      isReady,
      showSplash,
      theme,
      navigationTheme: createNavigationTheme(mode),
      setMode: updateMode,
      toggleTheme: () => updateMode(mode === 'dark' ? 'light' : 'dark'),
      setDisplayName: updateDisplayName,
    };
  }, [displayName, isReady, mode, showSplash, updateDisplayName, updateMode]);

  return (
    <AppSettingsContext.Provider value={value}>
      {children}
    </AppSettingsContext.Provider>
  );
};

export const useAppSettings = () => {
  const context = useContext(AppSettingsContext);

  if (!context) {
    throw new Error('useAppSettings must be used within AppSettingsProvider');
  }

  return context;
};
