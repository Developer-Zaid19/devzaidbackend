import React from 'react';
import renderer from 'react-test-renderer';
import {TextInput} from 'react-native';
import CheckoutScreen from '../src/screens/CheckoutScreen';
import {useAppSettings} from '../src/context/AppSettingsContext';
import {useCart} from '../src/context/CartContext';

jest.mock('../src/context/AppSettingsContext', () => ({
  useAppSettings: jest.fn(),
}));

jest.mock('../src/context/CartContext', () => ({
  useCart: jest.fn(),
}));

jest.mock('react-native-vector-icons/MaterialCommunityIcons', () => 'MaterialCommunityIcons');

describe('CheckoutScreen dark mode inputs', () => {
  beforeEach(() => {
    useAppSettings.mockReturnValue({
      theme: {
        isDark: true,
        colors: {
          background: '#111110',
          backgroundSecondary: '#1C1C1A',
          backgroundTertiary: '#232320',
          surface: '#1C1C1A',
          border: '#2E2E2A',
          textPrimary: '#F0F0EC',
          textSecondary: '#9E9E96',
          primary: '#059669',
          white: '#FFFFFF',
        },
      },
    });

    useCart.mockReturnValue({
      clearCart: jest.fn(),
      subtotal: 20,
      shipping: 5,
      total: 25,
    });
  });

  it('applies visible border styling to checkout inputs in dark mode', () => {
    const tree = renderer.create(
      <CheckoutScreen navigation={{goBack: jest.fn(), navigate: jest.fn()}} />,
    );

    const inputs = tree.root.findAllByType(TextInput);
    expect(inputs.length).toBeGreaterThan(0);

    const styles = inputs.map(input =>
      Array.isArray(input.props.style) ? input.props.style : [input.props.style],
    );

    expect(styles).toEqual(
      expect.arrayContaining([
        expect.arrayContaining([
          expect.objectContaining({
            borderWidth: 1,
            borderColor: '#2E2E2A',
          }),
        ]),
      ]),
    );
  });
});
