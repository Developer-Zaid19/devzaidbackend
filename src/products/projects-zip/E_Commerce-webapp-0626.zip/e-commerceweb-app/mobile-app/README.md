# Aurevia

Aurevia is a modern e-commerce mobile application template built with React Native CLI. The project focuses on delivering a clean shopping experience UI and can serve as a foundation for building a complete e-commerce application.

> This project currently uses local product data and assets, making it ideal as a starter template for future backend integration.

## Features

* Modern e-commerce user interface
* Product listing screen
* Product detail view
* Category-based browsing
* Shopping cart interface
* Responsive mobile layouts
* Local product data management
* Reusable React Native components
* Clean and scalable project structure

## Tech Stack

* React Native CLI
* JavaScript
* React Hooks (`useState`, `useEffect`)

## Project Structure

```text
Aurevia/
├── data/
├── Media/
│   └── Productsimg/
├── components/
├── screens/
├── navigation/
├── utils/
└── App.js
```

## Data Source

The application currently uses local static data stored within the project.

No backend, authentication system, database, or external API is required.

## Installation

### Clone Repository

```bash
git clone <repository-url>
cd Aurevia
```

### Install Dependencies

```bash
npm install
```

### Start Metro Server

```bash
npx react-native start
```

### Run on Android

```bash
npx react-native run-android
```

## Build Release APK

Navigate to the Android directory:

```bash
cd android
```

Generate a release APK:

```bash
./gradlew assembleRelease
```

Generated APK location:

```text
android/app/build/outputs/apk/release/app-release.apk
```

## Customization

You can easily extend Aurevia by adding:

* Backend APIs
* User Authentication
* Product Search
* Wishlist Functionality
* Payment Gateway Integration
* Order Management
* Push Notifications
* User Profiles

## Purpose

This project is intended as a reusable React Native e-commerce template that developers can use as a starting point for building production-ready shopping applications.

## License

MIT License
