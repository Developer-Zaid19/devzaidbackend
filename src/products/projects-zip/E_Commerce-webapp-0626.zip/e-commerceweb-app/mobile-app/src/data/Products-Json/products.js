const products = [
  {
    id: "aur-1001",
    name: "Luma Ceramic Table Lamp",
    category: "Home",
    price: 78,
    rating: 4.8,
    stock: 18,
    badge: "Best seller",
    image: require("../productsimg/lamp.webp"),
    description: "Soft matte ceramic lamp with warm ambient glow for desks, shelves, and bedside corners.",
    embedding: []
  },
  {
    id: "aur-1002",
    name: "Nord Wireless Headphones",
    category: "Tech",
    price: 129,
    rating: 4.7,
    stock: 24,
    badge: "New",
    image: require("../productsimg/headphone.webp"),
    description: "Cushioned wireless headphones tuned for deep focus, travel, and clean calls.",
    embedding: []
  },
  {
    id: "aur-1003",
    name: "Atlas Weekender Duffel",
    category: "Travel",
    price: 96,
    rating: 4.9,
    stock: 12,
    badge: "Limited",
    image: require("../productsimg/bag.webp"),
    description: "Structured canvas duffel with smart pockets and a compact carry-on profile.",
    embedding: []
  },
  {
    id: "aur-1004",
    name: "Sora Linen Throw",
    category: "Home",
    price: 54,
    rating: 4.6,
    stock: 33,
    badge: "Cozy pick",
    image: require("../productsimg/sofa.webp"),
    description: "Breathable linen-cotton throw woven for year-round comfort and quiet texture.",
    embedding: []
  },
  {
    id: "aur-1005",
    name: "Pulse Smart Bottle",
    category: "Wellness",
    price: 42,
    rating: 4.5,
    stock: 29,
    badge: "Popular",
    image: require("../productsimg/waterbottle.webp"),
    description: "Double-wall bottle with hydration reminders and a leakproof stainless build.",
    embedding: []
  },
  {
    id: "aur-1006",
    name: "Mira Ribbed Knit Set",
    category: "Fashion",
    price: 88,
    rating: 4.7,
    stock: 16,
    badge: "Soft touch",
    image: require("../productsimg/garments.webp"),
    description: "Relaxed ribbed knit set made for polished weekends and easy layering.",
    embedding: []
  },
  {
    id: "aur-1007",
    name: "Terra Desk Organizer",
    category: "Office",
    price: 36,
    rating: 4.4,
    stock: 41,
    badge: "Clean desk",
    image: require("../productsimg/penpencil.webp"),
    description: "Modular desktop organizer with trays for tools, notes, cables, and daily essentials.",
    embedding: []
  },
  {
    id: "aur-1008",
    name: "Echo Mini Speaker",
    category: "Tech",
    price: 67,
    rating: 4.6,
    stock: 20,
    badge: "Compact",
    image: require("../productsimg/speaker.webp"),
    description: "Portable speaker with punchy sound, textured grip, and all-day battery life.",
    embedding: []
  },
  {
    id: "aur-1009",
    name: "Bloom Skincare Duo",
    category: "Wellness",
    price: 59,
    rating: 4.8,
    stock: 22,
    badge: "Glow kit",
    image: require("../productsimg/skincream.webp"),
    description: "Gentle cleanser and daily moisturizer pairing for a simple morning routine.",
    embedding: []
  }
];

export default products;