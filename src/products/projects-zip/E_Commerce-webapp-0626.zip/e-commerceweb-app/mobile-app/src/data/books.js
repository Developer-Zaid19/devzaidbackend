export const books = [
  {
    id: 'sahih-bukhari',
    title: 'Sahih Bukhari',
    volumes: 9,
  },
  {
    id: 'sahih-muslim',
    title: 'Sahih Muslim',
    volumes: 7,
  },
  {
    id: 'al-tirmidhi',
    title: 'Al Tirmidhi',
    volumes: 6,
  },
  {
    id: 'abu-dawood',
    title: 'Abu Dawood',
    volumes: 5,
  },
  {
    id: 'ibn-e-majah',
    title: 'Ibn e Majah',
    volumes: 5,
  },
  {
    id: 'sunan-nasai',
    title: 'Sunan Nasai',
    volumes: 6,
  },
  {
    id: 'mishkat',
    title: 'Mishkat',
    volumes: 4,
  },
];
