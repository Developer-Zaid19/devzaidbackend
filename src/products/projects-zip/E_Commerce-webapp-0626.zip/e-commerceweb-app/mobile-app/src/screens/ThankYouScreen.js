import React from 'react';
import {View, Text, TouchableOpacity, StatusBar} from 'react-native';
import tw from 'twrnc';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAppSettings} from '../context/AppSettingsContext';

export default function ThankYouScreen({navigation}) {
  const {theme} = useAppSettings();
  const {colors} = theme;

  return (
    <View style={[tw`flex-1 items-center justify-center px-6`, {backgroundColor: colors.background}]}> 
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <View style={[
        tw`items-center justify-center w-24 h-24 rounded-full mb-6`,
        {backgroundColor: colors.primary + '20'},
      ]}>
        <MaterialCommunityIcons name="check-decagram" size={44} color={colors.primary} />
      </View>

      <Text style={[tw`text-3xl font-black text-center`, {color: colors.textPrimary}]}> 
        Thank you for your order!
      </Text>

      <Text style={[tw`text-base text-center mt-3`, {color: colors.textSecondary}]}> 
        Your purchase is confirmed and a receipt has been sent to your email.
      </Text>

      <TouchableOpacity
        activeOpacity={0.9}
        onPress={() => navigation.navigate('Tabs', {screen: 'Home'})}
        style={[
          tw`mt-8 px-6 py-4 rounded-full`,
          {backgroundColor: colors.primary},
        ]}>
        <Text style={[tw`text-base font-black`, {color: colors.white}]}>Continue shopping</Text>
      </TouchableOpacity>
    </View>
  );
}
