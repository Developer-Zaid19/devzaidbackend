import React from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  Image,
} from "react-native";
import { useNavigation } from "@react-navigation/native";
import { getTheme } from "../theme";
import products from '../data/Products-Json/products';
import { useCart } from "../context/CartContext";
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';

const { width } = Dimensions.get("window");


const categories = [...new Set(products.map(item => item.category))]
  .map(category => ({
    name: category,
    icon: '📦',
  }));

const flashSaleProducts = products
  .slice(0, 5)
  .map(item => ({
    ...item,
    oldPrice: `$${Math.round(item.price * 1.3)}`,
    price: `$${item.price}`,
    discount: `-${Math.round(
      ((item.price * 1.3 - item.price) /
        (item.price * 1.3)) *
      100,
    )}%`,
  }));

const featuredProducts = products.slice(0, 4);

const recommendedProducts = [...products]
  .sort((a, b) => b.rating - a.rating)
  .slice(0, 5);

  const brands = [...new Set(products.map(item => item.category))];

export default function HomeScreen({ colorScheme = "dark" }) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const { colors } = theme;
  const s = styles(colors);
  const navigation = useNavigation();
  const { addItem, cartCount } = useCart();
  const { toggleFavorite, isFavorite } = useFavorites();

  const handleGoToCart = () => navigation.navigate('Cart');

  return (
    <View
      style={[
        s.root,
        {
          backgroundColor: colors.background,
        },
      ]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={s.scrollContent}>
        <View style={s.header}>
          <View>
            <Text style={s.greeting}>
              Welcome Back 👋
            </Text>

            <Text style={s.headerTitle}>
              Find Your Next Purchase
            </Text>
          </View>

          <TouchableOpacity style={s.iconButton} onPress={handleGoToCart}>
            <Text style={s.iconText}>🛒</Text>

            {cartCount > 0 ? (
              <View style={s.badge}>
                <Text style={s.badgeText}>{cartCount}</Text>
              </View>
            ) : null}
          </TouchableOpacity>
        </View>

        <View style={s.searchContainer}>
          <TouchableOpacity
            activeOpacity={0.9}
            onPress={() => navigation.navigate('Search')}
            style={s.searchBar}>
            <Text style={s.searchIcon}>🔍</Text>

            <Text style={s.searchPlaceholder}>
              Search products, brands...
            </Text>
          </TouchableOpacity>
        </View>

        <View style={s.categoriesSection}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>Categories</Text>

            <TouchableOpacity>
              <Text style={s.sectionLink}>See All</Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={s.categoriesRow}>
            {categories.map(item => (
              <TouchableOpacity
                key={item.name}
                style={s.categoryCard}>
                <View style={s.categoryIcon}>
                  <Text style={s.categoryEmoji}>
                    {item.icon}
                  </Text>
                </View>

                <Text style={s.categoryName}>
                  {item.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        <View style={s.saleBanner}>
          <View style={s.saleContent}>
            <Text style={s.saleBadge}>
              LIMITED OFFER
            </Text>

            <Text style={s.saleTitle}>
              Summer Sale
            </Text>

            <Text style={s.saleSubtitle}>
              Up to 70% OFF on selected items
            </Text>

            <TouchableOpacity
              style={s.shopNowBtn}
              onPress={() => navigation.navigate('Products')}>
              <Text style={s.shopNowText}>
                Shop Now →
              </Text>
            </TouchableOpacity>
          </View>

          <View style={s.saleCircleLarge} />
          <View style={s.saleCircleSmall} />
        </View>

        <View style={s.flashSection}>
          <View style={s.sectionHeader}>
            <View>
              <Text style={s.sectionTitle}>
                Flash Sale ⚡
              </Text>

              <Text style={s.flashSubtitle}>
                Ending in 02:14:37
              </Text>
            </View>

            <TouchableOpacity>
              <Text style={s.sectionLink}>
                View All
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={s.flashRow}>
            {flashSaleProducts.map(item => (
              <TouchableOpacity
                key={item.id}
                style={s.flashCard}
                onPress={() => navigation.navigate('ProductDetail', {product: item})}>
<View style={s.flashImage}>
  <Image
    source={item.image}
    style={{
      width: "100%",
      height: "100%",
      borderRadius: 16,
    }}
    resizeMode="cover"
  />

  <View style={s.discountBadge}>
    <Text style={s.discountText}>
      {item.discount}
    </Text>
  </View>
</View>

                <View style={s.flashInfo}>
                  <Text
                    numberOfLines={1}
                    style={s.flashName}>
                    {item.name}
                  </Text>

                  <View style={s.priceRow}>
                    <Text style={s.flashPrice}>
                      {item.price}
                    </Text>

                    <Text style={s.oldPrice}>
                      {item.oldPrice}
                    </Text>
                  </View>

                  <TouchableOpacity
                    style={s.addPill}
                    onPress={event => {
                      event.stopPropagation();
                      addItem(item);
                    }}>
                    <Text style={s.addPillText}>Add to cart</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={s.productsSection}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>
              Featured Products
            </Text>

            <TouchableOpacity>
              <Text style={s.sectionLink}>
                See All
              </Text>
            </TouchableOpacity>
          </View>

          <View style={s.productsGrid}>
            {featuredProducts.map(item => (
              <TouchableOpacity
                key={item.id}
                style={s.productCard}
                onPress={() => navigation.navigate('ProductDetail', {product: item})}>
                <TouchableOpacity
                  style={[
                    s.heartButton,
                    {
                      backgroundColor: isFavorite(item.id) ? colors.primary : colors.surfaceElevated,
                    },
                  ]}
                  onPress={event => {
                    event.stopPropagation();
                    toggleFavorite(item);
                  }}>
                  <Text>{isFavorite(item.id) ? '❤️' : '🤍'}</Text>
                </TouchableOpacity>

<View style={s.productImage}>
  <Image
    source={item.image}
    style={{
      width: "100%",
      height: "100%",
    }}
    resizeMode="cover"
  />
</View>

                <View style={s.productContent}>
                  <Text
                    numberOfLines={2}
                    style={s.productTitle}>
                    {item.name}
                  </Text>

                  <Text style={s.productPrice}>
                    ${item.price}
                  </Text>

                  <TouchableOpacity
                    style={s.addPill}
                    onPress={event => {
                      event.stopPropagation();
                      addItem(item);
                    }}>
                    <Text style={s.addPillText}>Add</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        <View style={s.recommendedSection}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>
              Recommended For You
            </Text>

            <TouchableOpacity>
              <Text style={s.sectionLink}>
                View All
              </Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={s.recommendedRow}>
            {recommendedProducts.map(item => (
              <TouchableOpacity
                key={item.id}
                style={s.recommendedCard}
                onPress={() => navigation.navigate('ProductDetail', {product: item})}>

<View style={s.recommendedImage}>
  <Image
    source={item.image}
    style={{
      width: "100%",
      height: "100%",
      borderRadius: 14,
    }}
    resizeMode="cover"
  />
</View>

                <View style={s.recommendedContent}>
                  <Text
                    numberOfLines={1}
                    style={s.recommendedTitle}>
                    {item.name}
                  </Text>

                  <View style={s.ratingRow}>
                    <Text style={s.star}>
                      ⭐
                    </Text>

                    <Text style={s.ratingText}>
                      {item.rating}
                    </Text>
                  </View>

                  <Text style={s.recommendedPrice}>
                    ${item.price}
                  </Text>

                  <TouchableOpacity
                    style={s.addPill}
                    onPress={event => {
                      event.stopPropagation();
                      addItem(item);
                    }}>
                    <Text style={s.addPillText}>Add</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={s.brandSection}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>
              Popular Brands
            </Text>
          </View>

          <View style={s.brandGrid}>
            {brands.map(
              brand => (
                <TouchableOpacity
                  key={brand}
                  style={s.brandCard}>
                  <Text style={s.brandText}>
                    {brand}
                  </Text>
                </TouchableOpacity>
              ),
            )}
          </View>
        </View>
        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const styles = (colors) =>
  StyleSheet.create({
    root: { flex: 1 },
    scrollContent: {
      paddingBottom: 40,
    },

    header: {
      paddingHorizontal: 20,
      paddingTop: 24,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },

    greeting: {
      color: colors.textSecondary,
      fontSize: 14,
      fontWeight: '600',
    },

    headerTitle: {
      color: colors.textPrimary,
      fontSize: 28,
      fontWeight: '900',
      marginTop: 4,
      maxWidth: 220,
    },

    iconButton: {
      width: 56,
      height: 56,
      borderRadius: 18,
      backgroundColor: colors.surface,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'relative',
    },

    iconText: {
      fontSize: 24,
    },

    badge: {
      position: 'absolute',
      right: -2,
      top: -2,
      width: 20,
      height: 20,
      borderRadius: 10,
      backgroundColor: colors.primary,
      justifyContent: 'center',
      alignItems: 'center',
    },

    badgeText: {
      fontSize: 10,
      fontWeight: '900',
      color: colors.background,
    },

    searchContainer: {
      paddingHorizontal: 20,
      marginTop: 20,
    },

    searchBar: {
      height: 58,
      borderRadius: 18,
      backgroundColor: colors.surface,
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 18,
    },

    searchIcon: {
      fontSize: 18,
    },

    searchPlaceholder: {
      marginLeft: 12,
      color: colors.textSecondary,
      fontSize: 15,
    },
    categoriesSection: {
      marginTop: 28,
    },

    sectionHeader: {
      paddingHorizontal: 20,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16,
    },

    sectionTitle: {
      fontSize: 22,
      fontWeight: '900',
      color: colors.textPrimary,
    },

    sectionLink: {
      color: colors.primary,
      fontWeight: '700',
    },

    categoriesRow: {
      paddingHorizontal: 20,
    },

    categoryCard: {
      width: 92,
      marginRight: 14,
      alignItems: 'center',
    },

    categoryIcon: {
      width: 72,
      height: 72,
      borderRadius: 22,
      backgroundColor: colors.surface,
      justifyContent: 'center',
      alignItems: 'center',

      shadowColor: colors.shadow,
      shadowOpacity: 0.15,
      shadowRadius: 10,
      shadowOffset: {
        width: 0,
        height: 4,
      },

      elevation: 5,
    },

    categoryEmoji: {
      fontSize: 30,
    },

    categoryName: {
      marginTop: 10,
      fontSize: 13,
      fontWeight: '700',
      color: colors.textPrimary,
      textAlign: 'center',
    },
    saleBanner: {
      marginHorizontal: 20,
      marginTop: 30,
      borderRadius: 28,
      overflow: 'hidden',

      backgroundColor: colors.primary,

      minHeight: 190,

      padding: 24,

      justifyContent: 'center',

      position: 'relative',
    },

    saleContent: {
      zIndex: 5,
    },

    saleBadge: {
      color: colors.background,
      fontWeight: '800',
      fontSize: 12,
      letterSpacing: 1.2,
    },

    saleTitle: {
      marginTop: 8,
      color: colors.background,
      fontSize: 34,
      fontWeight: '900',
    },

    saleSubtitle: {
      marginTop: 8,
      color: colors.background,
      opacity: 0.85,
      fontSize: 15,
    },

    shopNowBtn: {
      marginTop: 20,

      alignSelf: 'flex-start',

      backgroundColor: colors.surface,

      paddingHorizontal: 20,
      paddingVertical: 12,

      borderRadius: 999,
    },

    shopNowText: {
      color: colors.textPrimary,
      fontWeight: '800',
    },

    saleCircleLarge: {
      position: 'absolute',

      width: 220,
      height: 220,

      borderRadius: 110,

      backgroundColor: 'rgba(255,255,255,0.12)',

      right: -70,
      top: -40,
    },

    saleCircleSmall: {
      position: 'absolute',

      width: 120,
      height: 120,

      borderRadius: 60,

      backgroundColor: 'rgba(255,255,255,0.10)',

      right: 20,
      bottom: -40,
    },
    flashSection: {
      marginTop: 30,
    },

    flashSubtitle: {
      color: colors.textSecondary,
      marginTop: 4,
      fontSize: 13,
    },

    flashRow: {
      paddingHorizontal: 20,
    },

    flashCard: {
      width: 190,

      marginRight: 16,

      borderRadius: 24,

      backgroundColor: colors.surface,

      overflow: 'hidden',

      shadowColor: colors.shadow,
      shadowOpacity: 0.15,
      shadowRadius: 10,
      shadowOffset: {
        width: 0,
        height: 4,
      },

      elevation: 5,
    },

    flashImage: {
      height: 160,

      backgroundColor:
        colors.backgroundTertiary,

      justifyContent: 'center',
      alignItems: 'center',

      position: 'relative',
    },

    productEmoji: {
      fontSize: 60,
    },

    discountBadge: {
      position: 'absolute',

      top: 12,
      left: 12,

      backgroundColor: '#ff4d4f',

      paddingHorizontal: 10,
      paddingVertical: 6,

      borderRadius: 999,
    },

    discountText: {
      color: '#fff',
      fontWeight: '900',
      fontSize: 11,
    },

    flashInfo: {
      padding: 14,
    },

    addPill: {
      marginTop: 10,
      alignSelf: 'flex-start',
      backgroundColor: colors.primary,
      paddingHorizontal: 12,
      paddingVertical: 8,
      borderRadius: 999,
    },

    addPillText: {
      color: colors.white,
      fontSize: 12,
      fontWeight: '800',
    },

    flashName: {
      color: colors.textPrimary,
      fontSize: 15,
      fontWeight: '800',
    },

    priceRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 8,
    },

    flashPrice: {
      color: colors.primary,
      fontWeight: '900',
      fontSize: 18,
    },

    oldPrice: {
      marginLeft: 8,

      color: colors.textSecondary,

      textDecorationLine: 'line-through',

      fontSize: 13,
    },
    productsSection: {
      marginTop: 34,
    },

    productsGrid: {
      paddingHorizontal: 20,

      flexDirection: 'row',

      flexWrap: 'wrap',

      justifyContent: 'space-between',
    },

    productCard: {
      width: '48%',

      backgroundColor: colors.surface,

      borderRadius: 22,

      overflow: 'hidden',

      marginBottom: 16,
    },

    heartButton: {
      position: 'absolute',

      right: 10,
      top: 10,

      zIndex: 10,

      width: 36,
      height: 36,

      borderRadius: 18,

      backgroundColor: colors.surfaceElevated,

      justifyContent: 'center',
      alignItems: 'center',
    },

    productImage: {
      height: 170,

      backgroundColor:
        colors.backgroundTertiary,

      justifyContent: 'center',
      alignItems: 'center',
    },

    productPlaceholder: {
      fontSize: 50,
    },

    productContent: {
      padding: 14,
    },

    productTitle: {
      color: colors.textPrimary,
      fontSize: 15,
      fontWeight: '700',
    },

    productPrice: {
      marginTop: 8,

      color: colors.primary,

      fontSize: 18,

      fontWeight: '900',
    },
    recommendedSection: {
      marginTop: 30,
    },

    recommendedRow: {
      paddingHorizontal: 20,
    },

    recommendedCard: {
      width: 220,

      backgroundColor: colors.surface,

      borderRadius: 24,

      overflow: 'hidden',

      marginRight: 16,
    },

    recommendedImage: {
      height: 140,

      backgroundColor:
        colors.backgroundTertiary,

      justifyContent: 'center',
      alignItems: 'center',
    },

    recommendedContent: {
      padding: 14,
    },

    recommendedTitle: {
      color: colors.textPrimary,
      fontSize: 16,
      fontWeight: '800',
    },

    ratingRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 6,
    },

    star: {
      fontSize: 14,
    },

    ratingText: {
      color: colors.textSecondary,
      marginLeft: 4,
    },

    recommendedPrice: {
      marginTop: 10,

      color: colors.primary,

      fontSize: 18,

      fontWeight: '900',
    },
    brandSection: {
      marginTop: 34,
    },

    brandGrid: {
      paddingHorizontal: 20,

      flexDirection: 'row',

      flexWrap: 'wrap',

      justifyContent: 'space-between',
    },

    brandCard: {
      width: '48%',

      height: 80,

      marginBottom: 12,

      borderRadius: 20,

      backgroundColor: colors.surface,

      justifyContent: 'center',
      alignItems: 'center',
    },

    brandText: {
      color: colors.textPrimary,

      fontWeight: '900',

      fontSize: 18,
    },
  });

