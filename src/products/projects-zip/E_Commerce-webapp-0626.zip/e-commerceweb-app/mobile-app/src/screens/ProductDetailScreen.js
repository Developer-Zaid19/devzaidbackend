import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import tw from 'twrnc';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {getTheme} from '../theme';
import {useCart} from '../context/CartContext';
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';

export default function ProductDetailScreen({route, navigation, colorScheme = 'dark'}) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const {colors} = theme;
  const {addItem} = useCart();
  const { toggleFavorite, isFavorite } = useFavorites();
  const {product} = route.params || {};

  if (!product) {
    return (
      <View style={[tw`flex-1 items-center justify-center`, {backgroundColor: colors.background}]}> 
        <Text style={[tw`text-lg font-semibold`, {color: colors.textPrimary}]}>Product not found</Text>
      </View>
    );
  }

  return (
    <View style={[tw`flex-1`, {backgroundColor: colors.background}]}> 
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={tw`pb-8`}>
        <View style={tw`px-4 pt-4`}>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation.goBack()}
            style={[
              tw`w-12 h-12 rounded-2xl items-center justify-center mb-4`,
              {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border},
            ]}>
            <MaterialCommunityIcons name="arrow-left" size={22} color={colors.textPrimary} />
          </TouchableOpacity>

          <Image
            source={product.image}
            style={[
              tw`w-full rounded-[28px]`,
              {
                height: 280,
                backgroundColor: colors.backgroundSecondary,
              },
            ]}
            resizeMode="cover"
          />

          <View style={[tw`mt-5 rounded-[28px] p-5`, {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border}]}> 
            <View style={tw`flex-row items-start justify-between`}>
              <View style={tw`flex-1 pr-3`}>
                <Text style={[tw`text-xs font-semibold uppercase tracking-[1.8px]`, {color: colors.primary}]}> 
                  {product.category}
                </Text>
                <Text style={[tw`text-2xl font-black mt-2`, {color: colors.textPrimary}]}> 
                  {product.name}
                </Text>
              </View>
              <View style={[
                tw`px-3 py-2 rounded-full`,
                {backgroundColor: colors.backgroundSecondary},
              ]}>
                <Text style={[tw`text-sm font-semibold`, {color: colors.textPrimary}]}>⭐ {product.rating}</Text>
              </View>
            </View>

            <Text style={[tw`text-base leading-7 mt-4`, {color: colors.textSecondary}]}> 
              {product.description}
            </Text>

            <View style={tw`flex-row items-center justify-between mt-6`}>
              <View>
                <Text style={[tw`text-sm`, {color: colors.textSecondary}]}>Price</Text>
                <Text style={[tw`text-3xl font-black mt-1`, {color: colors.primary}]}>${product.price}</Text>
              </View>
              <View style={[tw`px-3 py-2 rounded-full`, {backgroundColor: colors.backgroundSecondary}]}> 
                <Text style={[tw`text-sm font-semibold`, {color: colors.textPrimary}]}>In stock: {product.stock}</Text>
              </View>
            </View>

            <View style={tw`mt-6 flex-row items-center`}>
              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => addItem(product)}
                style={[
                  tw`flex-1 rounded-full py-4 items-center`,
                  {backgroundColor: colors.primary},
                ]}>
                <Text style={[tw`text-base font-black`, {color: colors.white}]}>Add to cart</Text>
              </TouchableOpacity>

              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => toggleFavorite(product)}
                style={[
                  tw`ml-3 h-12 w-12 rounded-full items-center justify-center`,
                  {
                    backgroundColor: isFavorite(product.id) ? colors.primary : colors.backgroundSecondary,
                  },
                ]}>
                <Text>{isFavorite(product.id) ? '❤️' : '🤍'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
