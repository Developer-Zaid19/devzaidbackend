import React, {useEffect, useState} from 'react';
import {
  Alert,
  Linking,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {ABOUT_US_URL} from '../config/env';
import {APP_VERSION} from '../config/appVersion';
import {useAppSettings} from '../context/AppSettingsContext';

const SettingsScreen = () => {
  const {theme, isDarkMode, toggleTheme, displayName, setDisplayName} =
    useAppSettings();
  const [nameInput, setNameInput] = useState(displayName);
  const styles = getStyles(theme);

  useEffect(() => {
    setNameInput(displayName);
  }, [displayName]);

  const handleSaveName = async () => {
    await setDisplayName(nameInput);
  };

  const handleOpenAbout = async () => {
    try {
      await Linking.openURL(ABOUT_US_URL);
    } catch (error) {
      console.log('About Us open error:', error);
      Alert.alert(
        'Unable to open',
        'Browser launch nahi ho saka. Please check that a browser app is installed.',
      );
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Settings</Text>
      <Text style={styles.label2}>Setting & Appearence</Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Appearance</Text>
        <View style={styles.toggleRow}>
          <View style={styles.copyBlock}>
            <Text style={styles.label}>Theme Dark/Light</Text>
          </View>
          <Switch
            value={!isDarkMode}
            onValueChange={toggleTheme}
            thumbColor={theme.colors.primary}
            trackColor={{
              false: theme.colors.border,
              true: theme.colors.secondaryLight,
            }}
          />
        </View>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Greeting Name</Text>
        <TextInput
          value={nameInput}
          onChangeText={setNameInput}
          placeholder="Enter your name"
          placeholderTextColor={theme.colors.textSecondary}
          style={styles.input}
        />
        <TouchableOpacity
          activeOpacity={0.88}
          style={styles.primaryButton}
          onPress={handleSaveName}>
          <Text style={styles.primaryButtonText}>Save Name</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>About Us</Text>
        {/* <Text style={styles.helper}>
          Opens your portfolio page in the browser.
        </Text> */}
        <TouchableOpacity
          activeOpacity={0.88}
          style={styles.secondaryButton}
          onPress={handleOpenAbout}>
          <Text style={styles.secondaryButtonText}>Open About Us</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.versionText}>Version {APP_VERSION}</Text>
    </ScrollView>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      padding: 16,
      paddingBottom: 28,
      backgroundColor: theme.colors.background,
      flexGrow: 1,
    },
    heading: {
      fontSize: 28,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
    },
    subheading: {
      marginTop: 4,
      marginBottom: 18,
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
      fontSize: 14,
    },
    card: {
      backgroundColor: theme.colors.surface,
      borderRadius: theme.colors.radius,
      borderWidth: 1,
      borderColor: theme.colors.border,
      padding: 16,
      marginBottom: 14,
    },
    cardTitle: {
      fontSize: 18,
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
      marginBottom: 10,
    },
    toggleRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    copyBlock: {
      flex: 1,
      paddingRight: 12,
    },
    label: {
      color: theme.colors.textPrimary,
      fontFamily: theme.typography.heading,
      fontSize: 15,
      marginBottom: 4,
    },
    label2: {
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.heading,
      fontSize: 15,
      marginBottom: 4,
    },
    helper: {
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
      fontSize: 14,
      lineHeight: 21,
    },
    input: {
      marginTop: 14,
      borderWidth: 1,
      borderColor: theme.colors.border,
      backgroundColor: theme.colors.backgroundSecondary,
      borderRadius: 14,
      color: theme.colors.textPrimary,
      paddingHorizontal: 14,
      paddingVertical: 12,
      fontFamily: theme.typography.body,
      fontSize: 15,
    },
    primaryButton: {
      marginTop: 14,
      backgroundColor: theme.colors.primary,
      borderRadius: 14,
      alignItems: 'center',
      paddingVertical: 13,
    },
    primaryButtonText: {
      color: theme.colors.background,
      fontFamily: theme.typography.heading,
      fontSize: 14,
    },
    secondaryButton: {
      marginTop: 14,
      backgroundColor: theme.colors.secondary,
      borderRadius: 14,
      alignItems: 'center',
      paddingVertical: 13,
    },
    secondaryButtonText: {
      color: theme.colors.white,
      fontFamily: theme.typography.heading,
      fontSize: 14,
    },
    versionText: {
      color: theme.colors.textSecondary,
      fontFamily: theme.typography.body,
      fontSize: 12,
      textAlign: 'center',
      marginTop: 'auto',
      paddingTop: 18,
    },
  });

export default SettingsScreen;
