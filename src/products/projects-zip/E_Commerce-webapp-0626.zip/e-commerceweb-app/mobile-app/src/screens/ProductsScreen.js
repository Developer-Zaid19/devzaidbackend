import React, {useMemo} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
} from 'react-native';
import tw from 'twrnc';
import {useNavigation} from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {getTheme} from '../theme';
import products from '../data/Products-Json/products';
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';

export default function ProductsScreen({colorScheme = 'dark'}) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const {colors} = theme;
  const navigation = useNavigation();
  const { toggleFavorite, isFavorite } = useFavorites();

  const groupedProducts = useMemo(() => {
    const grouped = products.reduce((acc, product) => {
      const key = product.category || 'General';
      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(product);
      return acc;
    }, {});

    return Object.entries(grouped).map(([category, items]) => ({
      category,
      items,
    }));
  }, []);

  return (
    <View
      style={[
        tw`flex-1`,
        {
          backgroundColor: colors.background,
        },
      ]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={tw`pb-8`}>
        <View
          style={[
            tw`px-4 pt-5 pb-4 flex-row items-center justify-between`,
            {
              backgroundColor: colors.backgroundSecondary,
            },
          ]}>
          <View style={tw`flex-1`}>
            <Text
              style={[
                tw`text-xs font-semibold uppercase tracking-[1.8px]`,
                {color: colors.primary},
              ]}>
              Shop by category
            </Text>
            <Text
              style={[
                tw`text-3xl font-black mt-1`,
                {color: colors.textPrimary},
              ]}>
              Products
            </Text>
          </View>

          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => navigation.navigate('Search')}
            style={[
              tw`w-12 h-12 rounded-2xl items-center justify-center`,
              {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border},
            ]}>
            <MaterialCommunityIcons name="magnify" size={22} color={colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={tw`px-4 mt-4`}>
          {groupedProducts.map(section => (
            <View key={section.category} style={tw`mb-6`}>
              <View style={tw`flex-row items-center justify-between mb-3`}>
                <Text
                  style={[
                    tw`text-lg font-bold`,
                    {color: colors.textPrimary},
                  ]}>
                  {section.category}
                </Text>
                <Text style={[tw`text-sm`, {color: colors.textSecondary}]}> 
                  {section.items.length} items
                </Text>
              </View>

              <View style={tw`gap-3`}>
                {section.items.map(item => (
                  <TouchableOpacity
                    key={item.id}
                    activeOpacity={0.9}
                    onPress={() => navigation.navigate('ProductDetail', {product: item})}
                    style={[
                      tw`rounded-3xl overflow-hidden flex-row p-3 my-2`,
                      {
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                    ]}>
                    <Image
                      source={item.image}
                      style={[
                        tw`rounded-2xl`,
                        {
                          width: 92,
                          height: 92,
                          backgroundColor: colors.backgroundSecondary,
                        },
                      ]}
                      resizeMode="cover"
                    />

                    <View style={tw`flex-1 ml-3 justify-between`}>
                      <View>
                        <View style={tw`flex-row items-start justify-between`}>
                          <Text
                            style={[
                              tw`text-base font-bold flex-1 pr-2`,
                              {color: colors.textPrimary},
                            ]}
                            numberOfLines={2}>
                            {item.name}
                          </Text>

                          <TouchableOpacity
                            activeOpacity={0.85}
                            style={[
                              tw`px-2.5 py-2 rounded-full`,
                              {
                                backgroundColor: isFavorite(item.id) ? colors.primary : colors.surface,
                              },
                            ]}
                            onPress={event => {
                              event.stopPropagation();
                              toggleFavorite(item);
                            }}>
                            <Text>{isFavorite(item.id) ? '❤️' : '🤍'}</Text>
                          </TouchableOpacity>
                        </View>

                        <Text
                          style={[
                            tw`text-sm mt-1`,
                            {color: colors.textSecondary},
                          ]}
                          numberOfLines={2}>
                          {item.description}
                        </Text>
                      </View>

                      <View style={tw`flex-row items-center justify-between mt-2`}>
                        <Text style={[tw`text-lg font-black`, {color: colors.primary}]}>${item.price}</Text>
                        <View
                          style={[
                            tw`px-3 py-1.5 rounded-full`,
                            {backgroundColor: colors.backgroundSecondary},
                          ]}>
                          <Text style={[tw`text-xs font-semibold`, {color: colors.textPrimary}]}>⭐ {item.rating}</Text>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
