import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  Image,
} from 'react-native';
import tw from 'twrnc';
import { useNavigation } from '@react-navigation/native';

import { getTheme } from '../theme';
import products from "../data/Products-Json/products.js";
import { useCart } from '../context/CartContext';
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';

export default function SearchScreen({ colorScheme = 'dark' }) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const { colors } = theme;
  const navigation = useNavigation();
  const { addItem } = useCart();
  const { toggleFavorite, isFavorite } = useFavorites();

  const [search, setSearch] = useState('');

  const filteredProducts = useMemo(() => {
    const query = search.trim().toLowerCase();

    if (!query) {
      return products;
    }

    return products.filter(product => {
      const name = product.name?.toLowerCase() || '';
      const category = product.category?.toLowerCase() || '';
      const description = product.description?.toLowerCase() || '';

      return (
        name.includes(query) ||
        category.includes(query) ||
        description.includes(query)
      );
    });
  }, [search, products]);

  const renderProduct = ({ item }) => {
    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={() => navigation.navigate('ProductDetail', {product: item})}
        style={[
          tw`mx-4 mb-4 rounded-3xl overflow-hidden`,
          {
            backgroundColor: colors.surface,
            borderWidth: 1,
            borderColor: colors.border,
          },
        ]}>
        {/* Product Image */}
        <Image
          source={item.image}
          resizeMode="cover"
          style={[
            tw`w-full`,
            {
              height: 220,
              backgroundColor: colors.backgroundSecondary,
            },
          ]}
        />

        <TouchableOpacity
          activeOpacity={0.85}
          style={[
            tw`absolute top-4 right-4 px-3 py-2 rounded-full`,
            {
              backgroundColor: isFavorite(item.id) ? colors.primary : colors.surface,
            },
          ]}
          onPress={event => {
            event.stopPropagation();
            toggleFavorite(item);
          }}>
          <Text>{isFavorite(item.id) ? '❤️' : '🤍'}</Text>
        </TouchableOpacity>

        {/* Badge */}
        {item.badge ? (
          <View
            style={[
              tw`absolute top-4 left-4 px-3 py-1 rounded-full`,
              {
                backgroundColor: colors.primary,
              },
            ]}>
            <Text
              style={[
                tw`text-xs font-bold`,
                {
                  color: '#000',
                },
              ]}>
              {item.badge}
            </Text>
          </View>
        ) : null}

        {/* Content */}
        <View style={tw`p-4`}>
          {/* Category */}
          <Text
            style={[
              tw`text-xs uppercase`,
              {
                color: colors.textSecondary,
              },
            ]}>
            {item.category}
          </Text>

          {/* Name */}
          <Text
            numberOfLines={2}
            style={[
              tw`text-lg font-bold mt-1`,
              {
                color: colors.textPrimary,
              },
            ]}>
            {item.name}
          </Text>

          {/* Description */}
          <Text
            numberOfLines={2}
            style={[
              tw`mt-2`,
              {
                color: colors.textSecondary,
              },
            ]}>
            {item.description}
          </Text>

          {/* Bottom Row */}
          <View style={tw`flex-row justify-between items-center mt-4`}>
            <View>
              <Text
                style={[
                  tw`text-xl font-extrabold`,
                  {
                    color: colors.primary,
                  },
                ]}>
                ${item.price}
              </Text>

              <Text
                style={[
                  tw`text-xs`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                Stock: {item.stock}
              </Text>
            </View>

            <View style={tw`flex-row items-center`}>
              <View
                style={[
                  tw`px-3 py-2 rounded-full`,
                  {
                    backgroundColor: colors.backgroundSecondary,
                  },
                ]}>
                <Text
                  style={[
                    tw`font-semibold`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}>
                  ⭐ {item.rating}
                </Text>
              </View>

              <TouchableOpacity
                activeOpacity={0.85}
                onPress={event => {
                  event.stopPropagation();
                  addItem(item);
                }}
                style={[
                  tw`ml-3 px-4 py-2 rounded-full`,
                  {
                    backgroundColor: colors.primary,
                  },
                ]}>
                <Text
                  style={[
                    tw`font-semibold`,
                    {
                      color: colors.white,
                    },
                  ]}>
                  Add
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View
      style={[
        tw`flex-1`,
        {
          backgroundColor: colors.background,
        },
      ]}>
      <FlatList
        data={filteredProducts}
        keyExtractor={item => item.id}
        renderItem={renderProduct}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          paddingBottom: 40,
        }}
        ListHeaderComponent={
          <>
            {/* Header */}
            <View style={tw`px-4 pt-4 pb-2`}>
              <Text
                style={[
                  tw`text-3xl font-bold`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                Search Products
              </Text>

              <Text
                style={[
                  tw`mt-1`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                Find products by name, category or description
              </Text>
            </View>

            {/* Search Box */}
            <View style={tw`px-4 mt-3`}>
              <View
                style={[
                  tw`rounded-2xl px-4`,
                  {
                    backgroundColor: colors.backgroundSecondary,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                ]}>
                <TextInput
                  value={search}
                  onChangeText={setSearch}
                  placeholder="Search products..."
                  placeholderTextColor={colors.textSecondary}
                  style={[
                    tw`h-14`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}
                />
              </View>
            </View>

            {/* Result Count */}
            <View style={tw`px-4 mt-4 mb-4`}>
              <Text
                style={[
                  tw`font-semibold`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {filteredProducts.length} Products Found
              </Text>
            </View>
          </>
        }
        ListEmptyComponent={
          <View style={tw`items-center justify-center mt-24 px-10`}>
            <Text
              style={[
                tw`text-5xl`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              🔍
            </Text>

            <Text
              style={[
                tw`text-xl font-bold mt-4`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              No Products Found
            </Text>

            <Text
              style={[
                tw`text-center mt-2`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              Try searching with a different keyword.
            </Text>
          </View>
        }
      />
    </View>
  );
}