import React from 'react';
import {View, Text, ScrollView, TouchableOpacity, Image, StatusBar} from 'react-native';
import tw from 'twrnc';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAppSettings} from '../context/AppSettingsContext';
import {useFavorites} from '../context/FavoritesContext';

export default function FavoritesScreen({navigation}) {
  const {theme} = useAppSettings();
  const {colors} = theme;
  const {favoriteItems, removeFavorite, clearFavorites} = useFavorites();

  return (
    <View style={[tw`flex-1`, {backgroundColor: colors.background}]}> 
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={tw`px-4 py-5 pb-8`}>
        <View style={tw`flex-row items-center justify-between mb-4`}>
          <View style={tw`flex-1`}>
            <Text style={[tw`text-xs font-semibold uppercase tracking-[1.8px]`, {color: colors.primary}]}>Saved for later</Text>
            <Text style={[tw`text-3xl font-black mt-1`, {color: colors.textPrimary}]}>Favorites</Text>
          </View>

          {favoriteItems.length > 0 ? (
            <TouchableOpacity onPress={clearFavorites} style={[tw`px-3 py-2 rounded-full`, {backgroundColor: colors.backgroundSecondary}]}> 
              <Text style={[tw`text-sm font-semibold`, {color: colors.textPrimary}]}>Clear</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        {favoriteItems.length === 0 ? (
          <View style={[tw`rounded-[24px] p-6 items-center`, {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border}]}> 
            <View style={[tw`w-16 h-16 rounded-full items-center justify-center mb-4`, {backgroundColor: colors.backgroundSecondary}]}> 
              <MaterialCommunityIcons name="heart-outline" size={28} color={colors.primary} />
            </View>
            <Text style={[tw`text-xl font-black`, {color: colors.textPrimary}]}>No favorites yet</Text>
            <Text style={[tw`text-center mt-2`, {color: colors.textSecondary}]}>Tap the heart on any product to keep it here.</Text>
          </View>
        ) : (
          favoriteItems.map(item => (
            <TouchableOpacity
              key={item.id}
              activeOpacity={0.9}
              onPress={() => navigation.navigate('ProductDetail', {product: item.product})}
              style={[
                tw`rounded-[24px] p-3 mb-3 flex-row`,
                {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border},
              ]}>
              <Image source={item.product.image} style={[tw`rounded-[18px]`, {width: 92, height: 92, backgroundColor: colors.backgroundSecondary}]} resizeMode="cover" />
              <View style={tw`flex-1 ml-3 justify-between`}>
                <View>
                  <Text style={[tw`text-base font-bold`, {color: colors.textPrimary}]} numberOfLines={2}>{item.product.name}</Text>
                  <Text style={[tw`text-sm mt-1`, {color: colors.textSecondary}]} numberOfLines={2}>{item.product.description}</Text>
                </View>
                <View style={tw`flex-row justify-between items-center mt-2`}>
                  <Text style={[tw`text-lg font-black`, {color: colors.primary}]}>${item.product.price}</Text>
                  <TouchableOpacity onPress={() => removeFavorite(item.id)} style={[tw`p-2 rounded-full`, {backgroundColor: colors.backgroundSecondary}]}> 
                    <MaterialCommunityIcons name="trash-can-outline" size={18} color={colors.textSecondary} />
                  </TouchableOpacity>
                </View>
              </View>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}
