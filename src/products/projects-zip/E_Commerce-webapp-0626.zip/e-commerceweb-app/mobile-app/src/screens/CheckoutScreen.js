import React, {useMemo, useState} from 'react';
import {View, Text, TextInput, TouchableOpacity, ScrollView, StatusBar,} from 'react-native';
import tw from 'twrnc';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useAppSettings} from '../context/AppSettingsContext';
import {useCart} from '../context/CartContext';

export default function CheckoutScreen({navigation}) {
  const {theme} = useAppSettings();
  const {colors} = theme;
  const {clearCart, subtotal, shipping, total} = useCart();

  const [form, setForm] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    phone: '',
    cardName: '',
    cardNumber: '',
  });
  const [deliveryMethod, setDeliveryMethod] = useState('Express');
  const [paymentMethod, setPaymentMethod] = useState('Card');

  const handleChange = (field, value) => {
    setForm(prev => ({...prev, [field]: value}));
  };

  const isFormValid = useMemo(
    () => Object.entries(form).filter(([key]) => ['cardName', 'cardNumber'].includes(key) ? paymentMethod === 'Card' : true).every(([, value]) => String(value).trim().length > 0),
    [form, paymentMethod],
  );

  const handleSubmit = () => {
    if (!isFormValid) {
      return;
    }

    clearCart();
    navigation.navigate('ThankYou');
  };

  return (
    <View style={[tw`flex-1`, {backgroundColor: colors.background}]}> 
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <ScrollView contentContainerStyle={tw`px-4 py-5 pb-8`} showsVerticalScrollIndicator={false}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => navigation.goBack()}
          style={[
            tw`w-12 h-12 rounded-2xl items-center justify-center mb-4`,
            {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border},
          ]}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={colors.textPrimary} />
        </TouchableOpacity>

        <Text style={[tw`text-3xl font-black`, {color: colors.textPrimary}]}>Checkout</Text>
        <Text style={[tw`mt-2 text-base`, {color: colors.textSecondary}]}>Please fill your details to confirm the order.</Text>

        <View style={[tw`mt-6 rounded-[24px] p-4`, {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border}]}> 
          <Text style={[tw`text-lg font-black mb-4`, {color: colors.textPrimary}]}>Shipping details</Text>

          <InputField label="Full name" value={form.name} onChangeText={value => handleChange('name', value)} placeholder="Name" colors={colors} />
          <InputField label="Email" value={form.email} onChangeText={value => handleChange('email', value)} placeholder="Support@example.com" colors={colors} keyboardType="email-address" />
          <InputField label="Phone" value={form.phone} onChangeText={value => handleChange('phone', value)} placeholder="0312 1234567" colors={colors} keyboardType="phone-pad" />
          <InputField label="Address" value={form.address} onChangeText={value => handleChange('address', value)} placeholder="House 12, Street 2" colors={colors} multiline />
          <InputField label="City" value={form.city} onChangeText={value => handleChange('city', value)} placeholder="Lucknow" colors={colors} />
        </View>

        <View style={[tw`mt-4 rounded-[24px] p-4`, {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border}]}> 
          <Text style={[tw`text-lg font-black mb-3`, {color: colors.textPrimary}]}>Delivery & payment</Text>

          <Text style={[tw`text-sm font-semibold mb-2`, {color: colors.textSecondary}]}>Delivery method</Text>
          <View style={tw`flex-row mb-4`}>
            {['Express', 'Standard'].map(method => (
              <TouchableOpacity
                key={method}
                activeOpacity={0.85}
                onPress={() => setDeliveryMethod(method)}
                style={[
                  tw`mr-2 px-3 py-2 rounded-full`,
                  {backgroundColor: deliveryMethod === method ? colors.primary : colors.backgroundSecondary},
                ]}>
                <Text style={[tw`text-sm font-semibold`, {color: deliveryMethod === method ? colors.white : colors.textPrimary}]}>{method}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[tw`text-sm font-semibold mb-2`, {color: colors.textSecondary}]}>Payment method</Text>
          <View style={tw`flex-row mb-4`}>
            {['Card', 'Cash on delivery'].map(method => (
              <TouchableOpacity
                key={method}
                activeOpacity={0.85}
                onPress={() => setPaymentMethod(method)}
                style={[
                  tw`mr-2 px-3 py-2 rounded-full`,
                  {backgroundColor: paymentMethod === method ? colors.primary : colors.backgroundSecondary},
                ]}>
                <Text style={[tw`text-sm font-semibold`, {color: paymentMethod === method ? colors.white : colors.textPrimary}]}>{method}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {paymentMethod === 'Card' ? (
            <>
              <InputField label="Cardholder name" value={form.cardName} onChangeText={value => handleChange('cardName', value)} placeholder="Cardholder Name" colors={colors} />
              <InputField label="Card number" value={form.cardNumber} onChangeText={value => handleChange('cardNumber', value)} placeholder="4242 4242 4242 4242" colors={colors} keyboardType="number-pad" />
            </>
          ) : null}
        </View>

        <View style={[tw`mt-4 rounded-[24px] p-4`, {backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border}]}> 
          <Text style={[tw`text-lg font-black mb-3`, {color: colors.textPrimary}]}>Order summary</Text>
          <Row label="Subtotal" value={`$${subtotal.toFixed(2)}`} colors={colors} />
          <Row label="Delivery" value={deliveryMethod === 'Express' ? '$12.00' : '$5.00'} colors={colors} />
          <Row label="Shipping" value={`$${shipping.toFixed(2)}`} colors={colors} />
          <View style={tw`h-px my-3`} />
          <Row label="Total" value={`$${(subtotal + (deliveryMethod === 'Express' ? 12 : 5) + shipping).toFixed(2)}`} colors={colors} bold />
        </View>

        <TouchableOpacity
          activeOpacity={0.9}
          onPress={handleSubmit}
          style={[
            tw`mt-6 rounded-full py-4 items-center`,
            {backgroundColor: isFormValid ? colors.primary : colors.backgroundSecondary},
          ]}>
          <Text style={[tw`text-base font-black`, {color: isFormValid ? colors.white : colors.textSecondary}]}>Proceed</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function InputField({label, value, onChangeText, placeholder, colors, keyboardType = 'default', multiline = false}) {
  return (
    <View style={tw`mb-3`}>
      <Text style={[tw`text-sm font-semibold mb-2`, {color: colors.textSecondary}]}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textSecondary}
        keyboardType={keyboardType}
        multiline={multiline}
        selectionColor={colors.primary}
        underlineColorAndroid={colors.border}
        style={[
          tw`rounded-2xl px-4 py-3`,
          {
            backgroundColor: colors.backgroundSecondary,
            color: colors.textPrimary,
            borderWidth: 1,
            borderColor: colors.border,
            minHeight: multiline ? 90 : 48,
            textAlignVertical: multiline ? 'top' : 'center',
          },
        ]}
      />
    </View>
  );
}

function Row({label, value, colors, bold = false}) {
  return (
    <View style={tw`flex-row justify-between items-center mb-2`}>
      <Text style={[tw`${bold ? 'font-black' : 'font-semibold'}`, {color: colors.textSecondary}]}>{label}</Text>
      <Text style={[tw`${bold ? 'font-black' : 'font-semibold'}`, {color: colors.textPrimary}]}>{value}</Text>
    </View>
  );
}
