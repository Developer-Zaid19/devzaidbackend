import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
} from 'react-native';

const AppSplash = ({ theme, displayName }) => {
  const styles = getStyles(theme);
  const trimmedName = displayName?.trim();

  return (
    <View style={styles.container}>
      {/* Background Circles */}
      <View style={styles.circleLarge} />
      <View style={styles.circleSmall} />

      {/* Logo */}
      <View style={styles.logoContainer}>
        <Text style={styles.logoText}>A</Text>
      </View>

      {/* Brand */}
      <Text style={styles.brandName}>
        Aurevia
      </Text>

      <Text style={styles.tagline}>
        Premium Shopping Experience
      </Text>

      {trimmedName ? (
        <Text style={styles.welcome}>
          Welcome back, {trimmedName}
        </Text>
      ) : null}

      <Text style={styles.subtitle}>
        Discover curated products crafted
        for modern lifestyles.
      </Text>

      <ActivityIndicator
        size="small"
        color={theme.colors.primary}
        style={styles.loader}
      />
    </View>
  );
};

const getStyles = theme =>
  StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: theme.colors.background,
      paddingHorizontal: 24,
      overflow: 'hidden',
    },

    circleLarge: {
      position: 'absolute',
      width: 260,
      height: 260,
      borderRadius: 130,
      backgroundColor: theme.colors.primaryDim,
      top: -80,
      right: -60,
    },

    circleSmall: {
      position: 'absolute',
      width: 180,
      height: 180,
      borderRadius: 90,
      backgroundColor: theme.colors.primaryDim,
      bottom: -50,
      left: -50,
    },

    logoContainer: {
      width: 90,
      height: 90,
      borderRadius: 45,
      backgroundColor: theme.colors.primary,
      justifyContent: 'center',
      alignItems: 'center',

      shadowColor: theme.colors.shadow,
      shadowOffset: {
        width: 0,
        height: 10,
      },
      shadowOpacity: 0.25,
      shadowRadius: 16,
      elevation: 10,
    },

    logoText: {
      color: '#04172B',
      fontSize: 40,
      fontFamily: theme.typography.heading,
      fontWeight: '700',
    },

    brandName: {
      marginTop: 22,
      color: theme.colors.textPrimary,
      fontSize: 34,
      fontFamily: theme.typography.heading,
      letterSpacing: 1,
    },

    tagline: {
      marginTop: 6,
      color: theme.colors.primary,
      fontSize: 14,
      fontFamily: theme.typography.body,
      letterSpacing: 2,
      textTransform: 'uppercase',
    },

    welcome: {
      marginTop: 24,
      color: theme.colors.primaryLight,
      fontSize: 18,
      fontFamily: theme.typography.heading,
      textAlign: 'center',
    },

    subtitle: {
      marginTop: 12,
      color: theme.colors.textSecondary,
      fontSize: 15,
      lineHeight: 24,
      textAlign: 'center',
      maxWidth: 290,
      fontFamily: theme.typography.body,
    },

    loader: {
      marginTop: 30,
    },
  });

export default AppSplash;