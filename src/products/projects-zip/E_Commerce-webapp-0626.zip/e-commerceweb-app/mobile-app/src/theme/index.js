import {
  DefaultTheme as NavigationDefaultTheme,
  DarkTheme as NavigationDarkTheme,
} from '@react-navigation/native';
import {Platform} from 'react-native';

const shared = {
  primary: '#059669',       // website --brand
  primaryLight: '#34D399',  // dark mode brand
  primaryDim: '#D1FAE5',    // website --brand-faint

  secondary: '#FBBF24',     // website --accent
  secondaryLight: '#F59E0B',

  radius: 16,
};

const lightColors = {
  ...shared,

  background: '#FAFAF7',          // --background
  backgroundSecondary: '#F4F4F0', // --background-subtle
  backgroundTertiary: '#EFEFE9',

  surface: '#FFFFFF',             // --background-card
  surfaceElevated: '#FFFFFF',

  textPrimary: '#111110',         // --foreground
  textSecondary: '#6B6B63',       // --foreground-muted

  border: '#E4E4DE',              // --border

  shadow: '#111110',
  white: '#FFFFFF',
};

const darkColors = {
  ...shared,

  background: '#111110',          // --background
  backgroundSecondary: '#1C1C1A', // --background-card
  backgroundTertiary: '#232320',  // --background-subtle

  surface: '#1C1C1A',
  surfaceElevated: '#232320',

  textPrimary: '#F0F0EC',         // --foreground
  textSecondary: '#9E9E96',       // --foreground-muted

  border: '#2E2E2A',              // --border

  shadow: '#000000',
  white: '#FFFFFF',
};

const fontFamily = (name, fallback) =>
  Platform.select({
    android: name || fallback,
    ios: name || fallback,
    default: fallback,
  });

const typography = {
  heading: fontFamily('DM Sans', 'sans-serif-medium'),
  body: fontFamily('Inter', 'sans-serif'),
  arabic: fontFamily('Amiri', 'serif'),
};

export const getTheme = (mode = 'dark') => {
  const colors = mode === 'light' ? lightColors : darkColors;

  return {
    mode,
    isDark: mode !== 'light',
    colors,
    typography,
  };
};

export const createNavigationTheme = (mode = 'dark') => {
  const baseTheme =
    mode === 'light' ? NavigationDefaultTheme : NavigationDarkTheme;
  const theme = getTheme(mode);

  return {
    ...baseTheme,
    colors: {
      ...baseTheme.colors,
      primary: theme.colors.primary,
      background: theme.colors.background,
      card: theme.colors.backgroundSecondary,
      text: theme.colors.textPrimary,
      border: theme.colors.border,
      notification: theme.colors.secondary,
    },
  };
};
