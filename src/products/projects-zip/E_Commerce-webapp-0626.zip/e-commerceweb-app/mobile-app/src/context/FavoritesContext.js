import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const FAVORITES_STORAGE_KEY = '@aurevia/favorites';

const defaultFavoritesValue = {
  favoriteItems: [],
  favoriteCount: 0,
  toggleFavorite: () => {},
  removeFavorite: () => {},
  clearFavorites: () => {},
  isFavorite: () => false,
};

const FavoritesContext = createContext(defaultFavoritesValue);

export const FavoritesProvider = ({children}) => {
  const [favoriteItems, setFavoriteItems] = useState([]);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let mounted = true;

    const loadFavorites = async () => {
      try {
        const raw = await AsyncStorage.getItem(FAVORITES_STORAGE_KEY);

        if (mounted && raw) {
          const parsed = JSON.parse(raw);

          if (Array.isArray(parsed)) {
            setFavoriteItems(parsed);
          }
        }
      } catch (error) {
        console.log('Favorites read error:', error);
      } finally {
        if (mounted) {
          setIsReady(true);
        }
      }
    };

    loadFavorites();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isReady) {
      return;
    }

    AsyncStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favoriteItems)).catch(error => {
      console.log('Favorites write error:', error);
    });
  }, [favoriteItems, isReady]);

  const toggleFavorite = useCallback(product => {
    setFavoriteItems(prevItems => {
      const existing = prevItems.find(item => item.id === product.id);

      if (existing) {
        return prevItems.filter(item => item.id !== product.id);
      }

      return [...prevItems, {id: product.id, product}];
    });
  }, []);

  const removeFavorite = useCallback(id => {
    setFavoriteItems(prevItems => prevItems.filter(item => item.id !== id));
  }, []);

  const clearFavorites = useCallback(() => {
    setFavoriteItems([]);
  }, []);

  const isFavorite = useCallback(
    id => favoriteItems.some(item => item.id === id),
    [favoriteItems],
  );

  const favoriteCount = favoriteItems.length;

  const value = useMemo(
    () => ({
      favoriteItems,
      favoriteCount,
      toggleFavorite,
      removeFavorite,
      clearFavorites,
      isFavorite,
    }),
    [clearFavorites, favoriteCount, favoriteItems, isFavorite, removeFavorite, toggleFavorite],
  );

  return <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>;
};

export const useFavorites = () => useContext(FavoritesContext);
