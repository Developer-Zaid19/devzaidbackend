import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CART_STORAGE_KEY = '@aurevia/cart';

const CartContext = createContext(null);

export const CartProvider = ({children}) => {
  const [items, setItems] = useState([]);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let mounted = true;

    const loadCart = async () => {
      try {
        const raw = await AsyncStorage.getItem(CART_STORAGE_KEY);

        if (mounted && raw) {
          const parsed = JSON.parse(raw);

          if (Array.isArray(parsed)) {
            setItems(parsed);
          }
        }
      } catch (error) {
        console.log('Cart read error:', error);
      } finally {
        if (mounted) {
          setIsReady(true);
        }
      }
    };

    loadCart();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isReady) {
      return;
    }

    AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items)).catch(error => {
      console.log('Cart write error:', error);
    });
  }, [isReady, items]);

  const addItem = useCallback(product => {
    setItems(prevItems => {
      const existingIndex = prevItems.findIndex(item => item.id === product.id);

      if (existingIndex >= 0) {
        const nextItems = [...prevItems];
        const existingItem = nextItems[existingIndex];
        nextItems[existingIndex] = {
          ...existingItem,
          quantity: existingItem.quantity + 1,
        };
        return nextItems;
      }

      return [...prevItems, {id: product.id, product, quantity: 1}];
    });
  }, []);

  const incrementItem = useCallback(id => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? {...item, quantity: item.quantity + 1} : item,
      ),
    );
  }, []);

  const decrementItem = useCallback(id => {
    setItems(prevItems =>
      prevItems.flatMap(item => {
        if (item.id !== id) {
          return [item];
        }

        if (item.quantity > 1) {
          return [{...item, quantity: item.quantity - 1}];
        }

        return [];
      }),
    );
  }, []);

  const removeItem = useCallback(id => {
    setItems(prevItems => prevItems.filter(item => item.id !== id));
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  const cartCount = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity, 0),
    [items],
  );

  const totalItems = cartCount;

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    [items],
  );

  const shipping = subtotal > 0 ? (subtotal >= 150 ? 0 : 12) : 0;
  const total = subtotal + shipping;

  const value = useMemo(
    () => ({
      items,
      addItem,
      incrementItem,
      decrementItem,
      removeItem,
      clearCart,
      cartCount,
      totalItems,
      subtotal,
      shipping,
      total,
    }),
    [addItem, cartCount, clearCart, decrementItem, incrementItem, items, removeItem, subtotal, shipping, total, totalItems],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export const useCart = () => {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }

  return context;
};
