import React from 'react';
import {StatusBar} from 'react-native';
import AppNavigator from './src/navigation/AppNavigator';
import AppSplash from './src/components/AppSplash';
import {
  AppSettingsProvider,
  useAppSettings,
} from './src/context/AppSettingsContext';
import {CartProvider} from './src/context/CartContext';
import {FavoritesProvider} from './src/context/FavoritesContext';

const AppContent = () => {
  const {isReady, showSplash, theme, navigationTheme, displayName, isDarkMode} =
    useAppSettings();

  if (!isReady || showSplash) {
    return <AppSplash theme={theme} displayName={displayName} />;
  }

  return (
    <>
      <StatusBar
        barStyle={isDarkMode ? 'light-content' : 'dark-content'}
        backgroundColor={theme.colors.background}
      />
      <AppNavigator navigationTheme={navigationTheme} />
    </>
  );
};

export default function App() {
  return (
    <AppSettingsProvider>
      <CartProvider>
        <FavoritesProvider>
          <AppContent />
        </FavoritesProvider>
      </CartProvider>
    </AppSettingsProvider>
  );
}
