import { CartProvider } from "@/components/CartProvider";
import { ThemeProvider } from "@/components/ThemeProvider";
import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import AuthProvider from "@/components/SessionProvider";
import "./globals.css";

export const metadata = {
  title: "Aurevia Market | Curated ecommerce store",
  description:
    "A polished responsive ecommerce website built with Next.js and Tailwind CSS.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body style={{ minHeight: "100vh", backgroundColor: "var(--background)", color: "var(--foreground)" }}>
        <AuthProvider>

        <ThemeProvider>
          <CartProvider>
            <div className="flex min-h-screen flex-col">
              <Navbar />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
          </CartProvider>
        </ThemeProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
