import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  StyleSheet,
  TextInput,
  RefreshControl,
} from 'react-native';
import tw from 'twrnc';
import { useNavigation } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { getTheme } from '../theme';
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';
import {
  getAllProducts
} from "../lib/products";

export default function ProductsScreen({ colorScheme = 'dark' }) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const { colors } = theme;
  const navigation = useNavigation();
  const { toggleFavorite, isFavorite } = useFavorites();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const [query, setQuery] = useState("");
  const [subject, setSubject] = useState("All");
  const [className, setClassName] = useState("All");
  const [type, setType] = useState("All");
  const [refreshing, setRefreshing] = useState(false);


  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    setSubject("All");
    setClassName("All");
  }, [type]);

  const loadProducts = async (forceRefresh = false) => {
    try {
      setLoading(true);

      const data = await getAllProducts(forceRefresh);

      setProducts(data);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    try {
      setRefreshing(true);

      await loadProducts(true);
    } finally {
      setRefreshing(false);
    }
  };
  const productsForFilters = useMemo(() => {
    if (type === "All") return products;

    return products.filter(item => item.kiyahai === type);
  }, [products, type]);

  const subjects = useMemo(
    () => [
      "All",
      ...new Set(
        productsForFilters
          .map(item => item.subject || item.category)
          .filter(Boolean)
      ),
    ],
    [productsForFilters]
  );

  const classes = useMemo(
    () => [
      "All",
      ...new Set(
        productsForFilters
          .map(item => item.className || item.class)
          .filter(Boolean)
      ),
    ],
    [productsForFilters]
  );

  const filteredProducts = useMemo(() => {
    const search = query.trim().toLowerCase();

    return products.filter((product) => {
      const matchesSearch =
        !search ||
        [
          product.title,
          product.name,
          product.subject,
          product.description,
        ]
          .filter(Boolean)
          .some((value) => value.toLowerCase().includes(search));

      const matchesSubject =
        subject === "All" ||
        product.subject === subject ||
        product.category === subject;

      const matchesClass =
        className === "All" ||
        product.className === className ||
        product.class === className;

      const matchesType =
        type === "All" ||
        product.kiyahai === type;

      return (
        matchesSearch &&
        matchesSubject &&
        matchesClass &&
        matchesType
      );
    });
  }, [products, query, subject, className, type]);

  const groupedProducts = useMemo(() => {
    const grouped = filteredProducts.reduce((acc, product) => {
      const key = product.category || "General";

      if (!acc[key]) {
        acc[key] = [];
      }

      acc[key].push(product);

      return acc;
    }, {});

    return Object.entries(grouped).map(([category, items]) => ({
      category,
      items,
    }));
  }, [filteredProducts]);



  return (
    <View
      style={[
        tw`flex-1`,
        {
          backgroundColor: colors.background,
        },
      ]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={tw`pb-8`}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[colors.primary]}
            tintColor={colors.primary}
          />
        }>
          
        <View
          style={[
            tw`px-4 pt-5 pb-4 flex-row items-center justify-between`,
            {
              backgroundColor: colors.backgroundSecondary,
            },
          ]}>
          <View style={tw`flex-1`}>
            <Text
              style={[
                tw`text-xs font-semibold uppercase tracking-[1.8px]`,
                { color: colors.primary },
              ]}>
              Shop by category
            </Text>
            <Text
              style={[
                tw`text-3xl font-black mt-1`,
                { color: colors.textPrimary },
              ]}>
              Products
            </Text>
          </View>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={tw`px-4 mt-4`}
        >
          {["All", "notes", "projects", "apk"].map(item => (
            <TouchableOpacity
              key={item}
              onPress={() => setType(item)}
              style={[
                tw`mr-2 px-4 py-2 rounded-full`,
                {
                  backgroundColor:
                    type === item
                      ? colors.primary
                      : colors.surface,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    type === item
                      ? "#fff"
                      : colors.textPrimary,
                  fontWeight: "700",
                }}
              >
                {item === "All"
                  ? "All"
                  : item === "notes"
                    ? "Notes"
                    : item === "projects"
                      ? "Projects"
                      : "APKs"}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={tw`px-4 mt-4`}>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search notes, APKs, projects..."
            placeholderTextColor={colors.textSecondary}
            style={[
              tw`rounded-2xl px-4 h-13`,
              {
                backgroundColor: colors.surface,
                color: colors.textPrimary,
                borderWidth: 1,
                borderColor: colors.border,
              },
            ]}
          />
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={tw`px-4 mt-3`}
        >
          {subjects.map(item => (
            <TouchableOpacity
              key={item}
              onPress={() => setSubject(item)}
              style={[
                tw`mr-2 px-4 py-2 rounded-full`,
                {
                  backgroundColor:
                    subject === item
                      ? colors.primary
                      : colors.surface,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    subject === item
                      ? "#fff"
                      : colors.textPrimary,
                }}
              >
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={tw`px-4 mt-3`}
        >
          {classes.map(item => (
            <TouchableOpacity
              key={item}
              onPress={() => setClassName(item)}
              style={[
                tw`mr-2 px-4 py-2 rounded-full`,
                {
                  backgroundColor:
                    className === item
                      ? colors.primary
                      : colors.surface,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    className === item
                      ? "#fff"
                      : colors.textPrimary,
                }}
              >
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={tw`px-4 mt-4`}>
          {groupedProducts.map(section => (
            <View key={section.category} style={tw`mb-6`}>
              <View style={tw`flex-row items-center justify-between mb-3`}>
                <Text
                  style={[
                    tw`text-lg font-bold`,
                    { color: colors.textPrimary },
                  ]}>
                  {section.category}
                </Text>
                <Text style={[tw`text-sm`, { color: colors.textSecondary }]}>
                  {section.items.length} items
                </Text>
              </View>

              <View style={tw`gap-3`}>
                {section.items.map(item => (
                  <TouchableOpacity
                    key={item.id}
                    activeOpacity={0.9}
                    onPress={() => navigation.navigate('ProductDetail', { product: item })}
                    style={[
                      tw`rounded-3xl overflow-hidden flex-row p-3 my-2`,
                      {
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                    ]}>
                    <Image
                      source={{ uri: item.image }}
                      style={[
                        tw`rounded-2xl`,
                        {
                          width: 92,
                          height: 92,
                          backgroundColor: item.kiyahai == "notes" ? "white" : colors.backgroundSecondary,
                        },
                      ]}
                      resizeMode={item.kiyahai == "notes" ? "contain" : "cover"}
                    />

                    <View style={tw`flex-1 ml-3 justify-between`}>
                      <View>
                        <View style={tw`flex-row items-start justify-between`}>
                          <Text
                            style={[
                              tw`text-base font-bold flex-1 pr-2`,
                              { color: colors.textPrimary },
                            ]}
                            numberOfLines={2}>
                            {item.name}
                          </Text>

                          <TouchableOpacity
                            activeOpacity={0.85}
                            style={[
                              tw`px-2.5 py-2 rounded-full`,
                              {
                                backgroundColor: isFavorite(item.id) ? colors.primary : colors.surface,
                              },
                            ]}
                            onPress={event => {
                              event.stopPropagation();
                              toggleFavorite(item);
                            }}>
                            <Text>{isFavorite(item.id) ? '❤️' : '🤍'}</Text>
                          </TouchableOpacity>
                        </View>

                        <Text
                          style={[
                            tw`text-sm mt-1`,
                            { color: colors.textSecondary },
                          ]}
                          numberOfLines={2}>
                          {item.description}
                        </Text>
                      </View>

                      <View style={tw`flex-row items-center justify-between mt-2`}>
                        <Text style={[tw`text-lg font-black`, { color: colors.primary }]}>FREE</Text>
                        <View
                          style={[
                            tw`px-3 py-1.5 rounded-full`,
                            { backgroundColor: colors.backgroundSecondary },
                          ]}>
                          <Text style={[tw`text-xs font-semibold`, { color: colors.textPrimary }]}>{item.fileSize || item.pages}</Text>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
