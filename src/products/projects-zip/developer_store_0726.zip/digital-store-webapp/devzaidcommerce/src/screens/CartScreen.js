import React from 'react';
import { useEffect, useMemo, useState } from 'react';
import { getAllProducts } from '../lib/products';
import RNFS from "react-native-fs";
import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Alert,
  Modal,
  ActivityIndicator,
} from 'react-native';
import tw from 'twrnc';
import { useNavigation } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { getTheme } from '../theme';
import { useCart } from '../context/CartContext';
import { useAppSettings } from '../context/AppSettingsContext';

export default function CartScreen({ colorScheme = 'dark' }) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const { colors } = theme;
  const s = makeStyles(colors);
  const navigation = useNavigation();
  const {
    items,
    removeItem,
    clearCart,
    cartCount,
  } = useCart();

  const [products, setProducts] = useState([]);
  const [downloading, setDownloading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [downloadCompleted, setDownloadCompleted] = useState(false);
  const [status, setStatus] = useState("");

  const checkout = async () => {
    try {
      setDownloadCompleted(false);
      setDownloading(true);
      setProgress(0);
      setStatus("Preparing download...");

      const payload = items.map(item => ({
        id: item.itemId,
        type: item.kiyahai,
      }));

      const response = await fetch(
        "https://devzaidbackend.onrender.com/api/products/mobiledownloadcart",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        }
      );

      const data = await response.json();

      console.log("Response:", data);
      setProgress(20)

      if (!response.ok) {
        throw new Error(data.message || "Download failed");
      }

      console.log("Download URL:", data.url);

      const downloadUrl = `https://devzaidbackend.onrender.com${data.url}`;
      setProgress(40)

      const filePath = `${RNFS.DownloadDirectoryPath}/DeveloperZaid-${Date.now()}.zip`;

      const task = RNFS.downloadFile({
        fromUrl: downloadUrl,
        toFile: filePath,
      });

      const result = await task.promise;
      setProgress(80)
      console.log(result);

      if (result.statusCode === 200) {
        setProgress(100);
        setDownloadCompleted(true);
      }

      const exists = await RNFS.exists(filePath);

      console.log("File Exists:", exists);

      console.log("Saved At:", filePath);

      setTimeout(() => {
        clearCart();
        setDownloading(false);
        setDownloadCompleted(false);
        setProgress(0);
      }, 2000);

    } catch (error) {
      console.log(error);

      Alert.alert(
        "Download Error",
        error.message || "Something went wrong."
      );

      setDownloading(false);
    }
  };

  useEffect(() => {
    const load = async () => {
      const data = await getAllProducts();
      setProducts(data);
    };

    load();
  }, []);

  const cartProducts = useMemo(() => {
    return items
      .map(cartItem => {
        const product = products.find(
          p =>
            p.id === cartItem.itemId &&
            p.kiyahai === cartItem.kiyahai,
        );

        return product
          ? {
            cartItem,
            product,
          }
          : null;
      })
      .filter(Boolean);
  }, [items, products]);

  const isEmpty = cartProducts.length === 0;

  return (
    <View style={[s.root, { backgroundColor: colors.background }]}>
      <StatusBar
        barStyle={theme.isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.backgroundSecondary}
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={s.scroll}>
        <View style={s.header}>
          <View>
            <Text style={[s.eyebrow, { color: colors.primary }]}>Your bag</Text>
            <Text style={[s.headline, { color: colors.textPrimary }]}>Cart</Text>
            <Text style={[s.subtitle, { color: colors.textSecondary }]}>
              {cartCount} item{cartCount === 1 ? '' : 's'} ready to checkout
            </Text>
          </View>
          {!isEmpty ? (
            <TouchableOpacity onPress={clearCart} style={s.clearButton}>
              <Text style={[s.clearButtonText, { color: colors.primary }]}>Clear</Text>
            </TouchableOpacity>
          ) : null}
        </View>

        {isEmpty ? (
          <View style={s.emptyState}>
            <View style={[s.emptyIcon, { backgroundColor: colors.backgroundSecondary }]}>
              <MaterialCommunityIcons name="cart-outline" size={36} color={colors.primary} />
            </View>
            <Text style={[s.emptyTitle, { color: colors.textPrimary }]}>Your cart feels light</Text>
            <Text style={[s.emptyBody, { color: colors.textSecondary }]}>
              Add a few favorites from home or search and they will appear here.
            </Text>
            <TouchableOpacity
              style={[s.primaryButton, { backgroundColor: colors.primary }]}
              onPress={() => navigation.navigate('Home')}>
              <Text style={[s.primaryButtonText, { color: colors.white }]}>Continue shopping</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <View style={s.itemsList}>
              {cartProducts.map(({ cartItem, product }) => (
                <View key={`${cartItem.kiyahai}-${cartItem.itemId}`} style={[s.cartCard, { backgroundColor: colors.surface, borderColor: colors.border }, tw`my-2`]}>
                  <Image source={{ uri: product.image }} style={[s.itemImage, {
                    backgroundColor: product.kiyahai == "notes" ? "white" : colors.backgroundSecondary,
                  }]}
                    resizeMode='contain' />
                  <View style={s.itemContent}>
                    <View style={s.itemTopRow}>
                      <View style={[{ flex: 1 }, tw`px-2`]}>
                        <Text style={[s.itemName, { color: colors.textPrimary }]} numberOfLines={2}>
                          {product.name}
                        </Text>
                        <Text style={[s.itemMeta, { color: colors.textSecondary }]}>
                          {product.category}
                        </Text>
                      </View>
                      <TouchableOpacity onPress={() =>
                        removeItem(
                          cartItem.itemId,
                          cartItem.kiyahai,
                        )
                      }>
                        <MaterialCommunityIcons name="trash-can-outline" size={20} color={colors.textSecondary} />
                      </TouchableOpacity>
                    </View>

                    <View style={s.itemBottomRow}>
                      <Text style={[s.itemPrice, { color: colors.primary }, tw`px-2`]}>FREE</Text>
                      <View
                        style={[
                          tw`px-3 py-1 rounded-full`,
                          { backgroundColor: colors.backgroundSecondary },
                        ]}>
                        <Text
                          style={[
                            tw`text-xs font-bold`,
                            { color: colors.primary },
                          ]}>
                          {product.kiyahai.toUpperCase()}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
              ))}
            </View>

            <View style={[s.summaryCard, { backgroundColor: colors.surfaceElevated, borderColor: colors.border }]}>
              <Text style={[s.summaryTitle, { color: colors.textPrimary }]}>Order summary</Text>
              <View style={s.summaryRow}>
                <Text style={[s.summaryLabel, { color: colors.textSecondary }]}>Subtotal</Text>
                <Text style={[s.summaryValue, { color: colors.textPrimary }]}>FREE</Text>
              </View>
              <View style={s.summaryRow}>
                <Text style={[s.summaryLabel, { color: colors.textSecondary }]}>Shipping</Text>
                <Text style={[s.summaryValue, { color: colors.textPrimary }]}>Internet</Text>
              </View>
              <View style={[s.summaryRow, s.totalRow]}>
                <Text style={[s.summaryLabel, { color: colors.textPrimary }]}>Total</Text>
                <Text style={[s.summaryValue, { color: colors.primary }]}>FREE</Text>
              </View>
              <TouchableOpacity
                style={[
                  s.primaryButton,
                  {
                    backgroundColor: downloadCompleted
                      ? "#16a34a"
                      : downloading
                        ? colors.border
                        : colors.primary,
                  },
                ]}
                onPress={checkout}
                disabled={downloading}
              >
                <Text
                  style={[
                    s.primaryButtonText,
                    {
                      color: colors.white,
                    },
                  ]}
                >
                  {downloadCompleted
                    ? "✓ Download Completed"
                    : downloading
                      ? `Downloading... ${progress}%`
                      : "Proceed to Checkout"}
                </Text>
              </TouchableOpacity>
            </View>
          </>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>
    </View>
  );
}

function makeStyles(colors) {
  return StyleSheet.create({
    root: { flex: 1 },
    scroll: { flexGrow: 1, paddingBottom: 32 },
    header: {
      paddingHorizontal: 20,
      paddingTop: 24,
      paddingBottom: 16,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
    },
    eyebrow: {
      fontSize: 12,
      fontWeight: '800',
      letterSpacing: 1.6,
      textTransform: 'uppercase',
      marginBottom: 6,
    },
    headline: {
      fontSize: 30,
      fontWeight: '900',
      letterSpacing: -0.6,
    },
    subtitle: {
      marginTop: 8,
      fontSize: 14,
    },
    clearButton: {
      paddingVertical: 8,
      paddingHorizontal: 10,
      borderRadius: 999,
      backgroundColor: colors.backgroundSecondary,
    },
    clearButtonText: {
      fontSize: 13,
      fontWeight: '700',
    },
    emptyState: {
      marginHorizontal: 20,
      marginTop: 24,
      padding: 24,
      borderRadius: 24,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: colors.border,
      backgroundColor: colors.surface,
    },
    emptyIcon: {
      width: 72,
      height: 72,
      borderRadius: 24,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 16,
    },
    emptyTitle: {
      fontSize: 20,
      fontWeight: '800',
      marginBottom: 8,
    },
    emptyBody: {
      textAlign: 'center',
      lineHeight: 22,
      marginBottom: 20,
    },
    primaryButton: {
      paddingVertical: 14,
      paddingHorizontal: 20,
      borderRadius: 999,
      alignItems: 'center',
      justifyContent: 'center',
    },
    primaryButtonText: {
      fontSize: 15,
      fontWeight: '800',
    },
    itemsList: {
      paddingHorizontal: 16,
      gap: 12,
    },
    cartCard: {
      flexDirection: 'row',
      borderRadius: 20,
      borderWidth: 1,
      padding: 12,
      gap: 12,
    },
    itemImage: {
      width: 80,
      height: 80,
      borderRadius: 16,
    },
    itemContent: {
      flex: 1,
      justifyContent: 'space-between',
      gap: 10,
    },
    itemTopRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 8,
    },
    itemName: {
      fontSize: 15,
      fontWeight: '800',
      lineHeight: 20,
    },
    itemMeta: {
      marginTop: 4,
      fontSize: 12,
    },
    itemBottomRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    itemPrice: {
      fontSize: 16,
      fontWeight: '900',
    },
    quantityRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
    },
    qtyButton: {
      width: 32,
      height: 32,
      borderRadius: 10,
      borderWidth: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    qtyText: {
      minWidth: 20,
      textAlign: 'center',
      fontWeight: '700',
    },
    summaryCard: {
      marginHorizontal: 16,
      marginTop: 18,
      borderRadius: 24,
      borderWidth: 1,
      padding: 18,
    },
    summaryTitle: {
      fontSize: 18,
      fontWeight: '800',
      marginBottom: 14,
    },
    summaryRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 10,
    },
    summaryLabel: {
      fontSize: 14,
    },
    summaryValue: {
      fontSize: 14,
      fontWeight: '700',
    },
    totalRow: {
      marginTop: 6,
      paddingTop: 10,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
  });
}
