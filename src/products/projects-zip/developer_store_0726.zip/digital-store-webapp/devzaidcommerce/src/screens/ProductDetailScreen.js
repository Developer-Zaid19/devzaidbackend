import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StatusBar,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import tw from 'twrnc';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { getTheme } from '../theme';
import { useCart } from '../context/CartContext';
import { useAppSettings } from '../context/AppSettingsContext';
import { useFavorites } from '../context/FavoritesContext';
import { getRelatedProducts, getAllProducts, getRelatedApks, getProjectBySlug, getRelatedProjects, getapksbyslug } from "../lib/products";

export default function ProductDetailScreen({ route, navigation, colorScheme = 'dark' }) {
  const { theme: appTheme } = useAppSettings();
  const theme = appTheme || getTheme(colorScheme);
  const { colors } = theme;
  const { addItem } = useCart();
  const { toggleFavorite, isFavorite } = useFavorites();
  const { product } = route.params || {};
  const [products, setProducts] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const relatedApps = useMemo(() => {
    return getRelatedApks(products, product);
  }, [products, product]);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const data = await getAllProducts();
    setProducts(data);
  };

  const relatedProducts = useMemo(() => {
    return getRelatedProducts(products, product, 4);
  }, [products, product]);

  console.log(product)

  const onRefresh = async () => {
    try {
      setRefreshing(true);
      await loadProducts();
    } finally {
      setRefreshing(false);
    }
  };

  if (!product) {
    return (
      <View style={[tw`flex-1 items-center justify-center`, { backgroundColor: colors.background }]}>
        <Text style={[tw`text-lg font-semibold`, { color: colors.textPrimary }]}>Product not found</Text>
      </View>
    );
  }

  if (product.kiyahai == "notes") {
    return (
      <View style={[tw`flex-1`, { backgroundColor: colors.background }]}>
        <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={tw`pb-8`}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          }>
          <View style={tw`px-4 pt-4`}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => navigation.goBack()}
              style={[
                tw`w-12 h-12 rounded-2xl items-center justify-center mb-4`,
                { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
              ]}>
              <MaterialCommunityIcons name="arrow-left" size={22} color={colors.textPrimary} />
            </TouchableOpacity>

            <Image
              source={{ uri: product.image }}
              style={[
                tw`w-full rounded-[28px]`,
                {
                  height: 280,
                  backgroundColor: "white",
                },
              ]}
              resizeMode="contain"
            />

            <View style={[tw`mt-5 rounded-[28px] p-5`, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}>
              <View style={tw`flex-row items-start justify-between`}>
                <View style={tw`flex-1 pr-3`}>
                  <Text
                    style={[
                      tw`text-xs font-bold uppercase tracking-[1.8px]`,
                      { color: colors.primary },
                    ]}>
                    {(product.type || product.subject || product.category) +
                      (product.what ? ` / ${product.what}` : "")}
                  </Text>
                  <Text style={[tw`text-2xl font-black mt-2`, { color: colors.textPrimary }]}>
                    {product.name}
                  </Text>
                </View>
                <View style={[
                  tw`px-3 py-2 rounded-full`,
                  { backgroundColor: colors.backgroundSecondary },
                ]}>
                  <Text style={[tw`text-sm font-bold`, { color: colors.textPrimary }]}>
                    {product.kiyahai === "notes"
                      ? `${product.pages}`
                      : product.fileSize}
                  </Text>
                </View>
              </View>

              <Text style={[tw`text-base leading-7 mt-4`, { color: colors.textSecondary }]}>
                {product.description}
              </Text>

              <View style={tw`flex-row items-center mt-4`}>
                <MaterialCommunityIcons
                  name="calendar-clock"
                  size={16}
                  color={colors.textSecondary}
                />

                <Text
                  style={[
                    tw`ml-2 text-sm`,
                    { color: colors.textSecondary },
                  ]}>
                  {product.uploaddate ||
                    product.uploadedDate ||
                    product.lastupdate ||
                    "Recently Updated"}
                </Text>
              </View>

              <View style={tw`mt-6 flex-row flex-wrap justify-between`}>
                <InfoCard
                  label="Subject"
                  value={product.type || product.subject || product.category}
                  colors={colors}
                />

                <InfoCard
                  label="Class"
                  value={product.className || product.class}
                  colors={colors}
                />

                <InfoCard
                  label="Pages"
                  value={product.pages ? `${product.pages} Pages` : "-"}
                  colors={colors}
                />

                <InfoCard
                  label="File"
                  value="ZIP/PDF"
                  colors={colors}
                />
              </View>

              <View style={tw`mt-6 flex-row items-center`}>
                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={() => addItem(product)}
                  style={[
                    tw`flex-1 rounded-full py-4 items-center`,
                    { backgroundColor: colors.primary },
                  ]}>
                  <Text style={[tw`text-base font-black`, { color: colors.white }]}>Add to cart</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={() => toggleFavorite(product)}
                  style={[
                    tw`ml-3 h-12 w-12 rounded-full items-center justify-center`,
                    {
                      backgroundColor: isFavorite(product.id) ? colors.primary : colors.backgroundSecondary,
                    },
                  ]}>
                  <Text>{isFavorite(product.id) ? '❤️' : '🤍'}</Text>
                </TouchableOpacity>

              </View>
            </View>
            <View style={tw`mt-8`}>
              <View style={tw`flex-row items-center justify-between mb-4`}>
                <Text
                  style={[
                    tw`text-xl font-black`,
                    { color: colors.textPrimary },
                  ]}>
                  Related Products
                </Text>

                <Text
                  style={[
                    tw`text-sm`,
                    { color: colors.primary },
                  ]}>
                  {relatedProducts.length} items
                </Text>
              </View>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={tw`pr-4`}>
              {relatedProducts.map(item => (
                <TouchableOpacity
                  key={item.id}
                  activeOpacity={0.9}
                  onPress={() =>
                    navigation.push("ProductDetail", {
                      product: item,
                    })
                  }>
                  <View
                    style={[
                      tw`mr-4 rounded-3xl overflow-hidden`,
                      {
                        width: 190,
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                    ]}>
                    <Image
                      source={{ uri: item.image }}
                      style={{
                        width: "100%",
                        height: 120,
                        backgroundColor: colors.backgroundSecondary,
                      }}
                      resizeMode="cover"
                    />
                    <View style={tw`p-3`}>
                      <Text
                        numberOfLines={1}
                        style={[
                          tw`text-xs font-bold uppercase`,
                          {
                            color: colors.primary,
                          },
                        ]}>
                        {item.category}
                      </Text>
                      <Text
                        numberOfLines={2}
                        style={[
                          tw`text-base font-black mt-2`,
                          {
                            color: colors.textPrimary,
                          },
                        ]}>
                        {item.name}
                      </Text>
                      <Text
                        numberOfLines={2}
                        style={[
                          tw`text-sm mt-2`,
                          {
                            color: colors.textSecondary,
                          },
                        ]}>
                        {item.description}
                      </Text>
                      <View style={tw`flex-row items-center justify-between mt-3`}>
                        <Text
                          style={[
                            tw`text-xs`,
                            {
                              color: colors.textSecondary,
                            },
                          ]}>
                          {item.kiyahai === "notes"
                            ? `${item.pages} Pages`
                            : item.fileSize}
                        </Text>

                        <Text
                          style={[
                            tw`text-xs font-bold`,
                            {
                              color: colors.primary,
                            },
                          ]}>
                          FREE
                        </Text>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </ScrollView>
      </View>
    );
  }


  if (product.kiyahai == "apk") {

    const [selectedScreenshot, setSelectedScreenshot] = useState(0);

    useEffect(() => {
      setSelectedScreenshot(0);
    }, [product.id]);
    console.log("SCREENSHOTS:", product.screenshots);

    return (
      <View style={[tw`flex-1`, { backgroundColor: colors.background }]}>
        <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={tw`pb-8`}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          }>
          <View style={tw`px-4 pt-4`}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => navigation.goBack()}
              style={[
                tw`w-12 h-12 rounded-2xl items-center justify-center mb-4`,
                { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
              ]}>
              <MaterialCommunityIcons name="arrow-left" size={22} color={colors.textPrimary} />
            </TouchableOpacity>

            {/* hero */}
            <View style={[tw`mt-5 rounded-[28px] p-5`, { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }]}>
              <View style={tw`flex-row`}>
                <View style={tw`pr-2`}>
                  <Image
                    source={{ uri: product.image }}
                    style={[
                      tw`w-[80px] rounded-full`,
                      {
                        height: 80,
                        backgroundColor: colors.backgroundSecondary,
                      },
                    ]}
                    resizeMode="cover"
                  />
                </View>
                <View>
                  <Text style={[tw`text-xs font-semibold uppercase tracking-[1.8px]`, { color: colors.primary }]}>
                    {product.category}
                  </Text>
                  <Text style={[tw`text-2xl font-black mt-2`, { color: colors.textPrimary }]}>
                    {product.name}
                  </Text>
                </View>

              </View>
              <Text style={[tw`text-base leading-7 mt-4`, { color: colors.textSecondary }]}>
                {product.description}
              </Text>

              <View style={tw`mt-6 flex-row flex-wrap justify-between`}>
                <InfoCard
                  label="Category"
                  value={product.category}
                  colors={colors}
                />

                <InfoCard
                  label="Stack"
                  value={product.stack}
                  colors={colors}
                />

                <InfoCard
                  label="File"
                  value={product.fileSize}
                  colors={colors}
                />

                <InfoCard
                  label="Updated"
                  value={product.lastupdate || "Recently"}
                  colors={colors}
                />
              </View>

              <View style={tw`mt-6 flex-row items-center`}>
                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={() => addItem(product)}
                  style={[
                    tw`flex-1 rounded-full py-4 items-center`,
                    { backgroundColor: colors.primary },
                  ]}>
                  <Text style={[tw`text-base font-black`, { color: colors.white }]}>Add to cart</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={() => toggleFavorite(product)}
                  style={[
                    tw`ml-3 h-12 w-12 rounded-full items-center justify-center`,
                    {
                      backgroundColor: isFavorite(product.id) ? colors.primary : colors.backgroundSecondary,
                    },
                  ]}>
                  <Text>{isFavorite(product.id) ? '❤️' : '🤍'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* screenshot gallery */}
            {product.screenshots?.length > 0 && (
              <>
                <Text
                  style={[
                    tw`text-2xl font-black mt-8 mb-4`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}>
                  Screenshots
                  {/* {product.screenshots[selectedScreenshot]} */}
                </Text>

                <Image
                  source={{
                    uri: (
                      product.screenshots[selectedScreenshot].startsWith("http")
                        ? product.screenshots[selectedScreenshot]
                        : `https://devzaidbackend.onrender.com/projects${product.screenshots[selectedScreenshot]}`
                    ).replace("/projects/img/", "/projects/"),
                  }}
                  style={[
                    tw`w-full rounded-3xl`,
                    {
                      height: 560,
                      backgroundColor: colors.backgroundSecondary,
                    },
                  ]}
                  resizeMode="cover"
                />
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={tw`mt-4 pr-4`}>
                  {product.screenshots.map((image, index) => {
                    console.log("Thumbnail:", image);
                    return (
                      <TouchableOpacity
                        key={index}
                        activeOpacity={selectedScreenshot === index ? 1 : 0.6}
                        style={{
                          transform: [
                            {
                              scale: selectedScreenshot === index ? 1 : 0.92,
                            },
                          ],
                        }}
                        onPress={() => setSelectedScreenshot(index)}>
                        <View
                          style={[
                            tw`mr-3 rounded-2xl overflow-hidden`,
                            {
                              width: 70,
                              height: 125,
                              borderWidth: 2,
                              borderColor:
                                selectedScreenshot === index
                                  ? colors.primary
                                  : colors.border,
                            },
                          ]}>
                          <Image
                            source={{
                              uri: (
                                image.startsWith("http")
                                  ? image
                                  : `https://devzaidbackend.onrender.com/projects${image}`
                              ).replace("/projects/img/", "/projects/"),
                            }}
                            style={{
                              width: "100%",
                              height: "100%",
                            }}
                            resizeMode="cover"
                          />
                        </View>
                      </TouchableOpacity>
                    )
                  })}
                </ScrollView>
              </>
            )}

            {/* about apk */}
            <View>

              <Text
                style={[
                  tw`text-2xl font-black mt-8 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                About App
              </Text>

              {product.aboutapk1 ? (
                <View
                  style={[
                    tw`rounded-3xl p-5 mb-4`,
                    {
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>
                  <Text
                    style={[
                      tw`text-base leading-7`,
                      {
                        color: colors.textSecondary,
                      },
                    ]}>
                    {product.aboutapk1}
                  </Text>
                </View>
              ) : null}

              {product.aboutapk2 ? (
                <View
                  style={[
                    tw`rounded-3xl p-5 mb-4`,
                    {
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>
                  <Text
                    style={[
                      tw`text-base leading-7`,
                      {
                        color: colors.textSecondary,
                      },
                    ]}>
                    {product.aboutapk2}
                  </Text>
                </View>
              ) : null}

              {product.aboutapk3 ? (
                <View
                  style={[
                    tw`rounded-3xl p-5`,
                    {
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>
                  <Text
                    style={[
                      tw`text-base leading-7`,
                      {
                        color: colors.textSecondary,
                      },
                    ]}>
                    {product.aboutapk3}
                  </Text>
                </View>
              ) : null}
            </View>

            {/* key features */}
            <View>
              <Text
                style={[
                  tw`text-2xl font-black mt-8 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                Key Features
              </Text>
              {product.features?.map((feature, index) => (
                <View
                  key={index}
                  style={[
                    tw`flex-row items-start rounded-2xl p-4 mb-3`,
                    {
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>
                  <View
                    style={[
                      tw`w-9 h-9 rounded-full items-center justify-center mr-3`,
                      {
                        backgroundColor: colors.primary,
                      },
                    ]}>
                    <MaterialCommunityIcons
                      name="check"
                      size={20}
                      color={colors.white}
                    />
                  </View>
                  <View style={tw`flex-1`}>
                    <Text
                      style={[
                        tw`text-base font-semibold`,
                        {
                          color: colors.textPrimary,
                        },
                      ]}>
                      {feature}
                    </Text>
                  </View>
                </View>
              ))}
            </View>

            {/* whatsnew */}
            {product.whatsnew && (
              <>
                <Text
                  style={[
                    tw`text-2xl font-black mt-8 mb-4`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}>
                  What's New
                </Text>
                {product.whatsnew.map((item, index) => (
                  <View
                    key={index}
                    style={[
                      tw`flex-row items-start rounded-2xl p-4 mb-3`,
                      {
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                    ]}>
                    <View
                      style={[
                        tw`w-9 h-9 rounded-full items-center justify-center mr-3`,
                        {
                          backgroundColor: colors.primary,
                        },
                      ]}>
                      <MaterialCommunityIcons
                        name="rocket-launch"
                        size={18}
                        color={colors.white}
                      />
                    </View>

                    <Text
                      style={[
                        tw`flex-1 text-base`,
                        {
                          color: colors.textPrimary,
                        },
                      ]}>
                      {item}
                    </Text>
                  </View>
                ))}
              </>
            )}

            {/* related apps */}
            {relatedApps.length > 0 && (
              <>
                <Text
                  style={[
                    tw`text-2xl font-black mt-8 mb-4`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}>
                  Related Apps
                </Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={tw`pr-4`}>
                  {relatedApps.map(item => (
                    <TouchableOpacity
                      key={item.id}
                      activeOpacity={0.9}
                      onPress={() =>
                        navigation.push("ProductDetail", {
                          product: item,
                          products,
                        })
                      }
                      style={[
                        tw`mr-4 rounded-3xl overflow-hidden`,
                        {
                          width: 220,
                          backgroundColor: colors.surface,
                          borderWidth: 1,
                          borderColor: colors.border,
                        },
                      ]}>
                      <Image
                        source={{ uri: item.image }}
                        style={{
                          width: "100%",
                          height: 130,
                        }}
                        resizeMode="cover"
                      />
                      <View style={tw`p-4`}>
                        <Text
                          style={[
                            tw`text-xs font-bold uppercase`,
                            {
                              color: colors.primary,
                            },
                          ]}>
                          {item.category}
                        </Text>
                        <Text
                          numberOfLines={2}
                          style={[
                            tw`text-lg font-black mt-2`,
                            {
                              color: colors.textPrimary,
                            },
                          ]}>
                          {item.name}
                        </Text>
                        <Text
                          numberOfLines={2}
                          style={[
                            tw`text-sm mt-2`,
                            {
                              color: colors.textSecondary,
                            },
                          ]}>
                          {item.description}
                        </Text>
                        <View style={tw`flex-row items-center justify-between mt-4`}>
                          <Text
                            style={[
                              tw`font-bold`,
                              {
                                color: colors.primary,
                              },
                            ]}>
                            FREE
                          </Text>

                          <MaterialCommunityIcons
                            name="arrow-right"
                            size={20}
                            color={colors.primary}
                          />
                        </View>
                      </View>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </>
            )}
          </View>
        </ScrollView>
      </View>
    );
  }

  if (product.kiyahai == "projects") {
    const [project, setProject] = useState(null);
    const [relatedProjects, setRelatedProjects] = useState([]);

    const FILE_URL = "https://devzaidbackend.onrender.com";

    const loadProject = async () => {
      try {
        const data = await getProjectBySlug(product.slug);

        setProject(data);

        const allProducts = await getAllProducts();

        setRelatedProjects(
          getRelatedProjects(allProducts, product, 4)
        );

      } catch (err) {
        console.log(err);
      }
    };

    const onRefresh = async () => {
      try {
        setRefreshing(true);
        await loadProject();
      } finally {
        setRefreshing(false);
      }
    };

    useEffect(() => {
      if (product.kiyahai !== "projects") return;

      loadProject();
    }, []);

    // console.log(project);

    if (product.kiyahai === "projects" && !project) {
      return (
        <View
          style={[
            tw`flex-1 items-center justify-center`,
            {
              backgroundColor: colors.background,
            },
          ]}>
          <ActivityIndicator
            size="large"
            color={colors.primary}
          />
        </View>
      );
    }

    return (
      <View style={tw`px-4 pt-4`}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => navigation.goBack()}
          style={[
            tw`w-12 h-12 rounded-2xl items-center justify-center mb-4`,
            { backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border },
          ]}>
          <MaterialCommunityIcons name="arrow-left" size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={tw`pb-8`}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.primary]}
              tintColor={colors.primary}
            />
          }>

          {/* hero */}
          <View>
            <Image
              source={{
                uri: `${FILE_URL}/projects${project.herosection.title_banner}`,
              }}
              style={[
                tw`w-full rounded-3xl`,
                {
                  height: 200,
                },
              ]}
              resizeMode="cover"
            />
            <Text
              style={[
                tw`text-3xl font-black mt-5`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              {project.herosection.title}
            </Text>
            <Text
              style={[
                tw`text-base leading-7 mt-3`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              {project.herosection.title_desc}
            </Text>
            <View style={tw`flex-row flex-wrap mt-5`}>
              {project.herosection.tech_tags.map((tag, index) => (
                <Text
                  key={index}
                  style={[
                    tw`px-4 py-2 rounded-full mr-2 mb-2 text-sm font-semibold`,
                    {
                      backgroundColor: colors.primary,
                      color: colors.white,
                    },
                  ]}>
                  {tag}
                </Text>
              ))}
            </View>
          </View>

          {/* add to cart button */}
          <View style={tw`mt-6 flex-row items-center`}>
            <TouchableOpacity
              activeOpacity={0.9}
              onPress={() => addItem(product)}
              style={[
                tw`flex-1 rounded-full py-4 items-center`,
                { backgroundColor: colors.primary },
              ]}>
              <Text style={[tw`text-base font-black`, { color: colors.white }]}>Add to cart</Text>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.9}
              onPress={() => toggleFavorite(product)}
              style={[
                tw`ml-3 h-12 w-12 rounded-full items-center justify-center`,
                {
                  backgroundColor: isFavorite(product.id) ? colors.primary : colors.backgroundSecondary,
                },
              ]}>
              <Text>{isFavorite(product.id) ? '❤️' : '🤍'}</Text>
            </TouchableOpacity>

          </View>

          {/* highlights */}
          <View>
            <Text
              style={[
                tw`text-2xl font-black mt-8 mb-4`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              Highlights
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={tw`pr-4`}>
              {project.herosection.unique.map((item, index) => (
                <View
                  key={index}
                  style={[
                    tw`mr-4 rounded-3xl p-5`,
                    {
                      width: 170,
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>
                  <Text
                    style={[
                      tw`text-3xl font-black`,
                      {
                        color: colors.primary,
                      },
                    ]}>
                    {item.value}
                  </Text>
                  <Text
                    style={[
                      tw`text-base font-bold mt-2`,
                      {
                        color: colors.textPrimary,
                      },
                    ]}>
                    {item.label}
                  </Text>
                  <Text
                    style={[
                      tw`text-sm mt-2`,
                      {
                        color: colors.textSecondary,
                      },
                    ]}>
                    {item.sub}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>

          {/* overview */}
          <View>
            <Text
              style={[
                tw`text-2xl font-black mt-8 mb-4`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              {project.overview.purpose}
              {`${FILE_URL}/projects${project.overview.purpose_img}`}
            </Text>

            <Image
              source={{
                uri: `${FILE_URL}/projects${project.overview.purpose_img}`,
              }}
              style={[
                tw`w-full rounded-3xl mb-5`,
                {
                  height: 220,
                },
              ]}
              resizeMode="cover"
            />

            <Text
              style={[
                tw`text-base leading-7`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              {project.overview.whatdo}
            </Text>

            <Text
              style={[
                tw`text-base leading-7 mt-4`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              {project.overview.howdo}
            </Text>

            <Text
              style={[
                tw`text-xl font-black mt-6 mb-4`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              Features
            </Text>
            {project.overview.facilities.map((item, index) => (
              <View
                key={index}
                style={tw`flex-row items-start mb-4`}>
                <View
                  style={[
                    tw`w-8 h-8 rounded-full items-center justify-center mr-3`,
                    {
                      backgroundColor: colors.primary,
                    },
                  ]}>
                  <MaterialCommunityIcons
                    name="check"
                    size={18}
                    color={colors.white}
                  />
                </View>
                <Text
                  style={[
                    tw`flex-1 text-base`,
                    {
                      color: colors.textPrimary,
                    },
                  ]}>
                  {item}
                </Text>
              </View>
            ))}
          </View>

          {/* super concept */}
          {project.structure.section_superconcept && (
            <>
              <Text
                style={[
                  tw`text-2xl font-black mt-8 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                {project.section_superconcept.title}
              </Text>
              <Image
                source={{
                  uri: `${FILE_URL}/projects${project.section_superconcept.superconceptimg}`,
                }}
                style={[
                  tw`w-full rounded-3xl mb-5`,
                  {
                    height: 220,
                  },
                ]}
                resizeMode="cover"
              />

              <Text
                style={[
                  tw`text-base leading-7`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {project.section_superconcept.whatitworks}
              </Text>

              <Text
                style={[
                  tw`text-base leading-7 mt-4`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {project.section_superconcept.howitworks}
              </Text>

              <Text
                style={[
                  tw`text-xl font-black mt-6 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                {project.section_superconcept.techdivtitle}
              </Text>
              <View style={tw`flex-row flex-wrap`}>
                {project.section_superconcept.techdivtags.map((tag, index) => (
                  <Text
                    key={index}
                    style={[
                      tw`px-4 py-2 rounded-full mr-2 mb-2 text-sm font-semibold`,
                      {
                        backgroundColor: colors.primary,
                        color: colors.white,
                      },
                    ]}>
                    {tag}
                  </Text>
                ))}
              </View>
            </>
          )}

          {/* section mobile app */}
          {project.structure.section_mobileapp && (
            <>
              <Text
                style={[
                  tw`text-2xl font-black mt-8 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                {project.section_mobileapp.title}
                {/* {`${FILE_URL}/projects${project.section_mobileapp.appimage}`} */}
              </Text>
              <Image
                source={{
                  uri: `${FILE_URL}/projects${project.section_mobileapp.appimage}`,
                }}
                style={[
                  tw`self-center rounded-3xl`,
                  {
                    width: 220,
                    height: 460,
                  },
                ]}
                resizeMode="cover"
              />
              <Text
                style={[
                  tw`text-base leading-7 mt-5`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {project.section_mobileapp.whatappworks}
              </Text>

              <Text
                style={[
                  tw`text-base leading-7 mt-5`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {project.section_mobileapp.howappworks}
              </Text>

              <Text
                style={[
                  tw`text-xl font-black mt-6 mb-4`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                Features
              </Text>

              {project.section_mobileapp.appfeatures.map((feature, index) => (
                <View
                  key={index}
                  style={[
                    tw`rounded-3xl p-5 mb-4`,
                    {
                      backgroundColor: colors.surface,
                      borderWidth: 1,
                      borderColor: colors.border,
                    },
                  ]}>

                  <View style={tw`flex-row items-center`}>
                    <View
                      style={[
                        tw`w-10 h-10 rounded-full items-center justify-center`,
                        {
                          backgroundColor: colors.primary,
                        },
                      ]}>
                      <MaterialCommunityIcons
                        name="check"
                        size={20}
                        color={colors.white}
                      />
                    </View>

                    <Text
                      style={[
                        tw`ml-3 text-lg font-black flex-1`,
                        {
                          color: colors.textPrimary,
                        },
                      ]}>
                      {feature.title}
                    </Text>
                  </View>

                  <Text
                    style={[
                      tw`mt-4 text-base leading-7`,
                      {
                        color: colors.textSecondary,
                      },
                    ]}>
                    {feature.desc}
                  </Text>
                </View>
              ))}
            </>
          )}

          {/* mobile working */}
          {project.structure.section_mobileworking && (
            <>
              <Text
                style={[
                  tw`text-2xl font-black mt-8`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                {project.section_mobileworking.title}
              </Text>
              <Text
                style={[
                  tw`text-lg font-bold mt-5`,
                  {
                    color: colors.primary,
                  },
                ]}>
                {project.section_mobileworking.systemworktitle}
              </Text>
              <Text
                style={[
                  tw`text-base leading-7 mt-3`,
                  {
                    color: colors.textSecondary,
                  },
                ]}>
                {project.section_mobileworking.systemworkdesc}
              </Text>
              <Image
                source={{
                  uri: `${FILE_URL}/projects${project.section_mobileworking.systemworkimg}`,
                }}
                style={[
                  tw`self-center rounded-3xl`,
                  {
                    width: 220,
                    height: 460,
                  },
                ]}
                resizeMode="cover"
              />
            </>
          )}

          {/* architecture */}
          <View>
            <Text
              style={[
                tw`text-2xl font-black mt-8`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              {project.architecture.systemstructure}
            </Text>
            <Text
              style={[
                tw`text-base leading-7 mt-3`,
                {
                  color: colors.textSecondary,
                },
              ]}>
              {project.architecture.systemstrucdesc}
            </Text>
            <Image
              source={{
                uri: `${FILE_URL}/projects${project.architecture.systemstrucbanner}`,
              }}
              style={[
                tw`w-full rounded-3xl mt-5`,
                {
                  height: 230,
                },
              ]}
              resizeMode="contain"
            />
            <Text
              style={[
                tw`text-xl font-black mt-6 mb-4`,
                {
                  color: colors.textPrimary,
                },
              ]}>
              Tech Stack
            </Text>
            {project.architecture.systemtags.map((item, index) => (
              <View
                key={index}
                style={[
                  tw`rounded-3xl p-5 mb-4`,
                  {
                    backgroundColor: colors.surface,
                    borderWidth: 1,
                    borderColor: colors.border,
                  },
                ]}>
                <Text
                  style={[
                    tw`text-lg font-black`,
                    {
                      color: colors.primary,
                    },
                  ]}>
                  {item.title}
                </Text>
                <Text
                  style={[
                    tw`text-base mt-2 leading-6`,
                    {
                      color: colors.textSecondary,
                    },
                  ]}>
                  {item.desc}
                </Text>
              </View>
            ))}
          </View>

          {/* related projects */}
          {relatedProjects.length > 0 && (
            <>
              <Text
                style={[
                  tw`text-2xl font-black mt-8 mb-5`,
                  {
                    color: colors.textPrimary,
                  },
                ]}>
                Related Projects
              </Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={tw`pr-4`}>

                {relatedProjects.map(item => (
                  <TouchableOpacity
                    key={item.id}
                    activeOpacity={0.9}
                    onPress={() =>
                      navigation.push("ProductDetail", {
                        product: item,
                        products,
                      })
                    }
                    style={[
                      tw`mr-4 rounded-3xl overflow-hidden`,
                      {
                        width: 220,
                        backgroundColor: colors.surface,
                        borderWidth: 1,
                        borderColor: colors.border,
                      },
                    ]}>

                    <Image
                      source={{ uri: item.image }}
                      style={{
                        width: "100%",
                        height: 150,
                      }}
                      resizeMode="cover"
                    />

                    <View style={tw`p-4`}>
                      <Text
                        numberOfLines={2}
                        style={[
                          tw`text-base font-black`,
                          {
                            color: colors.textPrimary,
                          },
                        ]}>
                        {item.name}
                      </Text>

                      <Text
                        numberOfLines={2}
                        style={[
                          tw`text-sm mt-2`,
                          {
                            color: colors.textSecondary,
                          },
                        ]}>
                        {item.description}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}

              </ScrollView>
            </>
          )}
          {/* <Text style={[tw`text-xs font-semibold tracking-[1.8px]`, { color: colors.primary }]}>
        </Text> */}
        </ScrollView>
      </View>
    )

  }


  return (
    <View style={[tw`flex-1 items-center justify-center`, { backgroundColor: colors.background }]}>
      <Text style={[tw`text-lg font-semibold`, { color: colors.textPrimary }]}>Detailed Screen not found</Text>
    </View>
  );
}


function InfoCard({ label, value, colors }) {
  return (
    <View
      style={[
        tw`rounded-2xl p-4 mb-3`,
        {
          width: "48%",
          backgroundColor: colors.backgroundSecondary,
          borderWidth: 1,
          borderColor: colors.border,
        },
      ]}>
      <Text
        style={[
          tw`text-xs font-bold uppercase`,
          { color: colors.textSecondary },
        ]}>
        {label}
      </Text>

      <Text
        numberOfLines={2}
        style={[
          tw`text-base font-black mt-2`,
          { color: colors.textPrimary },
        ]}>
        {value || "-"}
      </Text>
    </View>
  );
}