import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CART_STORAGE_KEY = '@developerzaidstore/cart';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let mounted = true;

    const loadCart = async () => {
      try {
        const raw = await AsyncStorage.getItem(CART_STORAGE_KEY);

        if (mounted && raw) {
          const parsed = JSON.parse(raw);

          if (Array.isArray(parsed)) {
            setItems(parsed);
          }
        }
      } catch (error) {
        console.log('Cart read error:', error);
      } finally {
        if (mounted) {
          setIsReady(true);
        }
      }
    };

    loadCart();

    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isReady) {
      return;
    }

    AsyncStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items)).catch(error => {
      console.log('Cart write error:', error);
    });
  }, [isReady, items]);

  const addItem = useCallback(product => {
    setItems(prevItems => {
      const exists = prevItems.some(
        item =>
          item.itemId === product.id &&
          item.kiyahai === product.kiyahai,
      );

      if (exists) {
        return prevItems;
      }

      return [
        ...prevItems,
        {
          itemId: product.id,
          kiyahai: product.kiyahai,
        },
      ];
    });
  }, []);

  const removeItem = useCallback((itemId, kiyahai) => {
    setItems(prevItems =>
      prevItems.filter(
        item =>
          !(
            item.itemId === itemId &&
            item.kiyahai === kiyahai
          ),
      ),
    );
  }, []);

  const clearCart = useCallback(() => {
    setItems([]);
  }, []);

  const cartCount = items.length;

  const totalItems = cartCount;

  const value = useMemo(
    () => ({
      items,
      addItem,
      removeItem,
      clearCart,
      cartCount,
      totalItems,
    }),
    [
      items,
      addItem,
      removeItem,
      clearCart,
      cartCount,
      totalItems,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export const useCart = () => {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }

  return context;
};
