# 📱 Developer Zaid Store Mobile App

A modern Android application built with **React Native** for browsing and downloading study notes, source code projects, and Android APKs.

The application focuses on speed, simplicity, and offline accessibility using local caching.

---

## ✨ Features

* 📚 Notes Marketplace
* 💻 Source Code Marketplace
* 📱 APK Marketplace
* 🔍 Smart Search
* 🏷 Category & Subject Filters
* ❤️ Favorites
* 🛒 Shopping Cart
* 📄 Rich Product Details
* 🖼 Screenshot Gallery
* 🌙 Light & Dark Theme
* 📦 Offline Product Cache
* 🔄 Pull To Refresh
* ⚡ Fast Native Performance

---

## 🛠 Tech Stack

* React Native CLI
* React Navigation
* AsyncStorage
* TWRNC (Tailwind for React Native)
* React Native Vector Icons
* JavaScript
* Express.js REST API
* MongoDB

---

## 📦 Product Types

### 📚 Notes

* PDF Study Notes
* Subject Wise
* Class Wise

### 💻 Source Code Projects

* Complete Source Code
* Detailed Documentation
* Screenshots
* Architecture Overview

### 📱 APK Applications

* Screenshots
* Features
* What's New
* Version Information
* Related Apps

---

## 📦 Offline Support

The app uses **AsyncStorage** to cache product lists locally.

Cached data includes:

* Notes
* Source Code Projects
* APKs

Users can continue browsing products even when internet connectivity is unavailable. Product details are always fetched online to ensure the latest information.

---

## 🚀 Installation

```bash
git clone <repository-url>

npm install

npx react-native run-android
```

---

## 📡 Backend API

The application communicates with an Express.js backend using REST APIs.

Main endpoints include:

* `/content/notes`
* `/content/projects`
* `/products/apks`

---

## 📌 Future Roadmap

* User Authentication
* Download Manager
* Order History
* Reviews & Ratings
* Push Notifications
* Tablet Optimization
* iOS Support

---

## 👨‍💻 Author

**Developer Zaid**

Full Stack Web & Mobile Application Developer

If you like this project, consider giving it a ⭐ on GitHub.
