"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useCart } from "@/components/CartProvider";
import { useTheme } from "@/components/ThemeProvider";
import site from "@/data/site.json";
import { FaMoon, FaSun, FaBars, FaXmark } from "react-icons/fa6";

const navItems = [
  { href: "/", label: "Home" },
  { href: "/products", label: "Products" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const pathname = usePathname();
  const { totals } = useCart();
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);

  return (
    <header
      className="sticky top-0 z-50 backdrop-blur-md"
      style={{ backgroundColor: "var(--nav-bg)", borderBottom: "1px solid var(--nav-border)" }}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <Image src="/logo.png" alt={`${site.name} logo`} width={40} height={40} />
          <span className="text-base font-black sm:text-lg" style={{ color: "var(--foreground)" }}>
            {site.name}
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {navItems.map((item) => (
            <NavLink key={item.href} item={item} active={pathname === item.href} />
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="grid h-9 w-9 place-items-center rounded-full transition-all hover:scale-105 active:scale-95"
            style={{
              border: "1px solid var(--border)",
              color: "var(--foreground-muted)",
              backgroundColor: "var(--background-subtle)",
            }}
          >
            {theme === "dark" ? <FaSun /> : <FaMoon />}
          </button>

          <Link
            href="/cart"
            className="hidden items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition-all hover:scale-105 sm:flex"
            style={{
              border: "1px solid var(--border)",
              color: "var(--foreground)",
              backgroundColor: "var(--background-card)",
            }}
          >
            Cart
            <span>{totals.count}</span>
          </Link>

          <Link
            href="/products"
            className="hidden rounded-full px-4 py-2 text-sm font-bold transition-all hover:scale-105 active:scale-95 sm:inline-flex"
            style={{ backgroundColor: "var(--accent)", color: "var(--cta-text)" }}
          >
            Browse Products
          </Link>

          <button
            type="button"
            onClick={() => setOpen((current) => !current)}
            className="grid h-9 w-9 place-items-center rounded-full md:hidden"
            style={{ border: "1px solid var(--border)", color: "var(--foreground)" }}
            aria-expanded={open}
            aria-label="Toggle navigation"
          >
            {open ? <FaXmark /> : <FaBars />}
          </button>
        </div>
      </nav>

      {open ? (
        <div
          className="border-t px-4 py-3 md:hidden"
          style={{ backgroundColor: "var(--background-card)", borderColor: "var(--border)" }}
        >
          <div className="mx-auto grid max-w-7xl gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-4 py-3 text-sm font-semibold transition"
                style={{
                  color: pathname === item.href ? "var(--brand)" : "var(--foreground)",
                  backgroundColor: pathname === item.href ? "var(--brand-faint)" : "transparent",
                }}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/cart"
              onClick={() => setOpen(false)}
              className="rounded-lg px-4 py-3 text-sm font-semibold"
              style={{ color: "var(--foreground)" }}
            >
              Saved notes ({totals.count})
            </Link>
          </div>
        </div>
      ) : null}
    </header>
  );
}

function NavLink({ item, active }) {
  return (
    <Link
      href={item.href}
      className="rounded-full px-4 py-2 text-sm font-semibold transition-all"
      style={{
        backgroundColor: active ? "var(--foreground)" : "transparent",
        color: active ? "var(--background)" : "var(--foreground-muted)",
      }}
    >
      {item.label}
    </Link>
  );
}
