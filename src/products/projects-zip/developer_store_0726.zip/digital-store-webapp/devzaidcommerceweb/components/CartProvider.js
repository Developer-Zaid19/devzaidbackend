"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [products, setProducts] = useState([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    async function loadProducts() {
      try {
        const response = await fetch("/api/products");
        if (!response.ok) {
          throw new Error("Failed to load products");
        }
        const productsData = await response.json();
        setProducts(productsData);
      } catch (error) {
        setProducts([]);
      }
    }

    loadProducts();
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("DeveloperZaid-cart");

      if (saved) {
        setItems(JSON.parse(saved));
      }
    } catch (error) {
      console.error("Failed to load cart", error);
      localStorage.removeItem("DeveloperZaid-cart");
    } finally {
      setReady(true);
    }
  }, []);


  useEffect(() => {
    if (!ready) return;

    localStorage.setItem(
      "DeveloperZaid-cart",
      JSON.stringify(items)
    );
  }, [items, ready]);

  const enrichedItems = useMemo(
    () =>
      items
        .map((item) =>
          products.find(
            (product) =>
              product.url === item.id
          )
        )
        .filter(Boolean),
    [items, products]
  );

  const totals = {
    count: enrichedItems.length,
  };

  function addItem(id, type) {
    setItems((current) => {
      const exists = current.some(
        (item) => item.id === id && item.type === type
      );

      if (exists) {
        return current;
      }

      return [...current, { id, type }];
    });
  }

  useEffect(() => {
    console.log("items changed:", items);
  }, [items]);

  function removeItem(id) {
    setItems((current) => current.filter((item) => item.id !== id));
    console.log(id)
    console.log(items)
  }

  function clearCart() {
    setItems([]);
  }

  const value = {
    items: enrichedItems,
    cartIds: items,
    totals,
    addItem,
    removeItem,
    clearCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error("useCart must be used inside CartProvider");
  }
  return context;
}
