import Image from "next/image";
import Link from "next/link";
import AddToCartButton from "@/components/AddToCartButton";
import { formatDate, formatPrice } from "@/lib/products";

export default function ProductCard({ product }) {
  const slug = product.slug || product.url;

  return (
    <article
      id={product.id}
      className="group overflow-hidden rounded-lg transition-all duration-300 hover:-translate-y-1"
      style={{
        backgroundColor: "var(--background-card)",
        border: "1px solid var(--border)",
        boxShadow: "var(--shadow-sm)",
        clipPath:
          "polygon(0 0, calc(100% - 30px) 0, 100% 30px, 100% 100%, 0 100%)",
      }}
    >
      <Link
        href={`/products/notes/${slug}`}
        className="relative block aspect-[4/3] overflow-hidden"
        style={{ backgroundColor: "var(--background-subtle)" }}
      >
        <Image
          src={`/notes/img${product.image || "penpencil.webp"}`}
          alt={product.title || product.name}
          fill
          sizes="(min-width: 1280px) 25vw, (min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
          className="h-full w-full transition duration-500 group-hover:scale-105 bg-white"
        />
        <span
          className="absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-bold backdrop-blur-sm"
          style={{
            backgroundColor: "var(--background-card)",
            color: "var(--foreground)",
            boxShadow: "var(--shadow-sm)",
          }}
        >
          {product.what || product.badge || "PDF"}
        </span>
      </Link>

      <div className="space-y-4 p-5">
        <div className="space-y-2">
          <div
            className="flex items-center justify-between gap-3 text-xs font-bold uppercase"
            style={{ color: "var(--brand)" }}
          >
            <span>{product.subject || product.category}</span>
            <span style={{ color: "var(--foreground-faint)" }}>
              {product.pages || product.pagesCount} pages
            </span>
          </div>
          <Link href={`/products/notes/${slug}`}>
            <h3 className="text-base font-bold leading-snug" style={{ color: "var(--foreground)" }}>
              {product.title || product.name}
            </h3>
          </Link>
          <p className="line-clamp-2 text-sm leading-6" style={{ color: "var(--foreground-muted)" }}>
            {product.description}
          </p>
        </div>

        <div className="grid gap-3 text-xs" style={{ color: "var(--foreground-faint)" }}>
          <div className="flex items-center justify-between">
            <span>{product.className || product.class}</span>
            <span>{formatDate(product.uploaddate)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span>{product.fileSize}</span>
          </div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <span className="text-lg font-black" style={{ color: "var(--foreground)" }}>
            {formatPrice(product.price)}
          </span>
          <AddToCartButton productId={product.url} compact type={"notes"} />
        </div>
      </div>
    </article>
  );
}
