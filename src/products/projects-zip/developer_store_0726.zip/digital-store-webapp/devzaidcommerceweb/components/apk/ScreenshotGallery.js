"use client";

import { useState } from "react";
import Image from "next/image";

export default function ScreenshotGallery({ screenshots = [], title }) {
    const [selected, setSelected] = useState(0);
    console.log(screenshots)

    return (
        <section className="my-10 space-y-5">
            <PhoneFrame src={`/projects/img/${screenshots[selected]}`} alt={title} tall />


            <div className="grid grid-cols-4 gap-4 md:grid-cols-6">

                {screenshots.map((image, index) => (

                    <button
                        key={index}
                        onClick={() => setSelected(index)}
                        className="relative aspect-[9/16] overflow-hidden rounded-xl border transition-all duration-200 hover:scale-105"
                        style={{
                            borderColor:
                                selected === index
                                    ? "var(--brand)"
                                    : "var(--border)",
                            boxShadow:
                                selected === index
                                    ? "var(--shadow-md)"
                                    : "none",
                        }}
                    >
                        <Image
                            src={`/projects/img${image}`}
                            alt="adb"
                            fill
                            className="object-cover"
                        />

                    </button>

                ))}

            </div>
        </section>
    );
}

function PhoneFrame({ src, alt, tall = false }) {
    return (
        <div className="flex justify-center">
            <div
                className={`relative bg-(--background-subtle) rounded-[2.5rem] border-4 border-(--border-strong) shadow-2xl overflow-hidden ${tall ? "md:w-56 w-64" : "w-52"
                    }`}
            >
                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-5 bg-(--background-subtle) rounded-b-2xl z-10" />
                <img
                    src={src}
                    alt={alt}
                    className={`w-full object-cover object-top ${tall ? "h-[480px]" : "h-96"}`}
                />
                {/* Home bar */}
                <div className="flex justify-center py-2 bg-(--background-subtle)">
                    <div className="w-20 h-1 bg-zinc-500 rounded-full" />
                </div>
            </div>
        </div>
    );
}