import Image from "next/image";
import Link from "next/link";
import AddToCartButton from "@/components/AddToCartButton";
import { formatDate, formatPrice } from "@/lib/products";

export default function SourceCodeCard({ product }) {
    const slug = product.slug || product.url;

    return (
        <article
            id={product.id}
            className="group overflow-hidden rounded-xl transition-all duration-300 hover:-translate-y-2"
            style={{
                backgroundColor: "var(--background-card)",
                border: "1px solid var(--border)",
                boxShadow: "var(--shadow-sm)",
                
            }}
        >
            <Link
                href={`/products/projects/${slug}`}
                className="relative block aspect-[4/3] overflow-hidden"
            >
                <Image
                    src={`/projects/img${product.image || "penpencil.webp"}`}
                    alt={product.title || product.name}
                    fill
                    loading="eager"
                    sizes="(min-width: 1280px) 25vw, (min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                    className="object-cover transition duration-700 group-hover:scale-110"
                />

                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/10 to-transparent" />

                {/* Badge */}
                <span
                    className="absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-semibold backdrop-blur-md"
                    style={{
                        backgroundColor: "rgba(255,255,255,.12)",
                        color: "#fff",
                        border: "1px solid rgba(255,255,255,.2)",
                    }}
                >
                    {product.what || product.badge || "SOURCE CODE"}
                </span>
            </Link>

            <div className="p-5 space-y-4">
                {/* Category */}
                <div
                    className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide"
                    style={{ color: "var(--brand)" }}
                >
                    <span>{product.subject || product.category}</span>                    
                </div>

                {/* Title */}
                <Link href={`/products/projects/${slug}`}>
                    <h3
                        className="text-lg font-bold line-clamp-2 min-h-[56px] transition-colors"
                        style={{ color: "var(--foreground)" }}
                    >
                        {product.title || product.name}
                    </h3>
                </Link>

                {/* Description */}
                <p
                    className="line-clamp-2 text-sm leading-6"
                    style={{ color: "var(--foreground-muted)" }}
                >
                    {product.description}
                </p>

                {/* Meta */}
                {/* <div
                    className="flex flex-wrap gap-x-4 gap-y-2 text-xs"
                    style={{ color: "var(--foreground-faint)" }}
                >
                    <span>📅 {formatDate(product.uploaddate)}</span>
                    <span>💾 {product.fileSize}</span>
                </div> */}

                {/* Footer */}
                <div
                    className="flex items-center justify-between border-t pt-4"
                    style={{ borderColor: "var(--border)" }}
                >
                    <div>
                        <p
                            className="text-xs"
                            style={{ color: "var(--foreground-faint)" }}
                        >
                            Price
                        </p>
                        <span
                            className="text-2xl font-black"
                            style={{ color: "var(--foreground)" }}
                        >
                            {formatPrice(product.price)}
                        </span>
                    </div>

                    <AddToCartButton
                        productId={product.slug}
                        compact
                        type="sourcecode"
                    />
                </div>
            </div>
        </article>
    );
}
