"use client";

import Image from "next/image";
import Link from "next/link";
import { useCart } from "@/components/CartProvider";
import { formatPrice } from "../lib/products";
import { useState } from "react";

export default function CartView() {
  const { items, totals, removeItem, cartIds, clearCart } = useCart();
  const [isloading, setisloading] = useState(false)

  const handleCheckout = async () => {
    try {
      setisloading(true)
      const response = await fetch("/api/download", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(cartIds),
      });

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "DeveloperZaid.zip";
      a.click();

      window.URL.revokeObjectURL(url);
      setisloading(false)
      clearCart()
    } catch (error) {
      console.error(error);
    } finally {
      setisloading(false)
    }
  };

  if (items.length === 0) {
    return (
      <section className="mx-auto max-w-3xl px-4 py-24 text-center sm:px-6">
        <p className="text-sm font-bold uppercase tracking-widest" style={{ color: "var(--brand)" }}>
          Cart
        </p>
        <h1 className="mt-3 text-4xl font-black" style={{ color: "var(--foreground)" }}>
          Your Cart is empty.
        </h1>
        <p className="mx-auto mt-4 max-w-xl" style={{ color: "var(--foreground-muted)" }}>
          Cart you want to revisit and they will appear here.
        </p>
        <Link
          href="/products"
          className="mt-8 inline-flex rounded-full px-6 py-3 text-sm font-bold text-white transition-all hover:scale-105"
          style={{ backgroundColor: "var(--brand)" }}
        >
          Browse More
        </Link>
      </section>
    );
  }

  return (
    <section
      className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8"
      style={{ backgroundColor: "var(--background)" }}
    >
      <div className="mb-8">
        <p className="text-sm font-bold uppercase tracking-widest" style={{ color: "var(--brand)" }}>
          Cart Products
        </p>
        <h1 className="mt-2 text-4xl font-black" style={{ color: "var(--foreground)" }}>
          Review your Cart
        </h1>
      </div>

      <div className="grid gap-8 lg:grid-cols-[1fr_380px]">
        {/* Items */}
        <div className="grid gap-4">
          {items.map((item) => (
            <article
              key={item.id}
              className="grid gap-4 rounded-2xl p-4 sm:grid-cols-[140px_1fr_auto] transition-all"
              style={{
                backgroundColor: "var(--background-card)",
                border: "1px solid var(--border)",
                boxShadow: "var(--shadow-sm)",
              }}
            >
              <Image
                // src={`/${"notes" || "projects"}/img${item.image}`}
                src={`/${item.kiyahai}/img${item.image}`}
                alt={item.name}
                width={140}
                height={140}
                className="aspect-square w-full rounded-xl object-cover sm:w-[140px] bg-transparent"
              />
              <div className="space-y-2">
                <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--brand)" }}>
                  {item.category}
                </p>
                <h2 className="text-lg font-bold" style={{ color: "var(--foreground)" }}>
                  {item.name}
                </h2>
                <p className="text-sm leading-6" style={{ color: "var(--foreground-muted)" }}>
                  {item.description}
                </p>
                <button
                  type="button"
                  onClick={() => removeItem(item.id)}
                  className="text-sm font-bold transition hover:opacity-70"
                  style={{ color: "#ef4444" }}
                >
                  Remove
                </button>
              </div>
              <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
                <span className="text-lg font-black" style={{ color: "var(--foreground)" }}>
                  {formatPrice(item.price * item.quantity)}
                </span>
              </div>
            </article>
          ))}
        </div>

        {/* Order summary */}
        <aside
          className="h-fit rounded-2xl p-6"
          style={{
            backgroundColor: "var(--background-card)",
            border: "1px solid var(--border)",
            boxShadow: "var(--shadow-md)",
          }}
        >
          <h2 className="text-xl font-black" style={{ color: "var(--foreground)" }}>
            Download summary
          </h2>
          <div className="mt-6 grid gap-4 text-sm">
            <SummaryLine label="Total Products" value={totals.count} />
            <SummaryLine label="Payment" value="None" />
            <div className="pt-4" style={{ borderTop: "1px solid var(--border)" }}>
              <SummaryLine label="Total" value="Free" strong />
            </div>
          </div>
          <button
            className="mt-6 flex w-full justify-center rounded-full px-5 py-3 text-sm font-black transition-all hover:scale-105 active:scale-95"
            style={{ backgroundColor: "var(--accent)", color: "var(--cta-text)" }}
            disabled={isloading}
            onClick={() => handleCheckout()}
          >
            {isloading ? "Collecting..." : "CheckOut"}
          </button>
        </aside>
      </div>
    </section>
  );
}

function SummaryLine({ label, value, strong = false }) {
  return (
    <div
      className="flex items-center justify-between gap-4"
      style={{
        color: strong ? "var(--foreground)" : "var(--foreground-muted)",
        fontWeight: strong ? 900 : 400,
        fontSize: strong ? "1.1rem" : "0.875rem",
      }}
    >
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
