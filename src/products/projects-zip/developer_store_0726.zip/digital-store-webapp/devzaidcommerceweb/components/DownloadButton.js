"use client";

export default function DownloadButton({ note, compact = false }) {

  return (
    <a
    href={`/notes/pdf/${note.url}`}
      className="rounded-full text-sm font-black transition-all hover:scale-105 active:scale-95"
      style={{
        backgroundColor: "var(--accent)",
        color: "var(--cta-text)",
        padding: compact ? "0.45rem 1rem" : "0.7rem 1.35rem",
        boxShadow: "var(--shadow-sm)",
      }}
    >
      Download
    </a>
  );
}
