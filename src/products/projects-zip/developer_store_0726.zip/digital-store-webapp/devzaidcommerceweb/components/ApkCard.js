import Image from "next/image";
import Link from "next/link";
import AddToCartButton from "@/components/AddToCartButton";
import { formatDate, formatPrice } from "@/lib/products";

export default function ApkCard({ product }) {
    const slug = product.slug || product.url;

    return (
        <article
            id={product.id}
            className="group overflow-hidden rounded-2xl border transition-all duration-300 hover:-translate-y-2 hover:shadow-xl"
            style={{
                backgroundColor: "var(--background-card)",
                borderColor: "var(--border)",
            }}
        >
            <div className="p-5">
                <Link href={`/products/apks/${product.id}`}>

                    {/* Header */}
                    <div className="flex flex-col gap-4 justify-center items-center">
                        <div className="relative h-20 w-20 overflow-hidden rounded-2xl">
                            <Image
                                // src={`/apk-icons/${product.icon}`}
                                src={`/apk/img${product.image}`}
                                alt={product.name}
                                fill
                                className="object-cover "
                            />
                        </div>

                        <div className="flex-1">
                            <h3
                                className="text-lg font-bold text-center"
                                style={{ color: "var(--foreground)" }}
                            >
                                {product.name}
                            </h3>

                            <p
                                className="text-sm mt-1"
                                style={{ color: "var(--foreground-muted)" }}
                            >
                                {product.description}
                            </p>

                            <div className="mt-2 flex flex-wrap gap-2">
                                <span
                                    className="rounded-full px-2 py-1 text-xs"
                                    style={{
                                        backgroundColor: "var(--background-subtle)"
                                    }}
                                >
                                    {product.category}
                                </span>

                                <span
                                    className="rounded-full px-2 py-1 text-xs"
                                    style={{
                                        backgroundColor: "var(--background-subtle)"
                                    }}
                                >
                                    v{product.version}
                                </span>
                                <span
                                    className="rounded-full px-2 py-1 text-xs"
                                    style={{
                                        backgroundColor: "var(--background-subtle)"
                                    }}
                                >
                                    ReactNative
                                </span>
                            </div>
                        </div>
                    </div>

                    {/* Stats */}
                    <div
                        className="mt-5 grid grid-cols-2 gap-3 border-y py-4"
                        style={{ borderColor: "var(--border)" }}
                    >
                        <div>
                            <p className="text-xs opacity-70">FileType</p>
                            <p className="font-bold">ZIP/APK</p>
                        </div>

                        <div>
                            <p className="text-xs opacity-70">Last Update</p>
                            <p className="font-bold">{product.lastUpdated}</p>
                        </div>

                        <div>
                            <p className="text-xs opacity-70">Size</p>
                            <p className="font-bold">{product.apkSize}MB</p>
                        </div>
                        <div>
                            <p className="text-xs opacity-70">Android</p>
                            <p className="font-bold">{product.androidVersion}</p>
                        </div>
                    </div>

                    {/* Compatibility */}
                    <div
                        className="mt-4 text-sm"
                        style={{ color: "var(--foreground-muted)" }}
                    >
                        Android {product.androidVersion}

                    </div>
                </Link>
                {/* Footer */}
                <div className="mt-5 flex items-center justify-between">
                    <div>
                        <span
                            className="text-2xl font-black"
                            style={{ color: "var(--foreground)" }}
                        >
                            FREE
                        </span>
                    </div>

                    <AddToCartButton
                        productId={product.slug}
                        type="apk"
                    />
                </div>
            </div>

        </article>
    );
}
