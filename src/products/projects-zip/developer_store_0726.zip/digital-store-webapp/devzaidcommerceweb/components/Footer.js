import Image from "next/image";
import Link from "next/link";
import site from "@/data/site.json";

export default function Footer() {
  return (
    <footer
      style={{
        borderTop: "1px solid var(--border)",
        backgroundColor: "var(--background-card)",
        color: "var(--foreground)",
      }}
    >
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
        <div>
          <div className="mb-4 flex items-center gap-3">
            <Image alt={`${site.name} logo`} src="/logo.png" width={40} height={40} />
            <span className="text-xl font-black" style={{ color: "var(--foreground)" }}>
              {site.name}
            </span>
          </div>
          <p className="max-w-md text-sm leading-6" style={{ color: "var(--foreground-muted)" }}>
            {site.description}
          </p>
        </div>

        <div>
          <h3 className="mb-4 text-xs font-bold uppercase" style={{ color: "var(--accent)" }}>
            Resources
          </h3>
          <div className="grid gap-3 text-sm">
            {[
              ["/products", "All products"],
              ["/cart", "Cart"],
            ].map(([href, label]) => (
              <Link key={href} href={href} className="w-fit transition-all hover:underline" style={{ color: "var(--foreground-muted)" }}>
                {label}
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-4 text-xs font-bold uppercase" style={{ color: "var(--accent)" }}>
            Contact
          </h3>
          <div className="grid gap-3 text-sm" style={{ color: "var(--foreground-muted)" }}>
            <span>{site.supportEmail}</span>
            <span>{site.phone}</span>
            <span>{site.address}</span>
          </div>
        </div>
      </div>

      <div
        className="px-4 py-5 text-center text-xs"
        style={{ borderTop: "1px solid var(--border)", color: "var(--foreground-faint)" }}
      >
        Copyright &copy; 2026 {site.name}. Free study resources for Software Tech.
      </div>
    </footer>
  );
}
