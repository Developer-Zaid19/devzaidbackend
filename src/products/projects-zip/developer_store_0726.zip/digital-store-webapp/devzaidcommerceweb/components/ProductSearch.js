"use client";

import { useMemo, useState } from "react";
import ProductCard from "@/components/NoteCard";
import SourceCodeCard from "./SourceCodeCard";
import ApkCard from "./ApkCard";

export default function ProductSearch({ products, initialSubject = "All" }) {
  const [query, setQuery] = useState("");
  const [subject, setSubject] = useState(initialSubject);
  const [className, setClassName] = useState("All");


  const subjects = useMemo(
    () => ["All", ...new Set(products.map((note) => note.subject || note.category))],
    [products],
  );
  const classes = useMemo(
    () => ["All", ...new Set(products.map((note) => note.className || note.class))],
    [products],
  );

  const filteredProducts = useMemo(() => {
    const search = query.trim().toLowerCase();

    return products
      .filter((product) => {
        const matchesSearch =
          !search ||
          [product.title, product.name, product.subject, product.description]
            .filter(Boolean)
            .some((value) => value.toLowerCase().includes(search));
        const matchesSubject = subject === "All" || product.subject === subject || product.category === subject;
        const matchesClass = className === "All" || product.className === className || product.class === className;

        return matchesSearch && matchesSubject && matchesClass;
      })
  }, [className, products, query, subject]);

  return (
    <div className="space-y-6">
      <div
        className="grid gap-3 rounded-lg p-4 lg:grid-cols-[1fr_180px_180px_160px]"
        style={{
          backgroundColor: "var(--background-card)",
          border: "1px solid var(--border)",
          boxShadow: "var(--shadow-sm)",
        }}
      >
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search notes by title, subject, or description"
          className="min-h-12 rounded-lg px-4 text-sm font-semibold outline-none transition"
          style={{
            backgroundColor: "var(--background-subtle)",
            border: "1px solid var(--border)",
            color: "var(--foreground)",
          }}
          aria-label="Search notes"
        />
        <Select label="Subject" value={subject} onChange={setSubject} options={subjects} />
        <Select label="Class" value={className} onChange={setClassName} options={classes} />      
      </div>

      <p className="text-sm font-semibold" style={{ color: "var(--foreground-muted)" }}>
        Showing {filteredProducts.length} free Products
      </p>
      <p className="text-sm font-semibold" style={{ color: "var(--foreground-muted)" }}>
        NOTES
      </p>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredProducts.filter((kiya) => kiya.kiyahai === "notes").map((product) => (
          <ProductCard key={product.id} product={product} />          
        ))}
        {filteredProducts.filter((kiya) => kiya.kiyahai === "projects").map((project) => (
          <SourceCodeCard key={project.id} product={project} />
        ))}
        {filteredProducts.filter((kiya) => kiya.kiyahai === "apk").map((apk) => (
          <ApkCard key={apk.id} product={apk} />
        ))}
        
      </div>
    </div>
  );
}

function Select({ label, value, onChange, options }) {
  return (
    <label className="grid gap-1">
      <span className="text-xs font-bold uppercase" style={{ color: "var(--foreground-faint)" }}>
        {label}
      </span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="min-h-12 rounded-lg px-3 text-sm font-bold outline-none"
        style={{
          backgroundColor: "var(--background-subtle)",
          border: "1px solid var(--border)",
          color: "var(--foreground)",
        }}
      >
        {options.map((option) => {
          const optionValue = Array.isArray(option) ? option[0] : option;
          const optionLabel = Array.isArray(option) ? option[1] : option;
          return (
            <option key={optionValue} value={optionValue}>
              {optionLabel}
            </option>
          );
        })}
      </select>
    </label>
  );
}
