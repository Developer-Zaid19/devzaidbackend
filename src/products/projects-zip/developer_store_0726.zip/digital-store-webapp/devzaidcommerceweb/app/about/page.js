import Image from "next/image";
import site from "@/data/site.json";

export const metadata = {
  title: "About",
  description: "Learn why <DeveloperZaid/> provides free educational Material for Techei.",
};

export default function AboutPage() {
  return (
    <>
      <section style={{ backgroundColor: "var(--background-card)" }}>
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1fr_0.9fr] lg:px-8">
          <div>
            <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
              About us
            </p>
            <h1 className="mt-2 text-4xl font-black leading-tight sm:text-5xl" style={{ color: "var(--foreground)" }}>
              A free Digital library built to make study material easier to find.
            </h1>
            <p className="mt-6 text-lg leading-8" style={{ color: "var(--foreground-muted)" }}>
              {site.name} helps beginners discover useful PDFs, Sourcecodes without accounts, payments, or confusing checkout steps.
              The goal is simple: organize quality material by subject, make search fast, and keep downloads free.
            </p>
          </div>
          <div className="relative min-h-[360px] overflow-hidden rounded-lg" style={{ boxShadow: "var(--shadow-xl)" }}>
            <Image src="/about.png" alt="Study workspace with notes" fill sizes="(min-width: 1024px) 45vw, 100vw" className="object-cover" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            ["Free access", "Every listed resource is available for direct Download Zip."],
            ["Beginners focused", "Products are grouped by subject, class, and type use cases."],
            ["Portfolio ready", "The project keeps room for future ebooks, roadmaps, bookmarks, ratings, and requests."],
          ].map(([title, copy]) => (
            <article key={title} className="rounded-lg p-6 transition-all hover:-translate-y-1" style={{ backgroundColor: "var(--background-card)", border: "1px solid var(--border)", boxShadow: "var(--shadow-sm)" }}>
              <h2 className="text-xl font-black" style={{ color: "var(--foreground)" }}>
                {title}
              </h2>
              <p className="mt-3 leading-7" style={{ color: "var(--foreground-muted)" }}>
                {copy}
              </p>
            </article>
          ))}
        </div>
      </section>
    </>
  );
}
