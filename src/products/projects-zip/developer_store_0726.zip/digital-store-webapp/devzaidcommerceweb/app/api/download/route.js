export async function POST(req) {
    try {
        const cartItems = await req.json();

        const backendResponse = await fetch(
            `http://localhost:5000/api/products/downloadcart`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(cartItems),
            }
        );

        if (!backendResponse.ok) {
            return Response.json(
                { success: false, message: "Download failed" },
                { status: 500 }
            );
        }

        const zipBuffer = await backendResponse.arrayBuffer();

        return new Response(zipBuffer, {
            headers: {
                "Content-Type": "application/zip",
                "Content-Disposition":
                    'attachment; filename="DeveloperZaid.zip"',
            },
        });
    } catch (error) {
        return Response.json(
            {
                success: false,
                message: error.message,
            },
            {
                status: 500,
            }
        );
    }
}