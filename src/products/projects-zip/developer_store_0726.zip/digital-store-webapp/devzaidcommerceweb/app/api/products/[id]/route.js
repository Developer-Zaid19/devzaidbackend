import { NextResponse } from "next/server";

const NOTES_API_URL =
  process.env.NOTES_API_URL ||
  process.env.NEXT_PUBLIC_NOTES_API_URL ||
  "http://localhost:5000/api/content/notes";

export async function PUT(request, { params }) {
  const { id } = await params;
  const body = await request.json();

  try {
    const response = await fetch(`${NOTES_API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      cache: "no-store",
    });
    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 502 });
  }
}

export async function DELETE(request, { params }) {
  const { id } = await params;

  try {
    const response = await fetch(`${NOTES_API_URL}/${id}`, {
      method: "DELETE",
      cache: "no-store",
    });
    const data = await response.json();
    return NextResponse.json(data, { status: response.status });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 502 });
  }
}
