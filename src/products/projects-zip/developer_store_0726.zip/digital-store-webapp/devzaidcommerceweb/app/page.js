import Image from "next/image";
import Link from "next/link";
import ProductCard from "@/components/NoteCard";
import site from "@/data/site.json";
import {
  getCategories,
  getFeaturedProducts,
  getLatestProducts,
  getAllProducts,
  getClasses,
} from "@/lib/products";
import SourceCodeCard from "@/components/SourceCodeCard";

export const dynamic = "force-dynamic";

export default async function Home() {

  const products = await getAllProducts();

  const featuredproducts = getFeaturedProducts(products, 4);
  const latestproducts = getLatestProducts(products, 4);
  const popularSubjects = getCategories(products).filter((subject) => subject !== "All").slice(0,9);
  const feildclass = getClasses(products).length-1

  return (
    <>
      <section className="relative overflow-hidden" style={{ backgroundColor: "#111827" }}>
        <div className="absolute inset-0 opacity-40">
          <Image src="/hero.avif" alt="Students reading free digital products" fill priority sizes="100vw" className="object-cover" />
        </div>
        <div className="absolute inset-x-0 bottom-0 h-36" style={{ background: "linear-gradient(to bottom, transparent, var(--background))" }} />

        <div className="relative mx-auto grid min-h-[610px] max-w-7xl content-end gap-8 px-4 pb-14 pt-28 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="mb-4 inline-flex rounded-full px-4 py-2 text-sm font-bold text-white backdrop-blur-sm" style={{ backgroundColor: "rgba(255,255,255,0.14)" }}>
              {site.tagline}
            </p>
            <h1 className="text-5xl font-black leading-tight text-white sm:text-6xl lg:text-7xl">
              Free Digital products For Coders
            </h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-neutral-200">
              Download quality study Material, cheatsheets, Source Codes, and quick revision PDFs completely free.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/products" className="rounded-full px-6 py-3 text-center text-sm font-black transition-all hover:scale-105 active:scale-95" style={{ backgroundColor: "var(--accent)", color: "var(--cta-text)" }}>
                Browse Products
              </Link>
              <Link href="/products" className="rounded-full border border-white/40 px-6 py-3 text-center text-sm font-bold text-white transition-all hover:bg-white hover:text-neutral-950">
                Latest Uploads
              </Link>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <Stat value={`${products.length}+`} label="Total products" />
            <Stat value={popularSubjects.length} label="Subjects" />
            <Stat value={feildclass} label="Feilds" />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <SectionHeading eyebrow="Featured products" title="Start with these Programmers favorites" href="/products" />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featuredproducts.map((note) => (
            <ProductCard key={note.id} product={note} />
          ))}
        </div>
      </section>

      <section style={{ backgroundColor: "var(--background-card)" }}>
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <SectionHeading eyebrow="Latest products" title="Recently uploaded Projects" href="/products#hadith-webapp-0326" />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {latestproducts.map((note) => (
              <SourceCodeCard key={note.id} product={note} />
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-8">
          <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
            Popular subjects
          </p>
          <h2 className="mt-2 text-3xl font-black" style={{ color: "var(--foreground)" }}>
            Browse by subject
          </h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {popularSubjects.map((subject) => {
            const subjectproducts = products.filter((note) => note.category === subject);
            return (
              <Link
                key={subject}
                href={`/products?subject=${encodeURIComponent(subject)}`}
                className="rounded-lg p-5 transition-all hover:-translate-y-1"
                style={{ backgroundColor: "var(--background-card)", border: "1px solid var(--border)", boxShadow: "var(--shadow-sm)" }}
              >
                <h3 className="text-lg font-black" style={{ color: "var(--foreground)" }}>
                  {subject}
                </h3>
                <p className="mt-2 text-sm" style={{ color: "var(--foreground-muted)" }}>
                  {subjectproducts.length} free Digital Resource
                </p>
              </Link>
            );
          })}
        </div>
      </section>
    </>
  );
}

function SectionHeading({ eyebrow, title, href }) {
  return (
    <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
      <div>
        <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
          {eyebrow}
        </p>
        <h2 className="mt-2 text-3xl font-black" style={{ color: "var(--foreground)" }}>
          {title}
        </h2>
      </div>
      <Link href={href} className="text-sm font-black underline decoration-4 underline-offset-4" style={{ color: "var(--foreground)", textDecorationColor: "var(--accent)" }}>
        View all products
      </Link>
    </div>
  );
}

function Stat({ value, label }) {
  return (
    <div className="rounded-lg p-4 backdrop-blur-sm" style={{ backgroundColor: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.15)" }}>
      <p className="text-2xl font-black" style={{ color: "var(--accent)" }}>
        {value}
      </p>
      <p className="mt-1 text-sm text-neutral-300">{label}</p>
    </div>
  );
}
