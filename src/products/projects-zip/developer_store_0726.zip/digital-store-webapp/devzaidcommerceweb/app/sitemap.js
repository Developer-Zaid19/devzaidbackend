import site from "@/data/site.json";
import { getProducts } from "@/lib/products";

export default async function sitemap() {
  let notes = [];

  try {
    notes = await getProducts();
  } catch (error) {
    notes = [];
  }
  const baseUrl = site.siteUrl;
  const routes = ["", "/notes", "/about", "/contact"].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.8,
  }));

  return [
    ...routes,
    ...notes.map((note) => ({
      url: `${baseUrl}/notes/${note.slug}`,
      lastModified: new Date(note.uploadedDate),
      changeFrequency: "monthly",
      priority: 0.7,
    })),
  ];
}
