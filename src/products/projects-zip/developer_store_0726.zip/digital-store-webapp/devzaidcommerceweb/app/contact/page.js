"use client"
import site from "@/data/site.json";
import { useEffect, useState } from "react";
import { FaYoutube, FaUser, FaLinkedin, FaGithub } from "react-icons/fa6";


export default function ContactPage() {

  const socialLinks = [
    { Icon: FaLinkedin, href: "https://www.linkedin.com/in/developer-zaid29", label: "LinkedIn" },
    { Icon: FaGithub, href: "https://github.com/Developer-Zaid19", label: "GitHub" },
    { Icon: FaUser, href: "https://developerzaid.vercel.app", label: "Facebook" },
    { Icon: FaYoutube, href: "https://www.youtube.com/@developer-zaid/", label: "Instagram" },
  ];

  const [name, setname] = useState("");
  const [email, setemail] = useState("");
  const [subject, setsubject] = useState("");
  const [msg, setmsg] = useState("");
  const [submitting, setsubmitting] = useState(false)


  async function handleSubmit() {
    setsubmitting(true);
    try {
      if(name==''|| email=='' || subject=='' || msg=='')  {
        alert("all feilds required")
        return
      }
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          subject,
          message: msg
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed to to response");
      alert("We will Contact you soon");
    } catch (err) {
      alert(err.message);
    } finally {
      setsubmitting(false);
    }
  }

  return (
    <section className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
      <div className="rounded-lg p-8 text-white" style={{ backgroundColor: "#0f172a" }}>
        <p className="text-sm font-bold uppercase" style={{ color: "var(--accent)" }}>
          Contact
        </p>
        <h1 className="mt-3 text-4xl font-black">Help improve the library.</h1>
        <p className="mt-4 leading-7 text-neutral-300">
          Report a broken zip, suggest a subject, request a resource, or share feedback about the platform.
        </p>
        <div className="my-8 grid gap-4 text-sm text-neutral-200">
          <span>{site.supportEmail}</span>
          <span>{site.phone}</span>
          <span>{site.address}</span>
        </div>
        <div className='flex justify-center items-center gap-8'>
          {socialLinks.map((item, i) => (
            <a
              key={i}
              target="_blank"
              href={item.href}
              aria-label={item.label}
              className="w-10 h-10 border border-(--border) rounded-xl flex items-center justify-center text-(--text-muted) hover:border-(--maincolor) hover:text-(--maincolor) hover:bg-[rgba(34,197,94,0.08)] hover:shadow-[0_0_12px_var(--mainglow)] hover:scale-110 transition-all duration-300"
            >
              <item.Icon />
            </a>
          ))}
        </div>

      </div>

      <form
        className="grid gap-5 rounded-lg p-6"
        style={{ backgroundColor: "var(--background-card)", border: "1px solid var(--border)", boxShadow: "var(--shadow-sm)" }}
      >
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Name" placeholder="Your name" value={name} func={setname} />
          <Field label="Email" type="email" placeholder="you@example.com" value={email} func={setemail} />
        </div>
        <Field label="Subject" placeholder="Broken download, request, or feedback" value={subject} func={setsubject} />
        <label className="grid gap-2">
          <span className="text-sm font-bold" style={{ color: "var(--foreground)" }}>
            Message
          </span>
          <textarea
          required
            rows="7"
            className="rounded-lg px-4 py-3 text-sm outline-none transition"
            style={{ backgroundColor: "var(--background-subtle)", border: "1px solid var(--border)", color: "var(--foreground)" }}
            placeholder="Write your message"
            value={msg}
            onChange={(e) => setmsg(e.target.value)}
          />
        </label>
        <button type="button"
         style={{ backgroundColor: "var(--accent)", color: "var(--cta-text)" }} onClick={() => handleSubmit()}
          disabled={submitting}
          className={`w-fit rounded-full px-6 py-3 text-sm font-black transition-all hover:scale-105 active:scale-95`}
          >
          {submitting ? "Submitting..." : "Send Message"}
        </button>
      </form>
    </section>
  );
}

function Field({ label, type = "text", placeholder, value, func }) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-bold" style={{ color: "var(--foreground)" }}>
        {label}
      </span>
      <input
        type={type}
        className="rounded-lg px-4 py-3 text-sm outline-none transition"
        style={{ backgroundColor: "var(--background-subtle)", border: "1px solid var(--border)", color: "var(--foreground)" }}
        placeholder={placeholder}
        value={value}
        onChange={(e) => func(e.target.value)}
        required
      />
    </label>
  );
}
