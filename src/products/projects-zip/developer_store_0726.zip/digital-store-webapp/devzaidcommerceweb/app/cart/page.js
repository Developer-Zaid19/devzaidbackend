import CartView from "@/components/CartView";

export const metadata = {
  title: "Cart Products",
};

export default function CartPage() {
  return <CartView />;
}
