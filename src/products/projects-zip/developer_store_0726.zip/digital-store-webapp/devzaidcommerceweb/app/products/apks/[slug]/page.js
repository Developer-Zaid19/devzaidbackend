import Image from "next/image";
import AddToCartButton from "@/components/AddToCartButton";
import ScreenshotGallery from "@/components/apk/ScreenshotGallery";
import Link from "next/link";
import { getApks, getapksbyslug } from "@/lib/products";
import { FaAndroid, FaFile, FaCalendar, FaCode, FaGear, FaEarthAsia, FaLaptopCode, FaCodeFork } from "react-icons/fa6";


export default async function Page({ params }) {
    const { slug } = await params;

    const apk = await getapksbyslug(slug)
    // console.log("hm yahan hai ", apk)

    const relatedApps = (await getApks()).filter((app) => app.id !== apk.id)
    // const relatedApps = await getApks()
    console.log(relatedApps)
    

    return (
        <main
            className="min-h-screen py-10"
            style={{ backgroundColor: "var(--background)" }}
        >
            <div className="mx-auto max-w-7xl px-4">

                {/* HERO */}

                <section
                    className="rounded-3xl border p-6 lg:p-10"
                    style={{
                        background: "var(--background-card)",
                        borderColor: "var(--border)",
                        boxShadow: "var(--shadow-md)",
                    }}
                >
                    <div className="grid gap-8 lg:grid-cols-[130px_1fr_260px]">

                        {/* APP ICON */}

                        <div className="flex justify-center lg:block">
                            <div
                                className="relative h-32 w-32 overflow-hidden rounded-3xl border"
                                style={{
                                    borderColor: "var(--border)",
                                    background: "var(--background-subtle)",
                                }}
                            >
                                <Image
                                    src={`/apk/img${apk.image}`}
                                    alt={apk.title}
                                    fill
                                    className="object-cover"
                                />
                            </div>
                        </div>

                        {/* APP DETAILS */}

                        <div className="space-y-5">

                            <div>
                                <h1
                                    className="text-3xl font-black lg:text-5xl"
                                    style={{ color: "var(--foreground)" }}
                                >
                                    {apk.title}
                                </h1>

                                <p
                                    className="mt-3 max-w-2xl text-base leading-7"
                                    style={{ color: "var(--foreground-muted)" }}
                                >
                                    {apk.description}
                                </p>
                            </div>

                            <div className="flex flex-wrap gap-3">

                                <span
                                    className="rounded-full px-4 py-2 text-sm font-semibold"
                                    style={{
                                        background: "var(--brand-faint)",
                                        color: "var(--brand)",
                                    }}
                                >
                                    {apk.category}
                                </span>

                                <span
                                    className="rounded-full px-4 py-2 text-sm"
                                    style={{
                                        background: "var(--background-subtle)",
                                        color: "var(--foreground-muted)",
                                    }}
                                >
                                    {apk.stack}
                                </span>

                                <span
                                    className="rounded-full px-4 py-2 text-sm"
                                    style={{
                                        background: "var(--background-subtle)",
                                        color: "var(--foreground-muted)",
                                    }}
                                >
                                    JavaScript
                                </span>

                            </div>

                            <div className="grid grid-cols-3 gap-4 max-w-xl">

                                <div>
                                    <p
                                        className="text-xs uppercase"
                                        style={{ color: "var(--foreground-faint)" }}
                                    >
                                        Version
                                    </p>

                                    <p
                                        className="font-semibold"
                                        style={{ color: "var(--foreground)" }}
                                    >
                                        {apk.version}
                                    </p>
                                </div>

                                <div>
                                    <p
                                        className="text-xs uppercase"
                                        style={{ color: "var(--foreground-faint)" }}
                                    >
                                        Android
                                    </p>

                                    <p
                                        className="font-semibold"
                                        style={{ color: "var(--foreground)" }}
                                    >
                                        {apk.androidVersion}
                                    </p>
                                </div>

                                <div>
                                    <p
                                        className="text-xs uppercase"
                                        style={{ color: "var(--foreground-faint)" }}
                                    >
                                        Size
                                    </p>

                                    <p
                                        className="font-semibold"
                                        style={{ color: "var(--foreground)" }}
                                    >
                                        {apk.fileSize}MB
                                    </p>
                                </div>

                            </div>

                        </div>

                        {/* PURCHASE */}

                        <div
                            className="rounded-2xl border p-6"
                            style={{
                                borderColor: "var(--border)",
                                background: "var(--background-subtle)",
                            }}
                        >
                            <p
                                className="text-sm"
                                style={{ color: "var(--foreground-faint)" }}
                            >
                                Price
                            </p>

                            <div className="mt-2 flex items-end gap-3">

                                <span
                                    className="text-4xl font-black"
                                    style={{ color: "var(--foreground)" }}
                                >
                                    FREE
                                </span>

                                <span
                                    className="line-through"
                                    style={{ color: "var(--foreground-faint)" }}
                                >
                                    299
                                </span>

                            </div>

                            <div className="mt-6 space-y-3">

                                <AddToCartButton
                                    productId={apk.id}
                                    type="apk"
                                />                               

                            </div>

                        </div>

                    </div>
                </section>

                <ScreenshotGallery
                    screenshots={apk.screenshots}
                    title={apk.title}
                />

                {/* ABOUT & FEATURES */}
                <section className="grid gap-8 lg:grid-cols-[1.3fr_.7fr] my-8">

                    {/* ABOUT */}

                    <div
                        className="rounded-3xl border p-8"
                        style={{
                            background: "var(--background-card)",
                            borderColor: "var(--border)",
                            boxShadow: "var(--shadow-sm)",
                        }}
                    >
                        <h2
                            className="text-2xl font-bold"
                            style={{ color: "var(--foreground)" }}
                        >
                            About this App
                        </h2>

                        <div
                            className="mt-6 space-y-5 leading-8"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            {apk.aboutapk1
                                .split("\n")
                                .map((paragraph, index) => (
                                    <p key={index}>{paragraph}</p>
                                ))}
                        </div>
                        <div
                            className="mt-6 space-y-5 leading-8"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            {apk.aboutapk2
                                .split("\n")
                                .map((paragraph, index) => (
                                    <p key={index}>{paragraph}</p>
                                ))}
                        </div>
                        <div
                            className="mt-6 space-y-5 leading-8"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            {apk.aboutapk3
                                .split("\n")
                                .map((paragraph, index) => (
                                    <p key={index}>{paragraph}</p>
                                ))}
                        </div>
                    </div>

                    {/* FEATURES */}

                    <div
                        className="rounded-3xl border p-8"
                        style={{
                            background: "var(--background-card)",
                            borderColor: "var(--border)",
                            boxShadow: "var(--shadow-sm)",
                        }}
                    >
                        <h2
                            className="text-2xl font-bold"
                            style={{ color: "var(--foreground)" }}
                        >
                            Key Features
                        </h2>

                        <div className="mt-6 grid gap-4">

                            {apk.features.map((feature) => (

                                <div
                                    key={feature}
                                    className="flex items-center gap-3 rounded-xl px-4 py-3"
                                    style={{
                                        background: "var(--background-subtle)",
                                    }}
                                >
                                    <div
                                        className="flex h-8 w-8 items-center justify-center rounded-full font-bold"
                                        style={{
                                            background: "var(--brand-faint)",
                                            color: "var(--brand)",
                                        }}
                                    >
                                        ✓
                                    </div>

                                    <span
                                        className="font-medium"
                                        style={{ color: "var(--foreground)" }}
                                    >
                                        {feature}
                                    </span>

                                </div>

                            ))}

                        </div>

                    </div>

                </section>


                {/* SPECIFICATIONS */}
                <section
                    className="rounded-3xl border p-8 my-8"
                    style={{
                        background: "var(--background-card)",
                        borderColor: "var(--border)",
                        boxShadow: "var(--shadow-sm)",
                    }}
                >

                    <div className="mb-8">

                        <h2
                            className="text-2xl font-bold"
                            style={{ color: "var(--foreground)" }}
                        >
                            App Information
                        </h2>

                        <p
                            className="mt-2"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            Technical details and compatibility.
                        </p>

                    </div>

                    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">

                        {[
                            {
                                title: "Version",
                                value: apk.version,
                                icon: FaGear,
                            },
                            {
                                title: "Android",
                                value: apk.androidVersion,
                                icon: FaAndroid,
                            },
                            {
                                title: "APK Size",
                                value: apk.fileSize + "MB",
                                icon: FaFile,
                            },
                            {
                                title: "Developer",
                                value: "Developer Zaid",
                                icon: FaLaptopCode,
                            },
                            {
                                title: "Language",
                                value: "English",
                                icon: FaEarthAsia,
                            },
                            {
                                title: "Updated",
                                value: apk.lastupdate,
                                icon: FaCalendar,
                            },
                            {
                                title: "Availibility",
                                value: "Opensource",
                                icon: FaCodeFork,
                            },
                            {
                                title: "Devstack",
                                value: `${apk.stack}`,
                                icon: FaCode,
                            },
                        ].map((item) => (

                            <div
                                key={item.title}
                                className="rounded-2xl border p-5 transition-all duration-300 hover:-translate-y-1"
                                style={{
                                    borderColor: "var(--border)",
                                    background: "var(--background-subtle)",
                                }}
                            >

                                <div
                                    className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl text-xl"
                                    style={{
                                        background: "var(--brand-faint)",
                                    }}
                                >
                                    <item.icon />
                                </div>

                                <p
                                    className="text-sm"
                                    style={{
                                        color: "var(--foreground-faint)",
                                    }}
                                >
                                    {item.title}
                                </p>

                                <h3
                                    className="mt-2 text-lg font-bold"
                                    style={{
                                        color: "var(--foreground)",
                                    }}
                                >
                                    {item.value}
                                </h3>

                            </div>

                        ))}

                    </div>

                </section>


                {/* WHAT'S NEW & REQUIREMENTS */}
                {apk.whatsnew && (

                <section className="grid gap-8 lg:grid-cols-2 my-8">

                    {/* WHAT'S NEW */}

                    <div
                        className="rounded-3xl border p-8"
                        style={{
                            background: "var(--background-card)",
                            borderColor: "var(--border)",
                            boxShadow: "var(--shadow-sm)",
                        }}
                    >

                        <h2
                            className="text-2xl font-bold"
                            style={{ color: "var(--foreground)" }}
                        >
                            What's New
                        </h2>

                        <p
                            className="mt-2"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            Latest improvements in this release.
                        </p>

                        <div className="mt-8 space-y-4">

                            {apk.whatsnew.map((item) => (

                                <div
                                    key={item}
                                    className="flex items-start gap-4 rounded-xl p-4"
                                    style={{
                                        background: "var(--background-subtle)",
                                    }}
                                >

                                    <div
                                        className="mt-1 flex h-7 w-7 items-center justify-center rounded-full text-sm font-bold"
                                        style={{
                                            background: "var(--brand)",
                                            color: "#fff",
                                        }}
                                    >
                                        ✓
                                    </div>

                                    <p
                                        className="leading-7"
                                        style={{
                                            color: "var(--foreground)",
                                        }}
                                    >
                                        {item}
                                    </p>

                                </div>

                            ))}

                        </div>

                    </div>

                    {/* REQUIREMENTS */}

                    <div
                        className="rounded-3xl border p-8"
                        style={{
                            background: "var(--background-card)",
                            borderColor: "var(--border)",
                            boxShadow: "var(--shadow-sm)",
                        }}
                    >

                        <h2
                            className="text-2xl font-bold"
                            style={{ color: "var(--foreground)" }}
                        >
                            System Requirements
                        </h2>

                        <p
                            className="mt-2"
                            style={{ color: "var(--foreground-muted)" }}
                        >
                            Minimum requirements to run this application.
                        </p>

                        <div className="mt-8 divide-y"
                            style={{
                                borderColor: "var(--border)"
                            }}
                        >

                            {[
                                ["Android Version", apk.androidVersion],
                                ["RAM", "2GB"],
                                ["Storage", apk.fileSize + "MB+"],
                                ["Internet", "Download this APK only"],
                            ].map(([label, value]) => (

                                <div
                                    key={label}
                                    className="flex items-center justify-between py-5"
                                >

                                    <span
                                        style={{
                                            color: "var(--foreground-muted)"
                                        }}
                                    >
                                        {label}
                                    </span>

                                    <span
                                        className="font-semibold"
                                        style={{
                                            color: "var(--foreground)"
                                        }}
                                    >
                                        {value}
                                    </span>

                                </div>

                            ))}

                        </div>

                    </div>

                </section>

                )}


                {/* RELATED APPS */}
                <section className="my-8">

                    <div className="mb-8 flex items-end justify-between">

                        <div>

                            <h2
                                className="text-3xl font-bold"
                                style={{ color: "var(--foreground)" }}
                            >
                                Related Apps
                            </h2>

                            <p
                                className="mt-2"
                                style={{ color: "var(--foreground-muted)" }}
                            >
                                You may also like these Android applications.
                            </p>

                        </div>

                    </div>

                    <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">

                        {relatedApps.map((app) => (

                            <Link
                                key={app.id}
                                href={`/products/apks/${app.id}`}
                                className="group rounded-3xl border p-5 transition-all duration-300 hover:-translate-y-2"
                                style={{
                                    background: "var(--background-card)",
                                    borderColor: "var(--border)",
                                    boxShadow: "var(--shadow-sm)",
                                }}
                            >

                                <div className="flex gap-4">

                                    <div
                                        className="relative h-20 w-20 overflow-hidden rounded-2xl"
                                        style={{
                                            background: "var(--background-subtle)",
                                        }}
                                    >
                                        <Image
                                            src={`/apk/img${app.icon}`}
                                            alt={app.title}
                                            fill
                                            className="object-cover transition duration-500 group-hover:scale-105"
                                        />
                                    </div>

                                    <div className="flex-1">

                                        <span
                                            className="rounded-full px-2 py-1 text-xs"
                                            style={{
                                                background: "var(--brand-faint)",
                                                color: "var(--brand)",
                                            }}
                                        >
                                            {app.category}
                                        </span>

                                        <h3
                                            className="mt-3 text-lg font-bold"
                                            style={{
                                                color: "var(--foreground)",
                                            }}
                                        >
                                            {app.title}
                                        </h3>

                                        <p
                                            className="mt-1 text-sm"
                                            style={{
                                                color: "var(--foreground-muted)",
                                            }}
                                        >
                                            <FaLaptopCode /> {app.stack}
                                        </p>

                                    </div>

                                </div>

                                <div
                                    className="mt-6 flex items-center justify-between border-t pt-5"
                                    style={{
                                        borderColor: "var(--border)",
                                    }}
                                >

                                    <span
                                        className="text-2xl font-black"
                                        style={{
                                            color: "var(--foreground)",
                                        }}
                                    >
                                        {app.price}
                                    </span>

                                    <span
                                        className="rounded-xl px-4 py-2 text-sm font-semibold transition"
                                        style={{
                                            background: "var(--brand)",
                                            color: "#fff",
                                        }}
                                    >
                                        View App
                                    </span>

                                </div>

                            </Link>

                        ))}

                    </div>

                </section>

                <details className="rounded-2xl border p-5">
                    <summary className="cursor-pointer font-semibold">
                        Can I install this app on multiple devices?
                    </summary>

                    <p className="mt-4 text-sm leading-7">
                        Yes, depending on the license purchased.
                    </p>
                </details>
            </div>
        </main>
    );
}