import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "@/components/AddToCartButton";
import ProductCard from "@/components/NoteCard";
import { formatDate, getProductBySlug, getProducts, getRelatedProducts } from "@/lib/products";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }) {
  const { slug } = await params;
  const note = await getProductBySlug(slug);

  if (!note) {
    return { title: "Note not found" };
  }

  return {
    title: note.title,
    description: note.description,
    openGraph: {
      title: note.title,
      description: note.description,
      type: "article",
    },
  };
}

export default async function NotePage({ params }) {
  const { slug } = await params;
  const notes = await getProducts();
  const note = notes.find((entry) => entry.slug === slug || entry.url === slug || String(entry.id) === String(slug));

  if (!note) notFound();

  const relatedNotes = getRelatedProducts(notes, note);

  return (
    <>
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
        <div
          className="relative min-h-[320px] overflow-hidden rounded-lg"
          style={{ backgroundColor: "var(--background-subtle)", boxShadow: "var(--shadow-xl)" }}
        >
          <Image
            src={`/notes/img${note.image || "penpencil.webp"}`}
            alt={note.title}
            fill
            sizes="(min-width: 1024px) 45vw, 100vw"
            className="bg-white"
          />
        </div>

        <div>
          <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
            {note.subject} / {note.what}
          </p>
          <h1 className="mt-3 text-4xl font-black leading-tight sm:text-5xl" style={{ color: "var(--foreground)" }}>
            {note.title}
          </h1>
          <p className="mt-5 text-lg leading-8" style={{ color: "var(--foreground-muted)" }}>
            {note.description}
          </p>

          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            <Info label="Subject" value={note.type} />
            <Info label="Class" value={note.className || note.class} />
            <Info label="File size" value={note.fileSize} />
            <Info label="Pages" value={`${note.pages || note.pagesCount} pages`} />
            <Info label="Uploaded" value={formatDate(note.uploaddate)} />
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <AddToCartButton productId={note.url} compact />
            <Link
              href="/notes"
              className="rounded-full px-6 py-3 text-center text-sm font-bold transition-all hover:scale-105"
              style={{ border: "1px solid var(--border)", color: "var(--foreground)" }}
            >
              Browse more notes
            </Link>
          </div>
        </div>
      </section>

      {relatedNotes.length ? (
        <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
          <div className="mb-8">
            <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
              Related notes
            </p>
            <h2 className="mt-2 text-3xl font-black" style={{ color: "var(--foreground)" }}>
              More from {note.subject}
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {relatedNotes.map((related) => (
              <ProductCard key={related.id} product={related} />
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}

function Info({ label, value }) {
  return (
    <div className="rounded-lg p-4" style={{ backgroundColor: "var(--background-card)", border: "1px solid var(--border)" }}>
      <p className="text-xs font-bold uppercase" style={{ color: "var(--foreground-faint)" }}>
        {label}
      </p>
      <p className="mt-1 font-black" style={{ color: "var(--foreground)" }}>
        {value}
      </p>
    </div>
  );
}
