import ProductSearch from "@/components/ProductSearch";
import { getAllProducts } from "@/lib/products";

export const metadata = {
  title: "Free PDF Notes",
  description: "Search, filter, and download free PDF notes by subject, class, latest uploads, and popularity.",
};

export const dynamic = "force-dynamic";

export default async function NotesPage({ searchParams }) {
  const products = await getAllProducts();
  const params = await searchParams;

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-sm font-bold uppercase" style={{ color: "var(--brand)" }}>
          Digital library
        </p>
        <h1 className="mt-2 text-4xl font-black" style={{ color: "var(--foreground)" }}>
          Download free Resources
        </h1>
        <p className="mt-4 max-w-2xl leading-7" style={{ color: "var(--foreground-muted)" }}>
          Search by title, filter by subject or class, and add to cart items.
        </p>
      </div>

      <ProductSearch
        products={products}
        initialSubject={params?.subject || "All"}
        initialSort={params?.sort || "latest"}
      />
    </section>
  );
}
