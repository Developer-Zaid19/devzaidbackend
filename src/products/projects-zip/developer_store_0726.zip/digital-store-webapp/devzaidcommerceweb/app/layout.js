import { CartProvider } from "@/components/CartProvider";
import { ThemeProvider } from "@/components/ThemeProvider";
import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import site from "@/data/site.json";
import "./globals.css";

export const metadata = {
  metadataBase: new URL(site.siteUrl),
  title: {
    default: "<DeveloperZaid/> | Free PDF Notes For Students",
    template: "%s | <DeveloperZaid/>",
  },
  description: site.description,
  openGraph: {
    title: "<DeveloperZaid/>",
    description: site.description,
    type: "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body style={{ minHeight: "100vh", backgroundColor: "var(--background)", color: "var(--foreground)" }}>
          <ThemeProvider>
            <CartProvider>
              <div className="flex min-h-screen flex-col">
                <Navbar />
                <main className="flex-1">{children}</main>
                <Footer />
              </div>
            </CartProvider>
          </ThemeProvider>
      </body>
    </html>
  );
}
