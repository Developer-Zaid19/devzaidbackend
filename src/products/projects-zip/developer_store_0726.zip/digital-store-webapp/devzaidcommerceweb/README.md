# 🚀 Developer Zaid Store Website

A modern digital marketplace built with **Next.js**, designed for distributing study notes, source code projects, and Android APKs through a clean, responsive, and fast user experience.

---

## ✨ Features

* 📚 Browse Study Notes
* 💻 Source Code Marketplace
* 📱 APK Marketplace
* 🔍 Powerful Search
* 🏷 Subject & Category Filters
* ❤️ Favorites
* 🛒 Shopping Cart
* 📄 Product Detail Pages
* 🌙 Light & Dark Theme
* 👨‍💼 Admin Dashboard
* 📱 Fully Responsive Design
* ⚡ Fast Performance

---

## 🛠 Tech Stack

* Next.js (App Router)
* React
* Tailwind CSS
* JavaScript
* Express.js REST API
* MongoDB

---

## 📂 Main Pages

* Home
* Products
* Product Details
* Cart
* Favorites
* About
* Contact
* Admin Dashboard

---

## 📦 Product Categories

### 📚 Notes

* PDF Notes
* Subject Wise
* Class Wise

### 💻 Source Code Projects

* Complete Source Code
* Documentation
* Images
* Download Support

### 📱 Android APKs

* APK Details
* Screenshots
* Features
* What's New
* Download Support

---

## 🔗 Backend API

The website communicates with a REST API backend for loading products and downloads.

Main endpoints include:

* `/content/notes`
* `/content/projects`
* `/products/apks`

---

## 🚀 Installation

```bash
git clone <repository-url>

npm install

npm run dev
```

---

## 🏗 Production Build

```bash
npm run build

npm start
```

---

## 📌 Future Improvements

* User Authentication
* Payment Gateway
* Product Reviews
* Ratings
* User Profiles
* Order History
* Notifications

---

## 👨‍💻 Author

**Developer Zaid**

Full Stack Web & Mobile Application Developer

If you like this project, consider giving it a ⭐ on GitHub.
